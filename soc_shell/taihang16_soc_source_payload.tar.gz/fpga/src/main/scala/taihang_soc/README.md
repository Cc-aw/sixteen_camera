# Taihang SoC FPGA Configuration

## Preferred 128x128 TinyYOLOv2 configuration

```text
TaihangSoC1Rocket1RVV1Gemmini128x128PackedFullOpsConfig
```

This is the preferred single-hart Taihang configuration for TinyYOLOv2. It
combines one Huge Rocket core, one DSP-oriented Saturn RVV unit, and one
logical 128x128 WS Gemmini. The Gemmini uses `tileRows=1`, `tileColumns=2`,
`meshRows=128`, and `meshColumns=64`, so two signed INT8 MACs share each
DSP48E2 while software continues to see `DIM=128`.

The configuration retains Taihang DDR, UART, MMIO, coherent DMA, and JTAG,
with SPI omitted. Gemmini MaxPool and nonlinear activation hardware remain
enabled for the TinyYOLOv2 software contract. Its generated parameter header
is:

```text
gemmini_params_taihang_128x128_packed_fullops.h
```

Key parameters are:

| Module | Configuration |
| --- | --- |
| Rocket | 1 Huge Rocket core |
| Saturn RVV | 1 unit, `vLen=256`, `dLen=128`, DSP parameters |
| Gemmini | 1 logical 128x128 WS array with dual-INT8 DSP packing |
| Gemmini memory | 512 KiB scratchpad, 256 KiB accumulator |
| System/DDR | 512-bit data path, 4 GiB DDR address space |
| Gemmini DMA | 256-bit data path, 32 in-flight requests |
| Clock | 100 MHz |

This source configuration has not yet been elaborated or implemented in this
repository.

本目录提供用于下板功能验证的 FPGA 配置：

```text
TaihangSoC2Rocket2RVV3Gemmini32x32Config
```

> 当前状态：该配置尚未完成 FPGA 下板验证，目前只完成了 Scala 编译和
> Chisel/FIRRTL/Verilog 生成检查。

配置包为 `tsmcchip.fpga.taihangsoc`，使用独立的
`TaihangSoCFPGATestHarness` 和 AXI 接口定义。配置文件位于
[`Configs.scala`](Configs.scala)。

## 配置目标

该配置保留 DDR、coherent DMA、MMIO、UART、JTAG 和 RVV 功能，但去掉 SPI，并将硬件规模
缩小为适合首次下板验证的版本：

| 模块 | 配置 |
| --- | --- |
| Rocket | 2 个 Huge Rocket core |
| Saturn RVV | 2 个，每个 Rocket 一个 |
| Gemmini | 3 个，均为 `32x32` WS-only mesh |
| 系统总线 | 256 bit |
| 外部内存 | 256 bit AXI，4 GiB 地址空间 |
| 时钟 | 100 MHz |
| UART | 115200 baud，地址 `0x10020000` |
| MMIO AXI | 地址 `0x10040000`，大小 `0x1000`，数据宽度 64 bit |
| SPI | 未实例化，不生成 SPI 顶层端口 |

`TaihangSoC2Rocket2RVV3Gemmini32x32Config` 保留双 Huge Rocket、双 Saturn RVV
和 Taihang 的 DDR/UART/MMIO/JTAG/DMA 接口，但将 Gemmini 改为三个独立的
32x32 WS-only 阵列。三个实例仍按 hart 0 上两个、hart 1 上一个分配，opcode
分别为 `custom3/custom2/custom1`，busy CSR 分别为 `0x7c2/0x7c3/0x7c4`。

该版本使用 explicit DSP MAC blackbox，并关闭 max-pool 和非线性激活硬件；
scratchpad 为 256 KiB、accumulator 为 64 KiB，DMA 总线保持 256 bit。

## Hart 与 Gemmini 分配

RoCC 加速器是 tile-local，不能由两个 Rocket 共享同一个硬件实例。因此
三个 Gemmini 按如下方式分配：

| Hart | RVV | Gemmini | Opcode | Busy CSR |
| --- | --- | --- | --- | --- |
| hart 0 | Saturn RVV | Gemmini 0 | `custom3` | `0x7c2` |
| hart 0 | Saturn RVV | Gemmini 1 | `custom2` | `0x7c3` |
| hart 1 | Saturn RVV | Gemmini 2 | `custom1` | `0x7c4` |

软件测试时需要让线程运行在拥有目标 Gemmini 的 hart 上。三个参数头文件
会在 Chisel elaboration 时生成：

```text
generators/gemmini/software/gemmini-rocc-tests/include/
  gemmini_params_taihang_32x32_gemmini0.h
  gemmini_params_taihang_32x32_gemmini1.h
  gemmini_params_taihang_32x32_gemmini2.h
```

## Gemmini 参数

每个 Gemmini 使用相同的资源缩减参数：

- mesh：`32x32`
- scratchpad：`256 KiB`，4 banks
- accumulator：`64 KiB`，2 banks
- reservation station：`ld=8`、`st=4`、`ex=8`
- load/store/execute queue：`8/4/8`
- 最大在途内存请求：`16`
- TLB：`4`
- DMA：最大传输 `64 bytes`，总线宽度 `256 bit`

Gemmini 使用 WS 数据流和 explicit DSP MAC blackbox，并关闭 max-pool 与非线性
激活硬件；软件 opcode/CSR 接口保持不变。

## 生成 RTL

从本仓库的 `fpga/` 目录执行：

```bash
cd /home/wzr/chipyard/fpga
source ../env.sh
env -u JAVA_OPTS -u SBT_OPTS XDG_RUNTIME_DIR=/tmp \
  make SUB_PROJECT=taihang_soc \
  CONFIG=TaihangSoC2Rocket2RVV3Gemmini32x32Config verilog
```

默认生成目录为：

```text
fpga/generated-src/tsmcchip.fpga.taihangsoc.TaihangSoCFPGATestHarness.TaihangSoC2Rocket2RVV3Gemmini32x32Config/
```

## 当前验证状态

已经完成的生成检查：

- `chipyard_fpga` Scala 编译通过
- Chisel/FIRRTL/Verilog elaboration 通过
- 生成 2 个 RocketTile
- 生成 2 个 SaturnRocketUnit
- 生成 3 个 Gemmini 实例
- 顶层包含 UART、AXI memory、AXI MMIO 和 AXI coherent F-Bus 接口
- 顶层不包含 SPI 接口

尚未完成的板级验证：

- Vivado 综合、布局布线和 bitstream 生成
- FPGA 启动、UART 和 JTAG 调试
- DDR、MMIO 和 coherent DMA 实际读写
- 两个 RVV 和三个 Gemmini 的板上功能
- YOLOv2 Tiny 板上推理

该配置目前是待验证的 Taihang SoC 32x32 版本。完成上述板级测试后，
才能标记为“已下板验证”。
