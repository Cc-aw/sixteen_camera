package gemmini
import chisel3._
import chisel3.util._
/** col < width, increment <=64: at most64 row boundaries can be crossed.
  * Seven compare/subtract stages, no runtime division or per-pixel iteration.
  */
object VirtualIRowAdvance {
  /** IPOAT：V03 有界跨行进位
   * I（Input 输入）：col<width、width>0、increment<=64。
   * P（Process 处理）：通过7级比较/减法计算 col+increment 跨越的行数，不使用通用除法。
   * O（Output 输出）：新列坐标和跨越行数，由调用者在命令接受时更新迭代器。
   * A（Author 作者）：王志瑞
   * T（Time 时间）：2026-09-09（注释补充日期）
   */
  def apply(col: UInt, width: UInt, increment: UInt): (UInt, UInt) = {
    var remainder: UInt = (col +& increment).pad(24)
    var rows: UInt = 0.U(7.W)
    for (bit <- 6 to 0 by -1) {
      val stride = width.pad(24) << bit
      val take = width =/= 0.U && remainder >= stride
      remainder = Mux(take, remainder - stride, remainder)
      rows = rows | Mux(take, (1 << bit).U(7.W), 0.U(7.W))
    }
    (remainder, rows)
  }
}
