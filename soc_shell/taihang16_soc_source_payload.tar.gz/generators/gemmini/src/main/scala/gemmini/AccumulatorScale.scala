
package gemmini

import chisel3._
import chisel3.util._
import Util._

class AccumulatorReadRespWithFullData[T <: Data: Arithmetic, U <: Data](fullDataType: Vec[Vec[T]], scale_t: U)
  extends Bundle {
  val resp = new AccumulatorReadResp(fullDataType, scale_t)
  val full_data = fullDataType.cloneType
}

class AccumulatorScaleResp[T <: Data: Arithmetic](fullDataType: Vec[Vec[T]], rDataType: Vec[Vec[T]]) extends Bundle {
  val full_data = fullDataType.cloneType
  val data = rDataType.cloneType
  val acc_bank_id = UInt(2.W)
  val fromDMA = Bool()
}

/** IPOAT
 * I（Input 输入）： local row handshakes and scale-pipe lane admission events.
 * P（Process 处理）： count events since reset, without changing ready/valid or allocating a CSR.
 * O（Output 输出）： optional local counters and current lane issue mask for module validation.
 * A（Author 作者）：王志瑞
 * T（Time 时间）：2026-09-09（注释补充日期）
 */
class AccumulatorScalePerf(lanes: Int) extends Bundle {
  val in_rows = UInt(64.W)
  val out_rows = UInt(64.W)
  val issued_elements = UInt(64.W)
  val issue_cycles = UInt(64.W)
  val all_lanes_cycles = UInt(64.W)
  val in_blocked_cycles = UInt(64.W)
  val window_full_cycles = UInt(64.W)
  val out_stall_cycles = UInt(64.W)
  val occupancy_sum = UInt(64.W)
  val occupancy_max = UInt(64.W)
  val lane_issues = UInt(lanes.W)
}

class AccumulatorScaleIO[T <: Data: Arithmetic, U <: Data](
  fullDataType: Vec[Vec[T]], scale_t: U,
  rDataType: Vec[Vec[T]], perf_lanes: Int = 0
) extends Bundle {
  val in = Flipped(Decoupled(new NormalizedOutput[T,U](fullDataType, scale_t)))
  val out = Decoupled(new AccumulatorScaleResp[T](fullDataType, rDataType))
  val silu_lut_write = Flipped(Valid(new SiluLutWrite))
  val perf = if (perf_lanes > 0) Some(Output(new AccumulatorScalePerf(perf_lanes))) else None
  /** IPOAT：AccScale 死锁观测端口
    * I：窗口 entry、发射/完成 lane 与输出握手；P：只读打包；O：四个 64-bit 页；
    * A：王志瑞；T：2026-09-17。
    */
  val deadlock_debug = Output(Vec(4, UInt(64.W)))
}

/** IPOAT
 * I（Input 输入）： accumulator element, arithmetic metadata, entry and column widths.
 * P（Process 处理）： carry the slot and column identity through the existing scale pipe.
 * O（Output 输出）： an explicitly sized element tag; acc_bank_id is a separate address.
 * A（Author 作者）：王志瑞
 * T（Time 时间）：2026-09-09（注释补充日期）
 */
class AccScaleDataWithIndex[T <: Data: Arithmetic, U <: Data](t: T, u: U, entryIdBits: Int, columnIndexBits: Int) extends Bundle {
  require(entryIdBits >= 1 && columnIndexBits >= 1)
  val scale = u.cloneType
  val act = UInt(Activation.bitwidth.W)
  val igelu_qb = t.cloneType
  val igelu_qc = t.cloneType
  val iexp_qln2 = t.cloneType
  val iexp_qln2_inv = t.cloneType
  val mean = t.cloneType
  val max = t.cloneType
  val inv_stddev = u.cloneType
  val inv_sum_exp = u.cloneType
  val data = t.cloneType
  val full_data = t.cloneType
  val id = UInt(entryIdBits.W)
  val index = UInt(columnIndexBits.W)
}

class AccScalePipe[T <: Data, U <: Data](t: T, rDataType: Vec[Vec[T]], scale_func: (T, U) => T, scale_t: U,
                                         latency: Int, has_nonlinear_activations: Boolean, has_normalizations: Boolean,
                                         entryIdBits: Int, columnIndexBits: Int)
                                        (implicit ev: Arithmetic[T]) extends Module {
  val u = scale_t
  require(latency >= 3,
    "AccScalePipe needs at least three cycles for pre-activation, scaling, and output activation")
  val io = IO(new Bundle {
    val in = Input(Valid(new AccScaleDataWithIndex(t, u, entryIdBits, columnIndexBits)(ev)))
    val out = Output(Valid(new AccScaleDataWithIndex(t, u, entryIdBits, columnIndexBits)(ev)))
    val silu_lut = Input(Vec(256, UInt(8.W)))
  })
  import ev._

  // Stage 1: register the request and the pre-activation result. This cuts the
  // accumulator/normalizer read muxes away from the FP scale datapath.
  val s1_valid = RegNext(io.in.valid, false.B)
  val s1_bits = RegEnable(io.in.bits, io.in.valid)

  val e = io.in.bits.data
  val act = io.in.bits.act
  // make sure no normalizations gets passed in if no functional units present
  assert(has_normalizations.B || (!io.in.valid) ||
    (act =/= Activation.LAYERNORM && act =/= Activation.SOFTMAX && act =/= Activation.IGELU))

  val e_act: T = MuxCase(e, if (has_normalizations) Seq(
    (has_nonlinear_activations.B && act === Activation.RELU) -> e.relu,
    (has_nonlinear_activations.B && has_normalizations.B && act === Activation.LAYERNORM) ->
      (e - io.in.bits.mean),
    (has_nonlinear_activations.B && has_normalizations.B && act === Activation.IGELU) ->
      AccumulatorScale.igelu(e, io.in.bits.igelu_qb, io.in.bits.igelu_qc),
    (has_nonlinear_activations.B && has_normalizations.B && act === Activation.SOFTMAX) ->
      AccumulatorScale.iexp(e - io.in.bits.max, io.in.bits.iexp_qln2, io.in.bits.iexp_qln2_inv, io.in.bits.igelu_qb, io.in.bits.igelu_qc),
  ) else Seq(
    (has_nonlinear_activations.B && act === Activation.RELU) -> e.relu
  ))
  val s1_e_act = RegEnable(e_act, io.in.valid)

  // Stage 2: isolate the HardFloat integer-to-float, multiply and conversion
  // chain. All control fields are carried alongside the scaled value.
  val s2_valid = RegNext(s1_valid, false.B)
  val s2_bits = RegEnable(s1_bits, s1_valid)
  val s2_data = RegEnable(scale_func(s1_e_act, if (has_normalizations) MuxCase(s1_bits.scale, Seq(
    (has_nonlinear_activations.B && has_normalizations.B && s1_bits.act === Activation.LAYERNORM) ->
      s1_bits.inv_stddev,
    (has_nonlinear_activations.B && has_normalizations.B && s1_bits.act === Activation.SOFTMAX) ->
      s1_bits.inv_sum_exp.asTypeOf(scale_t)
  )).asTypeOf(scale_t) else s1_bits.scale.asTypeOf(scale_t)), s1_valid)

  // Stage 3: clip first, then apply the programmable SiLU table or LeakyReLU.
  // The table remains the existing Chisel implementation; no BRAM blackbox is
  // introduced here. The following trailing Pipe captures this combinational
  // activation result while preserving the original external latency.
  val s3_valid = RegNext(s2_valid, false.B)
  val s3_bits = RegEnable(s2_bits, s2_valid)
  val s3_clip = RegEnable(s2_data.clippedToWidthOf(rDataType.head.head), s2_valid)
  val e_silu = if (s3_clip.getWidth == 8) {
    io.silu_lut(s3_clip.asUInt).asTypeOf(s3_clip)
  } else {
    s3_clip
  }
  val e_clipped = MuxCase(s3_clip, Seq(
    (has_nonlinear_activations.B && s3_bits.act === Activation.LEAKY_RELU) ->
      Activation.leakyRelu(s3_clip),
    (has_nonlinear_activations.B && s3_bits.act === Activation.SILU_LUT) -> e_silu,
  ))

  val out = Wire(Valid(new AccScaleDataWithIndex(t, u, entryIdBits, columnIndexBits)(ev)))
  out.valid := s3_valid
  out.bits := s3_bits
  out.bits.data := e_clipped
  io.out := Pipe(out, latency - 3)
}


/** IPOAT：S01/S02 Scale 窗口与分块调度
 * I（Input 输入）：ACC 数据/scale/激活、输出 ready、窗口深度及 scheduler 参数。
 * P（Process 处理）：按所选调度器处理保有行；分块模式先预留最老待发块，返回结果按归属收集并按序退休。
 * O（Output 输出）：量化输出、原有返回元数据及可选性能计数；reset 清除有效状态。
 * A（Author 作者）：王志瑞
 * T（Time 时间）：2026-09-09（注释补充日期）
 */
class AccumulatorScale[T <: Data, U <: Data](
  fullDataType: Vec[Vec[T]], rDataType: Vec[Vec[T]],
  scale_t: U,
  read_small_data: Boolean, read_full_data: Boolean,
  scale_func: (T, U) => T,
  num_scale_units: Int,
  latency: Int,
  has_nonlinear_activations: Boolean, has_normalizations: Boolean,
  acc_scale_n_entries: Int = 3,
  acc_scale_scheduler: String = "legacy",
  acc_scale_perf_enable: Boolean = false)(implicit ev: Arithmetic[T]) extends Module {

  require(acc_scale_n_entries >= 1, "Scale window must contain at least one entry")
  require(num_scale_units == -1 || num_scale_units > 0, "Scale unit count must be positive or -1")
  require(num_scale_units == -1 || !has_normalizations || acc_scale_n_entries == 3,
    "Normalization window expansion requires separate validation; keep N=3")

  require(Set("legacy", "chunked_no_norm").contains(acc_scale_scheduler), "Unknown scale scheduler")
  require(acc_scale_scheduler != "chunked_no_norm" || (!has_normalizations && num_scale_units > 0),
    "chunked_no_norm requires finite scale units and normalization disabled")

  import ev._

  val rowWidth = fullDataType.size * fullDataType.head.size
  val perfLanes = if (num_scale_units == -1) rowWidth else num_scale_units
  val laneIssues = WireInit(VecInit(Seq.fill(perfLanes)(false.B)))
  /** IPOAT：AccScale lane 完成镜像
    * I（Input 输入）：每条 AccScalePipe 的 result.valid。
    * P（Process 处理）：与既有 laneIssues 对齐成只读完成 mask。
    * O（Output 输出）：诊断页中的 pipeline completion valid。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-17
    */
  val laneCompletions = WireInit(VecInit(Seq.fill(perfLanes)(false.B)))
  val windowFull = WireDefault(false.B)
  val io = IO(new AccumulatorScaleIO[T,U](
    fullDataType, scale_t, rDataType, if (acc_scale_perf_enable) perfLanes else 0
  )(ev))
  val t = io.in.bits.acc_read_resp.data(0)(0).cloneType
  val acc_read_data = io.in.bits.acc_read_resp.data
  val silu_lut = RegInit(VecInit((0 until 256).map(_.U(8.W))))
  when (io.silu_lut_write.valid) {
    assert(io.silu_lut_write.bits.base(2, 0) === 0.U)
    for (i <- 0 until 8) {
      silu_lut(io.silu_lut_write.bits.base + i.U) :=
        io.silu_lut_write.bits.data(8 * i + 7, 8 * i)
    }
  }
  val out = Wire(Decoupled(new AccumulatorScaleResp[T](
    fullDataType, rDataType)(ev)))
  io.deadlock_debug.foreach(_ := 0.U)

  if (num_scale_units == -1) {
    laneIssues.foreach(_ := io.in.fire)
    val data = io.in.bits.acc_read_resp.data
    val act = io.in.bits.acc_read_resp.act
    val igelu_qb = io.in.bits.acc_read_resp.igelu_qb
    val igelu_qc = io.in.bits.acc_read_resp.igelu_qc
    val iexp_qln2 = io.in.bits.acc_read_resp.iexp_qln2
    val iexp_qln2_inv = io.in.bits.acc_read_resp.iexp_qln2_inv
    val scale = io.in.bits.acc_read_resp.scale

    val activated_data = VecInit(data.map(v => VecInit(v.map { e =>
      val e_act = MuxCase(e, if (has_normalizations) Seq(
        (has_nonlinear_activations.B && act === Activation.RELU) -> e.relu,
        (has_nonlinear_activations.B && has_normalizations.B && act === Activation.LAYERNORM) ->
          (e - io.in.bits.mean),
        (has_nonlinear_activations.B && has_normalizations.B && act === Activation.IGELU) ->
          AccumulatorScale.igelu(e, igelu_qb, igelu_qc),
        (has_nonlinear_activations.B && has_normalizations.B && act === Activation.SOFTMAX) ->
          AccumulatorScale.iexp(e - io.in.bits.max, iexp_qln2, iexp_qln2_inv, igelu_qb, igelu_qc),
      ) else Seq(
        (has_nonlinear_activations.B && act === Activation.RELU) -> e.relu
      ))

      val e_scaled: T = scale_func(e_act, if (has_normalizations) MuxCase(scale, Seq(
        (has_nonlinear_activations.B && has_normalizations.B && act === Activation.LAYERNORM) ->
          io.in.bits.inv_stddev,
        (has_nonlinear_activations.B && has_normalizations.B && act === Activation.SOFTMAX) ->
          io.in.bits.inv_sum_exp.asTypeOf(scale_t)
      )).asTypeOf(scale_t) else scale.asTypeOf(scale_t))

      val e_clipped_pre_act = e_scaled.clippedToWidthOf(rDataType.head.head)
      val e_silu = if (e_clipped_pre_act.getWidth == 8) {
        silu_lut(e_clipped_pre_act.asUInt).asTypeOf(e_clipped_pre_act)
      } else {
        e_clipped_pre_act
      }
      val e_clipped = MuxCase(e_clipped_pre_act, Seq(
        (has_nonlinear_activations.B && act === Activation.LEAKY_RELU) ->
          Activation.leakyRelu(e_clipped_pre_act),
        (has_nonlinear_activations.B && act === Activation.SILU_LUT) -> e_silu,
      ))

      e_clipped
    })))

    val in = Wire(Decoupled(new AccumulatorReadRespWithFullData(fullDataType, scale_t)(ev)))
    in.valid := io.in.valid
    io.in.ready := in.ready
    in.bits.resp := io.in.bits.acc_read_resp
    in.bits.full_data := acc_read_data
    in.bits.resp.data := activated_data

    val pipe_out = Pipeline(in, latency)

    out.valid := pipe_out.valid
    pipe_out.ready := out.ready
    out.bits.full_data := pipe_out.bits.full_data
    out.bits.data      := pipe_out.bits.resp.data
    out.bits.fromDMA   := pipe_out.bits.resp.fromDMA
    out.bits.acc_bank_id := pipe_out.bits.resp.acc_bank_id
  } else {
    val width = acc_read_data.size * acc_read_data(0).size
    /** IPOAT
     * I（Input 输入）： compile-time window depth and physical accumulator row width.
     * P（Process 处理）： retain one-hot rotation and per-column completion for either scheduler.
     * O（Output 输出）： ordered rows; slots remain owned until out.fire, including backpressure.
     * A（Author 作者）：王志瑞
     * T（Time 时间）：2026-09-09（注释补充日期）
     */
    val nEntries = acc_scale_n_entries

    val entryIdBits = math.max(1, log2Ceil(nEntries))
    val columnIndexBits = math.max(1, log2Ceil(width))
    /*val regs = Reg(Vec(nEntries, Valid(new AccumulatorReadResp[T,U](
      fullDataType, scale_t)(ev))))*/
    val regs = Reg(Vec(nEntries, Valid(new NormalizedOutput[T,U](
      fullDataType, scale_t)(ev))))
    val out_regs = Reg(Vec(nEntries, new AccumulatorScaleResp[T](
      fullDataType, rDataType)(ev)))

    val fired_masks = Reg(Vec(nEntries, Vec(width, Bool())))
    val completed_masks = Reg(Vec(nEntries, Vec(width, Bool())))
    val head_oh = RegInit(1.U(nEntries.W))
    val tail_oh = RegInit(1.U(nEntries.W))
    windowFull := regs.map(_.valid).reduce(_ && _)
    out.valid := Mux1H(head_oh.asBools, (regs zip completed_masks).map({case (r, c) => r.valid && c.reduce(_&&_)}))
    out.bits  := Mux1H(head_oh.asBools, out_regs)
    when (out.fire) {
      for (i <- 0 until nEntries) {
        when (head_oh(i)) {
          regs(i).valid := false.B
        }
      }
      head_oh := (head_oh << 1).asUInt | head_oh(nEntries-1)
    }

    io.in.ready := !Mux1H(tail_oh.asBools, regs.map(_.valid)) || (tail_oh === head_oh && out.fire)
    when (io.in.fire) {
      for (i <- 0 until nEntries) {
        when (tail_oh(i)) {
          regs(i).valid := true.B
          regs(i).bits  := io.in.bits
          out_regs(i).fromDMA := io.in.bits.acc_read_resp.fromDMA
          out_regs(i).acc_bank_id := io.in.bits.acc_read_resp.acc_bank_id
          fired_masks(i).foreach(_ := false.B)
          completed_masks(i).foreach(_ := false.B)
        }
      }
      tail_oh := (tail_oh << 1).asUInt | tail_oh(nEntries-1)
    }

    if (acc_scale_scheduler == "chunked_no_norm") {
      /** IPOAT
       * I（Input 输入）： live entries, issued masks, ring head and fixed scale lane count.
       * P（Process 处理）： reserve the oldest pending row's first unissued chunk, then register
       *            its id/phase before local lane muxes. One reserved chunk enters the
       *            Valid-only arithmetic pipes next cycle; no result storage is released.
       * O（Output 输出）： at most U distinct columns per cycle, each owned until ordered out.fire.
       * A（Author 作者）：王志瑞
       * T（Time 时间）：2026-09-09（注释补充日期）
       */
      require(num_scale_units <= width, "chunked_no_norm requires at most one unit per column")
      val chunks = (width + num_scale_units - 1) / num_scale_units
      val chunkBits = math.max(1, log2Ceil(chunks))
      val pending = VecInit((0 until nEntries).map(e => regs(e).valid && !fired_masks(e).asUInt.andR))
      val headId = Wire(UInt(entryIdBits.W))
      headId := OHToUInt(head_oh)
      val byAge = (Cat(pending.asUInt, pending.asUInt) >> headId)(nEntries - 1, 0)
      val offset = Wire(UInt(entryIdBits.W))
      offset := PriorityEncoder(byAge)
      val unwrapped = headId +& offset
      val selectedId = Wire(UInt(entryIdBits.W))
      selectedId := Mux(unwrapped >= nEntries.U, unwrapped - nEntries.U, unwrapped)
      val chunkPending = VecInit((0 until chunks).map(c => !fired_masks(selectedId)(c * num_scale_units)))
      val selectedChunk = Wire(UInt(chunkBits.W))
      selectedChunk := PriorityEncoder(chunkPending.asUInt)
      val reserve = pending.asUInt.orR
      val dispatchValid = RegNext(reserve, false.B)
      val dispatchId = RegEnable(selectedId, reserve)
      val dispatchChunk = RegEnable(selectedChunk, reserve)
      val selectedRow = regs(dispatchId).bits.acc_read_resp

      for (e <- 0 until nEntries; c <- 0 until chunks) {
        when (reserve && selectedId === e.U && selectedChunk === c.U) {
          assert(regs(e).valid, "Scale chunk reservation requires a live row")
          for (w <- c * num_scale_units until math.min(width, (c + 1) * num_scale_units)) {
            assert(!fired_masks(e)(w), "Scale chunk column was already reserved")
            fired_masks(e)(w) := true.B
          }
        }
      }

      for (u <- 0 until num_scale_units) {
        val input = Wire(Valid(new AccScaleDataWithIndex(t, scale_t, entryIdBits, columnIndexBits)(ev)))
        val columns = (u until width by num_scale_units)
        val chunkSelect = (0 until columns.size).map(c => dispatchChunk === c.U)
        val element = Mux1H(chunkSelect, columns.map(w => selectedRow.data(w / acc_read_data.head.size)(w % acc_read_data.head.size)))
        input.valid := dispatchValid && dispatchChunk < columns.size.U
        input.bits := 0.U.asTypeOf(input.bits)
        input.bits.id := dispatchId
        input.bits.index := dispatchChunk * num_scale_units.U + u.U
        input.bits.data := element
        input.bits.full_data := element
        input.bits.scale := selectedRow.scale
        input.bits.act := selectedRow.act
        laneIssues(u) := input.valid
        val pipe = Module(new AccScalePipe(t, rDataType, scale_func, scale_t, latency,
          has_nonlinear_activations, false, entryIdBits, columnIndexBits))
        pipe.io.in := input
        pipe.io.silu_lut := silu_lut
        val result = pipe.io.out
        laneCompletions(u) := result.valid
        when (input.valid) {
          assert(dispatchId < nEntries.U && regs(dispatchId).valid, "Scale dispatch lost its owner")
        }
        when (result.valid) {
          assert(result.bits.id < nEntries.U && result.bits.index < width.U, "Scale completion out of range")
          assert(regs(result.bits.id).valid, "Scale completion has no live owner")
          assert(fired_masks(result.bits.id)(result.bits.index), "Scale completion was not reserved")
          assert(!completed_masks(result.bits.id)(result.bits.index), "Scale duplicate completion")
          assert(result.bits.index % num_scale_units.U === u.U, "Scale completion changed lane")
        }
        // Static per-column writers merge concurrent lane completions without vector overwrite.
        for (e <- 0 until nEntries; w <- columns) {
          when (result.valid && result.bits.id === e.U && result.bits.index === w.U) {
            out_regs(e).data(w / acc_read_data.head.size)(w % acc_read_data.head.size) := result.bits.data
            out_regs(e).full_data(w / acc_read_data.head.size)(w % acc_read_data.head.size) := result.bits.full_data
            completed_masks(e)(w) := true.B
          }
        }
      }
    } else {
      require(nEntries < 31, "Legacy policy uses an Int-sized 1 << N")
      val num_units_with_norm = if (has_normalizations) 4 else 0 // TODO: move to configs

      val inputs_norm = Seq.fill(width*nEntries) { Wire(Decoupled(new AccScaleDataWithIndex(t, scale_t, entryIdBits, columnIndexBits)(ev))) }
      val inputs_non_norm = Seq.fill(width*nEntries) { Wire(Decoupled(new AccScaleDataWithIndex(t, scale_t, entryIdBits, columnIndexBits)(ev))) }

      val norm_mask = regs.map(r => r.valid && (
        (r.bits.acc_read_resp.act === Activation.SOFTMAX) ||
        (r.bits.acc_read_resp.act === Activation.LAYERNORM) ||
        (r.bits.acc_read_resp.act === Activation.IGELU)
      ))

      // input: norm_mask
      // output: {b2, b1, b0} <-> b_i = whether entry i should use functional units with norm (1 = should)
      val static_assignment_policy = Wire(Vec(1 << nEntries, UInt(nEntries.W)))
      println("static policy for " + num_units_with_norm + " norm units:")
      for (i <- 0 until (1 << nEntries)) {
        val binaryString = String.format("%" + nEntries + "s", i.toBinaryString)
          .replace(' ', '0').toCharArray.toList
        val num_norm : Int = binaryString.count(_ == '1')
        val ratio_of_norm_entries = num_norm.toFloat / nEntries.toFloat
        val ratio_of_norm_units = num_units_with_norm.toFloat / num_scale_units.toFloat
        if (ratio_of_norm_entries >= ratio_of_norm_units) {
          // use norm units for all norm entries
          static_assignment_policy(i.U) := i.U
          println("input pattern " + binaryString.mkString("") + ": " + binaryString.mkString(""))
        } else {
          def flip_n_zeros (s: List[Char], n: Int): List[Char] = {
            if (s.nonEmpty) {
              if ((s.head == '0') && (n > 0))
                '1' :: flip_n_zeros(s.tail, n - 1)
              else
                s.head :: flip_n_zeros(s.tail, n)
            } else {
              assert(n == 0, "cannot flip " + n + " zeros in an empty string")
              List.empty
            }
          }
          val flippedString = flip_n_zeros(
            binaryString, Math.round(ratio_of_norm_units * nEntries) - num_norm)
          val flipped = Integer.parseInt(flippedString.mkString(""), 2)
          static_assignment_policy(i.U) := flipped.U
          println("input pattern " + binaryString.mkString("") + ": " + flipped.toBinaryString)
        }
      }

      //    val inputs = Seq.fill(width*nEntries) { Wire(Decoupled(new AccScaleDataWithIndex(t, scale_t, entryIdBits, columnIndexBits)(ev))) }
      val current_policy = Wire(UInt(nEntries.W))
      val norm_mask_int = Wire(UInt(nEntries.W))
      norm_mask_int := VecInit(norm_mask).asUInt
      dontTouch(norm_mask_int)
      current_policy := static_assignment_policy(norm_mask_int)


      for (i <- 0 until nEntries) {
        for (w <- 0 until width) {
          val input = inputs_norm(i*width+w)

          val acc_read_resp = regs(i).bits.acc_read_resp

          input.valid       := regs(i).valid && !fired_masks(i)(w) && /*norm_mask(i)*/ current_policy(i)
          input.bits.data   := acc_read_resp.data(w / acc_read_data(0).size)(w % acc_read_data(0).size)
          input.bits.full_data := acc_read_resp.data(w / acc_read_data(0).size)(w % acc_read_data(0).size)
          input.bits.scale  := acc_read_resp.scale
          input.bits.act    := acc_read_resp.act
          input.bits.igelu_qb := acc_read_resp.igelu_qb
          input.bits.igelu_qc := acc_read_resp.igelu_qc
          input.bits.iexp_qln2 := acc_read_resp.iexp_qln2
          input.bits.iexp_qln2_inv := acc_read_resp.iexp_qln2_inv
          input.bits.mean := regs(i).bits.mean
          input.bits.max := regs(i).bits.max
          input.bits.inv_stddev := regs(i).bits.inv_stddev
          input.bits.inv_sum_exp := regs(i).bits.inv_sum_exp
          input.bits.id := i.U
          input.bits.index := w.U
          if (num_units_with_norm == 0) {
            input.ready := false.B
          }
          when (input.fire) {
            fired_masks(i)(w) := true.B
          }
        }
      }

      for (i <- 0 until nEntries) {
        for (w <- 0 until width) {
          val input = inputs_non_norm(i*width+w)

          val acc_read_resp = regs(i).bits.acc_read_resp

          input.valid       := regs(i).valid && !fired_masks(i)(w) && (!current_policy(i))
          input.bits.data   := acc_read_resp.data(w / acc_read_data(0).size)(w % acc_read_data(0).size)
          input.bits.full_data := acc_read_resp.data(w / acc_read_data(0).size)(w % acc_read_data(0).size)
          input.bits.scale  := acc_read_resp.scale
          input.bits.act    := acc_read_resp.act
          input.bits.igelu_qb := DontCare
          input.bits.igelu_qc := DontCare
          input.bits.iexp_qln2 := DontCare
          input.bits.iexp_qln2_inv := DontCare
          input.bits.mean := DontCare
          input.bits.max := DontCare
          input.bits.inv_stddev := DontCare
          input.bits.inv_sum_exp := DontCare
          input.bits.id := i.U
          input.bits.index := w.U
          if (num_scale_units == num_units_with_norm) {
            input.ready := false.B
          }
          when (input.fire) {
            fired_masks(i)(w) := true.B
          }
        }
      }

      for (i <- 0 until num_scale_units) {
        val norm_supported = (i < num_units_with_norm) && has_normalizations

        val arbIn =
          if (norm_supported)
            // for norm units, prioritize norm operations
            inputs_norm.zipWithIndex.filter({ case (_, w) => w % num_units_with_norm == i }).map(_._1)
          else
            inputs_non_norm.zipWithIndex.filter({ case (_, w) => w % (num_scale_units - num_units_with_norm) == (i - num_units_with_norm) }).map(_._1)

        val arb = Module(new RRArbiter(new AccScaleDataWithIndex(t, scale_t, entryIdBits, columnIndexBits)(ev), arbIn.length))
        arb.io.in <> arbIn
        arb.io.out.ready := true.B
        val arbOut = Reg(Valid(new AccScaleDataWithIndex(t, scale_t, entryIdBits, columnIndexBits)(ev)))
        arbOut.valid := arb.io.out.valid
        arbOut.bits  := arb.io.out.bits
        when (reset.asBool) {
          arbOut.valid := false.B
        }
        val pipe = Module(new AccScalePipe(t, rDataType, scale_func, scale_t, latency,
              has_nonlinear_activations, norm_supported, entryIdBits, columnIndexBits))

        laneIssues(i) := arbOut.valid
        pipe.io.in := arbOut
        pipe.io.silu_lut := silu_lut
        val pipe_out = pipe.io.out
        laneCompletions(i) := pipe_out.valid
        when (pipe_out.valid) {
          assert(pipe_out.bits.id < nEntries.U, "Scale completion slot out of range")
          assert(pipe_out.bits.index < width.U, "Scale completion column out of range")
          assert(regs(pipe_out.bits.id).valid, "Scale completion has no live owner")
          assert(fired_masks(pipe_out.bits.id)(pipe_out.bits.index), "Scale completion was not issued")
          assert(!completed_masks(pipe_out.bits.id)(pipe_out.bits.index), "Scale duplicate completion")
        }

        for (j <- 0 until nEntries) {
          for (w <- 0 until width) {
            val id0 = w % acc_read_data(0).size
            val id1 = w / acc_read_data(0).size
              if (norm_supported && (j*width+w) % num_units_with_norm == i) {
                when (pipe_out.fire && pipe_out.bits.id === j.U && pipe_out.bits.index === w.U) {
                  out_regs(j).data     (id1)(id0) := pipe_out.bits.data
                  out_regs(j).full_data(id1)(id0) := pipe_out.bits.full_data
                  completed_masks(j)(w) := true.B
                }
              }
              if (num_scale_units > num_units_with_norm) {
                if ((j*width+w) % (num_scale_units - num_units_with_norm) == (i - num_units_with_norm)) {
                  val id0 = w % acc_read_data(0).size
                  val id1 = w / acc_read_data(0).size
                  when (pipe_out.fire && pipe_out.bits.id === j.U && pipe_out.bits.index === w.U) {
                    out_regs(j).data     (id1)(id0) := pipe_out.bits.data
                    out_regs(j).full_data(id1)(id0) := pipe_out.bits.full_data
                    completed_masks(j)(w) := true.B
                  }
                }
              }
          }
        }
      }
    }
    assert(PopCount(head_oh) === 1.U && PopCount(tail_oh) === 1.U,
      "Scale ring pointers must remain one-hot")
    when (io.in.fire && Mux1H(tail_oh.asBools, regs.map(_.valid))) {
      assert(out.fire && head_oh === tail_oh, "Scale reuse requires retirement of the old row")
    }
    when (reset.asBool) {
      regs.foreach(_.valid := false.B)
    }

    /** IPOAT：AccScale entry 生命周期快照
      * I（Input 输入）：各 entry valid、fired/completed mask、head/tail。
      * P（Process 处理）：每个 entry 压缩为元素计数，保留环形指针。
      * O（Output 输出）：页1窗口身份、页2发射计数、页3完成计数。
      * A（Author 作者）：王志瑞
      * T（Time 时间）：2026-09-17
      */
    val firedCounts = VecInit((0 until 3).map { i =>
      if (i < nEntries) PopCount(fired_masks(i)).pad(8) else 0.U(8.W)
    })
    val completedCounts = VecInit((0 until 3).map { i =>
      if (i < nEntries) PopCount(completed_masks(i)).pad(8) else 0.U(8.W)
    })
    val validMask = VecInit(regs.map(_.valid)).asUInt.pad(8)
    io.deadlock_debug(1) := Cat(0.U(40.W), validMask, tail_oh.pad(8), head_oh.pad(8))
    io.deadlock_debug(2) := Cat(0.U(40.W), firedCounts.asUInt)
    io.deadlock_debug(3) := Cat(0.U(40.W), completedCounts.asUInt)
  }

  io.out <> out

  /** IPOAT：AccScale 活性快照
    * I（Input 输入）：in/out 握手、lane issue/completion、windowFull。
    * P（Process 处理）：任一进展清零年龄，否则在活动窗口内饱和递增。
    * O（Output 输出）：页0 的活性、背压和管线 valid 证据。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-17
    */
  val debugCyclesSinceProgress = RegInit(0.U(32.W))
  when (io.in.fire || io.out.fire || laneIssues.asUInt.orR || laneCompletions.asUInt.orR) {
    debugCyclesSinceProgress := 0.U
  }.elsewhen ((io.in.valid || io.out.valid || windowFull) && debugCyclesSinceProgress =/= "hffffffff".U) {
    debugCyclesSinceProgress := debugCyclesSinceProgress + 1.U
  }
  io.deadlock_debug(0) := Cat(debugCyclesSinceProgress,
    laneCompletions.asUInt.pad(8)(7, 0), laneIssues.asUInt.pad(8)(7, 0),
    0.U(9.W), windowFull,
    io.out.fire, io.out.ready, io.out.valid,
    io.in.fire, io.in.ready, io.in.valid)

  /** IPOAT
   * I（Input 输入）： row fire/stall events and lane admissions into the arithmetic pipes.
   * P（Process 处理）： optional 64-bit counters; outstanding rows are input count minus output count.
   * O（Output 输出）： local performance observations, absent entirely when the parameter is false.
   * A（Author 作者）：王志瑞
   * T（Time 时间）：2026-09-09（注释补充日期）
   */
  io.perf.foreach { perf =>
    def count(event: Bool): UInt = {
      val value = RegInit(0.U(64.W))
      when (event) { value := value + 1.U }
      value
    }
    val inRows = count(io.in.fire)
    val outRows = count(io.out.fire)
    val occupancy = inRows - outRows
    val issued = RegInit(0.U(64.W))
    issued := issued + PopCount(laneIssues)
    val occupancySum = RegInit(0.U(64.W))
    occupancySum := occupancySum + occupancy
    val occupancyMax = RegInit(0.U(64.W))
    when (occupancy > occupancyMax) { occupancyMax := occupancy }
    perf.in_rows := inRows
    perf.out_rows := outRows
    perf.issued_elements := issued
    perf.issue_cycles := count(laneIssues.asUInt.orR)
    perf.all_lanes_cycles := count(laneIssues.asUInt.andR)
    perf.in_blocked_cycles := count(io.in.valid && !io.in.ready)
    perf.window_full_cycles := count(windowFull)
    perf.out_stall_cycles := count(io.out.valid && !io.out.ready)
    perf.occupancy_sum := occupancySum
    perf.occupancy_max := occupancyMax
    perf.lane_issues := laneIssues.asUInt
  }


  if (read_small_data)
    io.out.bits.data := out.bits.data
  else
    io.out.bits.data := DontCare

  if (read_full_data)
    io.out.bits.full_data := out.bits.full_data
  else
    io.out.bits.full_data := DontCare
}

object AccumulatorScale {
  def igelu[T <: Data](q: T, qb: T, qc: T)(implicit ev: Arithmetic[T]): T = {
    import ev._

    val zero = q.zero
    val one = q.identity
    def neg(x: T) = zero-x

    val q_sign = Mux(q.zero > q, neg(one), one)
    val q_abs = Mux(q.zero > q, neg(q), q)
    val q_clipped = Mux(q_abs > neg(qb), neg(qb), q_abs)
    val q_poly = qc.mac(q_clipped + qb, q_clipped + qb).withWidthOf(q)
    val q_erf = (q_sign * q_poly).withWidthOf(q)
    (q * (q_erf + qc)).withWidthOf(q)
  }

  def iexp[T <: Data](q: T, qln2: T, qln2_inv: T, qb: T, qc: T)(implicit ev: Arithmetic[T]): T = {
    /*
    import ev._

    val zero = q.zero
    def neg(x: T) = zero-x

    // qln2_inv needs scale to be 1 / (2 ** 16) / S
    // qln2_inv / S / (2 ** 16) = 1 / ln2
    // q * qln2_inv = x / S / ln2 * S * (2 ** 16) = x / ln2 * (2 ** 16)
    val neg_q_iexp = neg(q)
    val z_iexp = (neg_q_iexp * qln2_inv).asUInt.do_>>(16).asTypeOf(q) // q is non-positive
    val z_iexp_saturated = Wire(z_iexp.cloneType)
    z_iexp_saturated := Mux((5 until 16).map(z_iexp.asUInt(_)).reduce(_ | _), 32.S.asTypeOf(z_iexp), z_iexp)
    val qp_iexp = q.mac(z_iexp, qln2).withWidthOf(q)
    val q_poly_iexp = qc.mac(qp_iexp + qb, qp_iexp + qb).withWidthOf(q)
    // we dont want a rounding shift
    //  TODO: z overflow
    (q_poly_iexp.asUInt.do_>>(z_iexp_saturated.asUInt)).asTypeOf(q) */
    import ev._

    val zero = q.zero
    val one = q.identity
    def neg(x: T) = zero-x

    val q_sign = Mux(q.zero > q, neg(one), one)
    val q_abs = Mux(q.zero > q, neg(q), q)
    val q_clipped = Mux(q_abs > neg(qb), neg(qb), q_abs)
    val q_poly = qc.mac(q_clipped + qb, q_clipped + qb).withWidthOf(q)
    val q_erf = (q_sign * q_poly).withWidthOf(q)
    (q * (q_erf + qc)).withWidthOf(q)
  }}
