
package gemmini

import java.nio.charset.StandardCharsets
import java.nio.file.{Files, Paths}
import chisel3._
import chisel3.util._
import org.chipsalliance.cde.config._
import freechips.rocketchip.diplomacy._
import freechips.rocketchip.tile._
import freechips.rocketchip.util.{BundleField, ClockGate}
import freechips.rocketchip.tilelink._
import GemminiISA._
import Util._

class GemminiCmd(rob_entries: Int)(implicit p: Parameters) extends Bundle {
  val cmd = new RoCCCommand
  val rob_id = UDValid(UInt(log2Up(rob_entries).W))
  val from_matmul_fsm = Bool()
  val from_conv_fsm = Bool()
  /** IPOAT：V02 Gemmini 命令扩展
   * I（Input 输入）：来自 LoopConv 的 VI 描述符或原始 legacy 命令。
   * P（Process 处理）：在 GemminiCmd 内按值保存元数据，经原队列/RS 转交执行链。
   * O（Output 输出）：与命令生命周期一致的 virtualI 字段，原始命令置无效。
   * A（Author 作者）：王志瑞
   * T（Time 时间）：2026-09-09（注释补充日期）
   */
  val virtualI = new VirtualICommand
}

class Gemmini[T <: Data : Arithmetic, U <: Data, V <: Data](val config: GemminiArrayConfig[T, U, V])
                                     (implicit p: Parameters)
  extends LazyRoCC (
    opcodes = config.opcodes,
    nPTWPorts = if (config.use_shared_tlb) 1 else 2,
    // （Author 作者：王志瑞）：保持 busy CSR 在前的既有 ABI；credit status 使用完整宽度的
    // 独立只读观测 CSR，不能复用 1-bit busy CSR。
    roccCSRs = config.busyCsrId.toSeq.map(id =>
      CustomCSR(id, mask = BigInt(1), init = Some(BigInt(0)))) ++
      config.loopConvStatusCsrId.toSeq.map(id =>
        CustomCSR(id, mask = (BigInt(1) << p(TileKey).core.xLen) - 1, init = Some(BigInt(0)))) ++
      // （Author 作者：王志瑞）：debug counters 必须进入 CSR fanout，否则未被消费的 Scala Reg
      // 会在生成 RTL 时被优化掉，板上无法验证 accepted-retired==outstanding。
      config.loopConvAcceptedCsrId.toSeq.map(id =>
        CustomCSR(id, mask = (BigInt(1) << p(TileKey).core.xLen) - 1, init = Some(BigInt(0)))) ++
      config.loopConvRetiredCsrId.toSeq.map(id =>
        CustomCSR(id, mask = (BigInt(1) << p(TileKey).core.xLen) - 1, init = Some(BigInt(0)))) ++
      // （Author 作者：王志瑞）：记录器使用独立 CSR，不复用 busy CSR 0x7c2。
      config.loopConvTraceControlCsrId.toSeq.map(id =>
        CustomCSR(id, mask = (BigInt(1) << p(TileKey).core.xLen) - 1, init = Some(BigInt(0)))) ++
      config.loopConvTraceStatusCsrId.toSeq.map(id =>
        CustomCSR(id, mask = (BigInt(1) << p(TileKey).core.xLen) - 1, init = Some(BigInt(0)))) ++
      config.loopConvTraceSelectCsrId.toSeq.map(id =>
        CustomCSR(id, mask = (BigInt(1) << p(TileKey).core.xLen) - 1, init = Some(BigInt(0)))) ++
      config.loopConvTraceDataCsrId.toSeq.map(id =>
        CustomCSR(id, mask = (BigInt(1) << p(TileKey).core.xLen) - 1, init = Some(BigInt(0)))) ++
      /** IPOAT：死锁诊断 CSR 注册
        * I（Input 输入）：配置中的 control/status/select/data CSR 编号。
        * P（Process 处理）：按既有 CSR 顺序追加四个 64-bit 自定义 CSR。
        * O（Output 输出）：Controller module 可读写的独立诊断窗口。
        * A（Author 作者）：王志瑞
        * T（Time 时间）：2026-09-17
        */
      config.deadlockDebugControlCsrId.toSeq.map(id =>
        CustomCSR(id, mask = (BigInt(1) << p(TileKey).core.xLen) - 1, init = Some(BigInt(0)))) ++
      config.deadlockDebugStatusCsrId.toSeq.map(id =>
        CustomCSR(id, mask = (BigInt(1) << p(TileKey).core.xLen) - 1, init = Some(BigInt(0)))) ++
      config.deadlockDebugSelectCsrId.toSeq.map(id =>
        CustomCSR(id, mask = (BigInt(1) << p(TileKey).core.xLen) - 1, init = Some(BigInt(0)))) ++
      config.deadlockDebugDataCsrId.toSeq.map(id =>
        CustomCSR(id, mask = (BigInt(1) << p(TileKey).core.xLen) - 1, init = Some(BigInt(0))))) {

  Files.write(Paths.get(config.headerFilePath), config.generateHeader().getBytes(StandardCharsets.UTF_8))
  if (System.getenv("GEMMINI_ONLY_GENERATE_GEMMINI_H") == "1") {
    System.exit(1)
  }

  val xLen = p(TileKey).core.xLen
  val spad = LazyModule(new Scratchpad(config))

  val use_ext_tl_mem = config.use_shared_ext_mem && config.use_tl_ext_mem
  val num_ids = 32 // TODO (richard): move to config
  val spad_base = config.tl_ext_mem_base
  val spad_data_len = config.sp_width / 8
  val acc_data_len = config.sp_width / config.inputType.getWidth * config.accType.getWidth / 8
  val max_data_len = spad_data_len // max acc_data_len

  val mem_depth = config.sp_bank_entries * spad_data_len / max_data_len
  val mem_width = max_data_len
  println(f"unified shared memory size: ${mem_depth}x${mem_width}x${config.sp_banks}")

  // make scratchpad read and write clients, per bank
  //    _____  ________  _______  ___   ___
  //   / __/ |/_/_  __/ / __/ _ \/ _ | / _ \
  //  / _/_>  <  / /   _\ \/ ___/ __ |/ // /
  // /___/_/|_| /_/   /___/_/  /_/ |_/____/
  // ***************************************
  // HOW TO USE EXTERNAL SCRATCHPAD:
  // the scratchpad MUST BE INSTANTIATED ELSEWHERE if use_ext_tl_mem is enabled,
  // else elaboration will not pass. the scratchpad needs to be dual ported
  // and must be able to serve the entire scratchpad row (config.sp_width) in 1 cycle.
  // three nodes must be hooked up correctly: spad_read_nodes, spad_write_nodes, and spad.spad_writer.node
  // for deadlock avoidance, read and write should not be sharing a single channel anywhere until the SRAMs.
  // see RadianceCluster.scala for an example
  val spad_read_nodes = if (use_ext_tl_mem) TLClientNode(Seq.tabulate(config.sp_banks) {i =>
    TLMasterPortParameters.v1(Seq(TLMasterParameters.v1(
      name = s"spad_read_node_$i",
      sourceId = IdRange(0, num_ids),
      visibility = Seq(AddressSet(spad_base + i * mem_width * mem_depth, mem_width * mem_depth - 1)),
      supportsProbe = TransferSizes(mem_width, mem_width),
      supportsGet = TransferSizes(mem_width, mem_width)
    )))
  }) else TLIdentityNode()

  val spad_write_nodes = if (use_ext_tl_mem) TLClientNode(Seq.tabulate(config.sp_banks) { i =>
    TLMasterPortParameters.v1(Seq(TLMasterParameters.v1(
      name = s"spad_write_node_$i",
      sourceId = IdRange(0, num_ids),
      visibility = Seq(AddressSet(spad_base + i * mem_width * mem_depth, mem_width * mem_depth - 1)),
      supportsProbe = TransferSizes(mem_width, mem_width),
      supportsPutFull = TransferSizes(mem_width, mem_width),
      supportsPutPartial = TransferSizes(mem_width, mem_width)
    )))
  }) else TLIdentityNode()

  // val acc_read_nodes = if (create_tl_mem) TLClientNode(Seq.tabulate(config.acc_banks) { i =>
  //   TLMasterPortParameters.v1(Seq(TLMasterParameters.v1(name = s"acc_read_node_$i", sourceId = IdRange(0, numIDs))))
  // }) else TLIdentityNode()
  // val acc_write_nodes = if (create_tl_mem) TLClientNode(Seq.tabulate(config.acc_banks) { i =>
  //   TLMasterPortParameters.v1(Seq(TLMasterParameters.v1(name = s"acc_write_node_$i", sourceId = IdRange(0, numIDs))))
  // }) else TLIdentityNode()

  override lazy val module = new GemminiModule(this)
  override val tlNode = if (config.use_dedicated_tl_port) spad.id_node else TLIdentityNode()
  override val atlNode = if (config.use_dedicated_tl_port) TLIdentityNode() else spad.id_node

  val node = if (config.use_dedicated_tl_port) tlNode else atlNode
}

class GemminiModule[T <: Data: Arithmetic, U <: Data, V <: Data]
    (outer: Gemmini[T, U, V])
    extends LazyRoCCModuleImp(outer)
    with HasCoreParameters {

  import outer.config._
  import outer.spad

  val ext_mem_io = if (use_shared_ext_mem && !use_tl_ext_mem)
    Some(IO(new ExtSpadMemIO(sp_banks, acc_banks, acc_sub_banks))) else None

  if (outer.use_ext_tl_mem) {
    val ext_mem_spad = outer.spad.module.io.ext_mem.get.spad
    val ext_mem_acc = outer.spad.module.io.ext_mem.get.acc
    val source_counters = Seq.fill(4)(Counter(outer.num_ids))

    def connect(ext_mem: ExtMemIO, bank_base: Int, req_size: Int, r_node: TLBundle, r_edge: TLEdgeOut, r_source: Counter,
                w_node: TLBundle, w_edge: TLEdgeOut, w_source: Counter): Unit = {
      r_node.a.valid := ext_mem.read_req.valid
      r_node.a.bits := r_edge.Get(r_source.value,
        (ext_mem.read_req.bits << req_size.U).asUInt | bank_base.U | outer.spad_base.U,
        req_size.U)._2
      ext_mem.read_req.ready := r_node.a.ready

      val w_shifted_addr = (ext_mem.write_req.bits.addr << req_size.U).asUInt
      val w_mask = (ext_mem.write_req.bits.mask << (w_shifted_addr & (w_edge.manager.beatBytes - 1).U)).asUInt

      w_node.a.valid := ext_mem.write_req.valid
      w_node.a.bits := w_edge.Put(w_source.value,
        w_shifted_addr | bank_base.U | outer.spad_base.U,
        req_size.U, ext_mem.write_req.bits.data, w_mask)._2
      ext_mem.write_req.ready := w_node.a.ready

      ext_mem.read_resp.valid := r_node.d.valid
      ext_mem.read_resp.bits := r_node.d.bits.data
      r_node.d.ready := ext_mem.read_resp.ready

      w_node.d.ready := true.B // writes are not acknowledged in gemmini

      when(ext_mem.read_req.fire) { r_source.inc() }
      when(ext_mem.write_req.fire) { w_source.inc() }
    }
    (outer.spad_read_nodes.out zip outer.spad_write_nodes.out)
      .zipWithIndex.foreach{ case (((r_node, r_edge), (w_node, w_edge)), i) =>
        connect(ext_mem_spad(i), i * outer.mem_depth * outer.mem_width, log2Up(outer.spad_data_len),
          r_node, r_edge, source_counters(0), w_node, w_edge, source_counters(1))
    }


    ext_mem_acc.foreach(_.foreach(x => {
      x.read_resp.bits := 0.U(1.W)
      x.read_resp.valid := false.B
      x.read_req.ready := false.B
      x.write_req.ready := false.B
    }))
    // (outer.acc_read_nodes.out zip outer.acc_write_nodes.out)
    //   .zipWithIndex.foreach { case (((r_node, r_edge), (w_node, w_edge)), i) =>
    //     // TODO (richard): one subbank only for now
    //     connect(ext_mem_acc(i)(0), log2Up(outer.acc_data_len),
    //       r_node, r_edge, source_counters(2), w_node, w_edge, source_counters(3))
    // }
  } else if (use_shared_ext_mem) {
    ext_mem_io.foreach(_ <> outer.spad.module.io.ext_mem.get)
  }

  val tagWidth = 32

  // Counters
  val counters = Module(new CounterController(outer.config.num_counter, outer.xLen))
  io.resp <> counters.io.out  // Counter access command will be committed immediately
  counters.io.event_io.external_values(0) := 0.U
  counters.io.event_io.event_signal(0) := false.B
  counters.io.in.valid := false.B
  counters.io.in.bits := DontCare
  counters.io.event_io.collect(spad.module.io.counter)

  // TLB
  implicit val edge = outer.spad.id_node.edges.out.head
  val tlb = Module(new FrontendTLB(if (outer.config.use_tl_ext_mem) 3 else 2,
    tlb_size, dma_maxbytes, use_tlb_register_filter, use_firesim_simulation_counters, use_shared_tlb))
  (tlb.io.clients zip outer.spad.module.io.tlb).foreach(t => t._1 <> t._2)

  tlb.io.exp.foreach(_.flush_skip := false.B)
  tlb.io.exp.foreach(_.flush_retry := false.B)

  io.ptw <> tlb.io.ptw

  counters.io.event_io.collect(tlb.io.counter)

  spad.module.io.flush := tlb.io.exp.map(_.flush()).reduce(_ || _)

  val clock_en_reg = RegInit(true.B)
  val gated_clock = if (clock_gate) ClockGate(clock, clock_en_reg, "gemmini_clock_gate") else clock
  outer.spad.module.clock := gated_clock

  /*
  //=========================================================================
  // Frontends: Incoming commands and ROB
  //=========================================================================

  // forward cmd to correct frontend. if the rob is busy, do not forward new
  // commands to tiler, and vice versa
  val is_cisc_mode = RegInit(false.B)

  val raw_cmd = Queue(io.cmd)
  val funct = raw_cmd.bits.inst.funct

  val is_cisc_funct = (funct === CISC_CONFIG) ||
                      (funct === ADDR_AB) ||
                      (funct === ADDR_CD) ||
                      (funct === SIZE_MN) ||
                      (funct === SIZE_K) ||
                      (funct === RPT_BIAS) ||
                      (funct === RESET) ||
                      (funct === COMPUTE_CISC)

  val raw_cisc_cmd = WireInit(raw_cmd)
  val raw_risc_cmd = WireInit(raw_cmd)
  raw_cisc_cmd.valid := false.B
  raw_risc_cmd.valid := false.B
  raw_cmd.ready := false.B

  //-------------------------------------------------------------------------
  // cisc
  val cmd_fsm = CmdFSM(outer.config)
  cmd_fsm.io.cmd <> raw_cisc_cmd
  val tiler = TilerController(outer.config)
  tiler.io.cmd_in <> cmd_fsm.io.tiler

  //-------------------------------------------------------------------------
  // risc
  val unrolled_cmd = LoopUnroller(raw_risc_cmd, outer.config.meshRows * outer.config.tileRows)
  */

  val reservation_station = withClock (gated_clock) { Module(new ReservationStation(outer.config, new GemminiCmd(reservation_station_entries))) }
  counters.io.event_io.collect(reservation_station.io.counter)

  when (io.cmd.valid && io.cmd.bits.inst.funct === CLKGATE_EN && !io.busy) {
    clock_en_reg := io.cmd.bits.rs1(0)
  }

  val raw_cmd_q = Module(new Queue(new GemminiCmd(reservation_station_entries), entries = 2))
  raw_cmd_q.io.enq.valid := io.cmd.valid
  io.cmd.ready := raw_cmd_q.io.enq.ready
  raw_cmd_q.io.enq.bits.cmd := io.cmd.bits
  raw_cmd_q.io.enq.bits.rob_id := DontCare
  raw_cmd_q.io.enq.bits.from_conv_fsm := false.B
  raw_cmd_q.io.enq.bits.from_matmul_fsm := false.B
  raw_cmd_q.io.enq.bits.virtualI := 0.U.asTypeOf(new VirtualICommand)

  val raw_cmd = raw_cmd_q.io.deq

  val max_lds = reservation_station_entries_ld
  val max_exs = reservation_station_entries_ex
  val max_sts = reservation_station_entries_st

  /** IPOAT：V02/V03 顶层配置接线
   * I（Input 输入）：静态 VI enable/cross_row 配置、原始命令与完成反馈。
   * P（Process 处理）：将开关传入 LoopConv，沿用既有仲裁、完成和 credit 接线。
   * O（Output 输出）：卷积展开命令及其 VI 元数据；两个开关默认关闭。
   * A（Author 作者）：王志瑞
   * T（Time 时间）：2026-09-09（注释补充日期）
   */
  /** IPOAT：LoopConv 诊断页接入
    * I（Input 输入）：LoopConv 原有命令/完成接口及四个只读诊断页。
    * P（Process 处理）：在保持原六类行为信号不变的同时透传诊断 Vec。
    * O（Output 输出）：供下方 CSR 快照汇聚的 loop_conv_deadlock_debug。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-17
    */
  val (conv_cmd, loop_conv_unroller_busy, loop_conv_request_retire, loop_conv_running_slots, loop_conv_ld_weight_trace, loop_conv_deadlock_debug) = if (has_loop_conv) withClock (gated_clock) { LoopConv(raw_cmd, reservation_station.io.conv_ld_completed, reservation_station.io.conv_st_completed, reservation_station.io.conv_ex_completed,
    meshRows*tileRows, coreMaxAddrBits, reservation_station_entries, max_lds, max_exs, max_sts, sp_banks * sp_bank_entries, acc_banks * acc_bank_entries,
    inputType.getWidth, accType.getWidth, dma_maxbytes,
    new ConfigMvinRs1(mvin_scale_t_bits, block_stride_bits, pixel_repeats_bits), new MvinRs2(mvin_rows_bits, mvin_cols_bits, local_addr_t),
    new ConfigMvoutRs2(acc_scale_t_bits, 32), new MvoutRs2(mvout_rows_bits, mvout_cols_bits, local_addr_t),
    new ConfigExRs1(acc_scale_t_bits), new PreloadRs(mvin_rows_bits, mvin_cols_bits, local_addr_t),
    new PreloadRs(mvout_rows_bits, mvout_cols_bits, local_addr_t),
    new ComputeRs(mvin_rows_bits, mvin_cols_bits, local_addr_t), new ComputeRs(mvin_rows_bits, mvin_cols_bits, local_addr_t),
    has_training_convs, has_max_pool, has_first_layer_optimizations, has_dw_convs, virtual_i_enable, virtual_i_cross_row) }
  else (raw_cmd, false.B, false.B, 0.U(2.W), 0.U.asTypeOf(Valid(new LoopConvTraceEvent)),
    0.U.asTypeOf(Vec(26, UInt(64.W))))

  val (loop_cmd, loop_matmul_unroller_busy, loop_completed) = withClock (gated_clock) { LoopMatmul(if (has_loop_conv) conv_cmd else raw_cmd, reservation_station.io.matmul_ld_completed, reservation_station.io.matmul_st_completed, reservation_station.io.matmul_ex_completed,
    meshRows*tileRows, coreMaxAddrBits, reservation_station_entries, max_lds, max_exs, max_sts, sp_banks * sp_bank_entries, acc_banks * acc_bank_entries,
    inputType.getWidth, accType.getWidth, dma_maxbytes, new MvinRs2(mvin_rows_bits, mvin_cols_bits, local_addr_t),
    new PreloadRs(mvin_rows_bits, mvin_cols_bits, local_addr_t), new PreloadRs(mvout_rows_bits, mvout_cols_bits, local_addr_t),
    new ComputeRs(mvin_rows_bits, mvin_cols_bits, local_addr_t), new ComputeRs(mvin_rows_bits, mvin_cols_bits, local_addr_t),
    new MvoutSpadRs1(32, local_addr_t), new MvoutRs2(mvout_rows_bits, mvout_cols_bits, local_addr_t)) }

  val unrolled_cmd = Queue(loop_cmd)
  unrolled_cmd.ready := false.B
  counters.io.event_io.connectEventSignal(CounterEvent.LOOP_MATMUL_ACTIVE_CYCLES, loop_matmul_unroller_busy)

  // Wire up controllers to ROB
  reservation_station.io.alloc.valid := false.B
  reservation_station.io.alloc.bits := unrolled_cmd.bits

  val completion_io = IO(new Bundle {
    val completed = Output(loop_completed.cloneType)
  })

  completion_io.completed := loop_completed

  /*
  //-------------------------------------------------------------------------
  // finish muxing control signals to rob (risc) or tiler (cisc)
  when (raw_cmd.valid && is_cisc_funct && !rob.io.busy) {
    is_cisc_mode       := true.B
    raw_cisc_cmd.valid := true.B
    raw_cmd.ready      := raw_cisc_cmd.ready
  }
  .elsewhen (raw_cmd.valid && !is_cisc_funct && !tiler.io.busy) {
    is_cisc_mode       := false.B
    raw_risc_cmd.valid := true.B
    raw_cmd.ready      := raw_risc_cmd.ready
  }
  */

  //=========================================================================
  // Controllers
  //=========================================================================
  val load_controller = withClock (gated_clock) { Module(new LoadController(outer.config, coreMaxAddrBits, local_addr_t)) }
  val store_controller = withClock (gated_clock) { Module(new StoreController(outer.config, coreMaxAddrBits, local_addr_t)) }
  val ex_controller = withClock (gated_clock) { Module(new ExecuteController(xLen, tagWidth, outer.config)) }

  counters.io.event_io.collect(load_controller.io.counter)
  counters.io.event_io.collect(store_controller.io.counter)
  counters.io.event_io.collect(ex_controller.io.counter)

  /*
  tiler.io.issue.load.ready := false.B
  tiler.io.issue.store.ready := false.B
  tiler.io.issue.exec.ready := false.B
  */

  reservation_station.io.issue.ld.ready := false.B
  reservation_station.io.issue.st.ready := false.B
  reservation_station.io.issue.ex.ready := false.B

  /*
  when (is_cisc_mode) {
    load_controller.io.cmd  <> tiler.io.issue.load
    store_controller.io.cmd <> tiler.io.issue.store
    ex_controller.io.cmd  <> tiler.io.issue.exec
  }
  .otherwise {
    load_controller.io.cmd.valid := rob.io.issue.ld.valid
    rob.io.issue.ld.ready := load_controller.io.cmd.ready
    load_controller.io.cmd.bits.cmd := rob.io.issue.ld.cmd
    load_controller.io.cmd.bits.cmd.inst.funct := rob.io.issue.ld.cmd.inst.funct
    load_controller.io.cmd.bits.rob_id.push(rob.io.issue.ld.rob_id)

    store_controller.io.cmd.valid := rob.io.issue.st.valid
    rob.io.issue.st.ready := store_controller.io.cmd.ready
    store_controller.io.cmd.bits.cmd := rob.io.issue.st.cmd
    store_controller.io.cmd.bits.cmd.inst.funct := rob.io.issue.st.cmd.inst.funct
    store_controller.io.cmd.bits.rob_id.push(rob.io.issue.st.rob_id)

    ex_controller.io.cmd.valid := rob.io.issue.ex.valid
    rob.io.issue.ex.ready := ex_controller.io.cmd.ready
    ex_controller.io.cmd.bits.cmd := rob.io.issue.ex.cmd
    ex_controller.io.cmd.bits.cmd.inst.funct := rob.io.issue.ex.cmd.inst.funct
    ex_controller.io.cmd.bits.rob_id.push(rob.io.issue.ex.rob_id)
  }
  */

  load_controller.io.cmd.valid := reservation_station.io.issue.ld.valid
  reservation_station.io.issue.ld.ready := load_controller.io.cmd.ready
  load_controller.io.cmd.bits := reservation_station.io.issue.ld.cmd
  load_controller.io.cmd.bits.rob_id.push(reservation_station.io.issue.ld.rob_id)

  store_controller.io.cmd.valid := reservation_station.io.issue.st.valid
  reservation_station.io.issue.st.ready := store_controller.io.cmd.ready
  store_controller.io.cmd.bits := reservation_station.io.issue.st.cmd
  store_controller.io.cmd.bits.rob_id.push(reservation_station.io.issue.st.rob_id)

  ex_controller.io.cmd.valid := reservation_station.io.issue.ex.valid
  reservation_station.io.issue.ex.ready := ex_controller.io.cmd.ready
  ex_controller.io.cmd.bits := reservation_station.io.issue.ex.cmd
  ex_controller.io.cmd.bits.rob_id.push(reservation_station.io.issue.ex.rob_id)

  // Wire up scratchpad to controllers
  spad.module.io.dma.read <> load_controller.io.dma
  spad.module.io.dma.write <> store_controller.io.dma
  spad.module.io.silu_lut_write := store_controller.io.silu_lut_write
  ex_controller.io.srams.read <> spad.module.io.srams.read
  ex_controller.io.srams.write <> spad.module.io.srams.write
  spad.module.io.acc.read_req <> ex_controller.io.acc.read_req
  ex_controller.io.acc.read_resp <> spad.module.io.acc.read_resp
  ex_controller.io.acc.write <> spad.module.io.acc.write

  // Im2Col unit
  val im2col = withClock (gated_clock) { Module(new Im2Col(outer.config)) }

  // Wire up Im2col
  counters.io.event_io.collect(im2col.io.counter)
  // im2col.io.sram_reads <> spad.module.io.srams.read
  im2col.io.req <> ex_controller.io.im2col.req
  ex_controller.io.im2col.resp <> im2col.io.resp

  // Wire arbiter for ExecuteController and Im2Col scratchpad reads
  (ex_controller.io.srams.read, im2col.io.sram_reads, spad.module.io.srams.read).zipped.foreach { case (ex_read, im2col_read, spad_read) =>
    val req_arb = Module(new Arbiter(new ScratchpadReadReq(n=sp_bank_entries), 2))

    req_arb.io.in(0) <> ex_read.req
    req_arb.io.in(1) <> im2col_read.req

    spad_read.req <> req_arb.io.out

    // TODO if necessary, change how the responses are handled when fromIm2Col is added to spad read interface

    ex_read.resp.valid := spad_read.resp.valid
    im2col_read.resp.valid := spad_read.resp.valid

    ex_read.resp.bits := spad_read.resp.bits
    im2col_read.resp.bits := spad_read.resp.bits

    spad_read.resp.ready := ex_read.resp.ready || im2col_read.resp.ready
  }

  // Wire up controllers to ROB
  reservation_station.io.alloc.valid := false.B
  // rob.io.alloc.bits := compressed_cmd.bits
  reservation_station.io.alloc.bits := unrolled_cmd.bits

  /*
  //=========================================================================
  // committed insn return path to frontends
  //=========================================================================

  //-------------------------------------------------------------------------
  // cisc
  tiler.io.completed.exec.valid := ex_controller.io.completed.valid
  tiler.io.completed.exec.bits := ex_controller.io.completed.bits

  tiler.io.completed.load <> load_controller.io.completed
  tiler.io.completed.store <> store_controller.io.completed

  // mux with cisc frontend arbiter
  tiler.io.completed.exec.valid  := ex_controller.io.completed.valid && is_cisc_mode
  tiler.io.completed.load.valid  := load_controller.io.completed.valid && is_cisc_mode
  tiler.io.completed.store.valid := store_controller.io.completed.valid && is_cisc_mode
  */

  //-------------------------------------------------------------------------
  // risc
  val reservation_station_completed_arb = Module(new Arbiter(UInt(log2Up(reservation_station_entries).W), 3))

  reservation_station_completed_arb.io.in(0).valid := ex_controller.io.completed.valid
  reservation_station_completed_arb.io.in(0).bits := ex_controller.io.completed.bits

  reservation_station_completed_arb.io.in(1) <> load_controller.io.completed
  reservation_station_completed_arb.io.in(2) <> store_controller.io.completed

  // mux with cisc frontend arbiter
  reservation_station_completed_arb.io.in(0).valid := ex_controller.io.completed.valid // && !is_cisc_mode
  reservation_station_completed_arb.io.in(1).valid := load_controller.io.completed.valid // && !is_cisc_mode
  reservation_station_completed_arb.io.in(2).valid := store_controller.io.completed.valid // && !is_cisc_mode

  reservation_station.io.completed.valid := reservation_station_completed_arb.io.out.valid
  reservation_station.io.completed.bits := reservation_station_completed_arb.io.out.bits
  reservation_station_completed_arb.io.out.ready := true.B

  /** IPOAT：Controller 完成源历史账本
    * I（Input 输入）：EX/LD/ST completion 与最终 completion arb 的实际事件及 ROB tag。
    * P（Process 处理）：逐源锁存最后 tag 并累计低 8 位事件数，冻结时保留长期历史。
    * O（Output 输出）：即使完成脉冲早于死锁快照，也能核对哪一路停止回传。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-19
    */
  val debugCompletionLastTag = RegInit(VecInit(Seq.fill(4)(0.U(8.W))))
  val debugCompletionCount = RegInit(VecInit(Seq.fill(4)(0.U(8.W))))
  val debugCompletionEvents = Seq(ex_controller.io.completed.valid,
    load_controller.io.completed.fire, store_controller.io.completed.fire,
    reservation_station_completed_arb.io.out.fire)
  val debugCompletionTags = Seq(ex_controller.io.completed.bits,
    load_controller.io.completed.bits, store_controller.io.completed.bits,
    reservation_station_completed_arb.io.out.bits)
  for (i <- 0 until 4) {
    when (debugCompletionEvents(i)) {
      debugCompletionLastTag(i) := debugCompletionTags(i)
      debugCompletionCount(i) := debugCompletionCount(i) + 1.U
    }
  }

  // Wire up global RoCC signals
  val gemminiBusy = raw_cmd.valid || loop_conv_unroller_busy || loop_matmul_unroller_busy || reservation_station.io.busy || spad.module.io.busy || unrolled_cmd.valid || loop_cmd.valid || conv_cmd.valid
  io.busy := gemminiBusy

  // （Input 输入；Author 作者：王志瑞）：credit 以完整 request 的 ingress accept 和 LoopConv slot 实际
  // retire 为唯一账本事件。不能用 busy、packet dequeue 或 sub-engine completed，否则会
  // 在资源尚未释放时错误地允许下一条 CONFIG1 进入。
  val loopConvAcceptedCount = RegInit(0.U(32.W))
  val loopConvRetiredCount = RegInit(0.U(32.W))
  val loopConvOutstandingCount = RegInit(0.U(4.W))
  val loopConvCreditOverflow = RegInit(false.B)
  val loopConvCreditUnderflow = RegInit(false.B)
  val loopConvRequestAccept = io.loopconv_request_accept && has_loop_conv.B
  val loopConvRequestRetire = loop_conv_request_retire && has_loop_conv.B
  val loopConvAcceptOnly = loopConvRequestAccept && !loopConvRequestRetire
  val loopConvRetireOnly = loopConvRequestRetire && !loopConvRequestAccept
  // （Author 作者：王志瑞）：SAFE_MAX 是 admission 上界；到达 SAFE_MAX 后若没有同拍 retire，
  // 任何 accept 都是 credit overflow。计数器物理饱和与 admission overflow 是两个概念。
  val loopConvOverflowViolation = loopConvAcceptOnly &&
    loopConvOutstandingCount >= loopConvSafeMax.U
  val loopConvUnderflowViolation = loopConvRetireOnly &&
    loopConvOutstandingCount === 0.U

  when (loopConvRequestAccept) {
    loopConvAcceptedCount := loopConvAcceptedCount + 1.U
  }
  when (loopConvRequestRetire) {
    loopConvRetiredCount := loopConvRetiredCount + 1.U
  }

  switch (Cat(loopConvRequestAccept, loopConvRequestRetire)) {
    is ("b10".U) {
      when (loopConvOutstandingCount =/= 15.U) {
        loopConvOutstandingCount := loopConvOutstandingCount + 1.U
      }
    }
    is ("b01".U) {
      when (loopConvOutstandingCount =/= 0.U) {
        loopConvOutstandingCount := loopConvOutstandingCount - 1.U
      }
    }
  }
  when (loopConvOverflowViolation ||
      (loopConvAcceptOnly && loopConvOutstandingCount === 15.U)) {
    loopConvCreditOverflow := true.B
  }
  when (loopConvUnderflowViolation) {
    loopConvCreditUnderflow := true.B
  }

  // （Author 作者：王志瑞）：这些 assertion 只观察 request accept/actual slot retire 账本，
  // 不进入 ready 路径。它们覆盖 SAFE_MAX、underflow 和三份计数状态的一致性。
  when (!reset.asBool) {
    assert(loopConvOutstandingCount <= loopConvSafeMax.U,
      "LoopConv outstanding exceeded SAFE_MAX")
    assert(!loopConvOverflowViolation,
      "LoopConv accepted a request without available credit")
    assert(!loopConvUnderflowViolation,
      "LoopConv retired a request with zero outstanding")
    assert(loopConvRetiredCount <= loopConvAcceptedCount,
      "LoopConv retired_count exceeded accepted_count")
    assert((loopConvAcceptedCount - loopConvRetiredCount) === loopConvOutstandingCount,
      "LoopConv accepted-retired did not equal outstanding")
  }

  // （Output 输出；Author 作者：王志瑞）：当前 RegisteredIngressAtomicReserve 的完整 request Queue 深度为
  // 2。assembler_partial 必须为 0，确保本次 admission 从 CONFIG1 开始而非接续半包。
  val loopConvCanSubmit = has_loop_conv.B &&
    loopConvOutstandingCount < loopConvSafeMax.U &&
    io.loopconv_request_queue_count < 2.U &&
    !io.loopconv_assembler_partial
  // （Process 处理；Author 作者：王志瑞）：一次性拼接状态字，避免先连接整根 Wire 再连接位选导致
  // Chisel 将位选视为只读目标。字段布局与文档及软件 ABI 保持一致。
  val loopConvStatus = Cat(
    0.U((xLen - 16).W),
    loopConvCreditUnderflow,
    loopConvCreditOverflow,
    false.B,
    io.loopconv_assembler_partial,
    loop_conv_running_slots,
    io.loopconv_request_queue_count(1, 0),
    0.U(3.W),
    loopConvOutstandingCount(2, 0),
    loopConvCanSubmit,
    gemminiBusy)

  // （Input 输入；Author 作者：王志瑞）：CSR 顺序与 Gemmini.roccCSRs 保持一致：原 busy 在前，状态 CSR
  // 在后。不要 foreach 把所有 CSR 都写成 busy，否则 status 会退化成 1-bit 忙信号。
  outer.config.busyCsrId.foreach { _ =>
    val busyCsr = io.csrs(0)
    busyCsr.stall := false.B
    busyCsr.set := true.B
    busyCsr.sdata := gemminiBusy
  }
  outer.config.loopConvStatusCsrId.foreach { _ =>
    val statusCsr = io.csrs(outer.config.busyCsrId.toSeq.size)
    statusCsr.stall := false.B
    statusCsr.set := true.B
    statusCsr.sdata := loopConvStatus
  }
  // （Author 作者：王志瑞）：CSR 顺序固定为 busy/status/accepted/retired，各 optional 字段的
  // 下标由此前实际存在的 CSR 数量计算，避免某项关闭时连错 worker 状态。
  outer.config.loopConvAcceptedCsrId.foreach { _ =>
    val acceptedCsrIndex = outer.config.busyCsrId.toSeq.size +
      outer.config.loopConvStatusCsrId.toSeq.size
    val acceptedCsr = io.csrs(acceptedCsrIndex)
    acceptedCsr.stall := false.B
    acceptedCsr.set := true.B
    acceptedCsr.sdata := loopConvAcceptedCount
  }
  outer.config.loopConvRetiredCsrId.foreach { _ =>
    val retiredCsrIndex = outer.config.busyCsrId.toSeq.size +
      outer.config.loopConvStatusCsrId.toSeq.size +
      outer.config.loopConvAcceptedCsrId.toSeq.size
    val retiredCsr = io.csrs(retiredCsrIndex)
    retiredCsr.stall := false.B
    retiredCsr.set := true.B
    retiredCsr.sdata := loopConvRetiredCount
  }

  // （Author 作者：王志瑞）：LoopConv LOAD2 轻量片上快照。只锁存 B0/B1/B2/首个 B3，
  // 避免多组宽 Trace RAM 和 Scratchpad 回传总线造成局部布线拥塞。
  if (outer.config.loopConvTraceControlCsrId.isDefined) {
    val traceCsrBase = outer.config.busyCsrId.toSeq.size +
      outer.config.loopConvStatusCsrId.toSeq.size +
      outer.config.loopConvAcceptedCsrId.toSeq.size +
      outer.config.loopConvRetiredCsrId.toSeq.size
    val traceControlCsr = io.csrs(traceCsrBase)
    val traceStatusCsr = io.csrs(traceCsrBase + 1)
    val traceSelectCsr = io.csrs(traceCsrBase + 2)
    val traceDataCsr = io.csrs(traceCsrBase + 3)

    traceControlCsr.stall := false.B
    traceControlCsr.set := false.B
    traceControlCsr.sdata := 0.U
    traceStatusCsr.stall := false.B
    traceStatusCsr.set := true.B
    traceSelectCsr.stall := false.B
    traceSelectCsr.set := false.B
    traceSelectCsr.sdata := 0.U
    traceDataCsr.stall := false.B
    traceDataCsr.set := true.B

    val traceStart = traceControlCsr.wen && traceControlCsr.wdata(0)
    val traceFreeze = traceControlCsr.wen && traceControlCsr.wdata(1)
    val traceClearOnly = traceControlCsr.wen && traceControlCsr.wdata(2)
    val traceClear = traceStart || traceClearOnly

    val traceArmed = RegInit(false.B)
    val traceTargetActive = RegInit(false.B)
    val traceDone = RegInit(false.B)
    val traceCycle = RegInit(0.U(32.W))
    traceCycle := traceCycle + 1.U

    val targetB2Fire = load_controller.io.cmd.fire &&
      load_controller.io.cmd.bits.from_conv_fsm &&
      load_controller.io.cmd.bits.cmd.inst.funct === LOAD2_CMD
    val targetComplete = traceTargetActive && load_controller.io.completed.fire

    when (traceStart) {
      traceArmed := true.B
      traceTargetActive := false.B
      traceDone := false.B
    }.elsewhen (traceFreeze || traceClearOnly) {
      traceArmed := false.B
      traceTargetActive := false.B
      traceDone := false.B
    }.elsewhen (traceArmed && targetB2Fire) {
      traceTargetActive := true.B
    }.elsewhen (targetComplete) {
      traceArmed := false.B
      traceTargetActive := false.B
      traceDone := true.B
    }

    val traceEvents = Wire(Vec(4, Valid(new LoopConvTraceEvent)))
    traceEvents.foreach { event =>
      event.valid := false.B
      event.bits := 0.U.asTypeOf(new LoopConvTraceEvent)
    }

    // （Author 作者：王志瑞）：LoopConvLdWeight 的内部区间量先锁存，再与稍后到达
    // ReservationStation 的 B1 描述符放在同一条记录中。
    val ldWeightInternal = RegInit(0.U.asTypeOf(new LoopConvTraceEvent))
    when (loop_conv_ld_weight_trace.valid) {
      ldWeightInternal := loop_conv_ld_weight_trace.bits
    }
    // （Author 作者：王志瑞）：若内部事件与 B1 恰好同拍，优先使用当前事件，避免读到上一条 LOAD2。
    val b1Internal = Mux(loop_conv_ld_weight_trace.valid,
      loop_conv_ld_weight_trace.bits, ldWeightInternal)

    // （王志瑞）B0：CPU 可见的 CONFIG5 和 LOOP_CONV_WS 命令。
    val b0Relevant = io.cmd.bits.inst.funct === LOOP_CONV_WS_CONFIG_5 ||
      io.cmd.bits.inst.funct === LOOP_CONV_WS
    traceEvents(0).valid := traceArmed && io.cmd.fire && b0Relevant
    traceEvents(0).bits.meta := io.cmd.bits.inst.funct
    traceEvents(0).bits.payload0 := io.cmd.bits.rs1
    traceEvents(0).bits.payload1 := io.cmd.bits.rs2

    // （王志瑞）B1：ReservationStation 接受的 LoopConv LOAD2。
    val b1Fire = reservation_station.io.alloc.fire &&
      unrolled_cmd.bits.from_conv_fsm &&
      unrolled_cmd.bits.cmd.inst.funct === LOAD2_CMD
    traceEvents(1).valid := traceArmed && b1Fire
    traceEvents(1).bits.meta := unrolled_cmd.bits.cmd.inst.funct
    traceEvents(1).bits.payload0 := unrolled_cmd.bits.cmd.rs1
    traceEvents(1).bits.payload1 := unrolled_cmd.bits.cmd.rs2
    traceEvents(1).bits.payload2 := Cat(
      b1Internal.payload2(15, 0),
      b1Internal.payload1(31, 0),
      b1Internal.payload0(15, 0))

    // （王志瑞）B2：LoadController 接受的同一条 LOAD2。
    traceEvents(2).valid := traceArmed && targetB2Fire
    traceEvents(2).bits.meta := load_controller.io.cmd.bits.cmd.inst.funct
    traceEvents(2).bits.payload0 := load_controller.io.cmd.bits.cmd.rs1
    traceEvents(2).bits.payload1 := load_controller.io.cmd.bits.cmd.rs2

    // （王志瑞）B3：只锁存 LoadController 发出的首个逐行请求。
    traceEvents(3).valid := traceArmed && traceTargetActive && load_controller.io.dma.req.fire
    traceEvents(3).bits.meta := Cat(
      load_controller.io.dma.req.bits.cmd_id,
      load_controller.io.dma.req.bits.cols,
      7.U(7.W),
      load_controller.io.dma.req.bits.all_zeros)
    traceEvents(3).bits.payload0 := load_controller.io.dma.req.bits.vaddr
    traceEvents(3).bits.payload1 := load_controller.io.dma.req.bits.laddr.asUInt
    traceEvents(3).bits.payload2 := Cat(
      0.U(32.W),
      load_controller.io.dma.req.bits.repeats,
      load_controller.io.dma.req.bits.block_stride)

    // （Author 作者：王志瑞）：四条一次性快照使用普通寄存器，不再推断 BRAM。索引字段为兼容
    // 既有 UART 软件而保留，但每个阶段只有 index 0 有效。
    val traceRecords = Reg(Vec(4, UInt(256.W)))
    val traceCaptured = RegInit(VecInit(Seq.fill(4)(false.B)))
    when (traceClear) {
      traceCaptured.foreach(_ := false.B)
    }.otherwise {
      traceEvents.zipWithIndex.foreach { case (event, index) =>
        when (event.valid && !traceCaptured(index)) {
          traceRecords(index) := Cat(
            event.bits.payload2,
            event.bits.payload1,
            event.bits.payload0,
            traceCycle,
            event.bits.meta)
          traceCaptured(index) := true.B
        }
      }
    }

    val oneOrZeroCounts = traceCaptured.map(valid => Cat(0.U(7.W), valid))
    val traceCounts = Cat(0.U(24.W) +: oneOrZeroCounts.reverse)
    traceStatusCsr.sdata := Cat(
      0.U(4.W), false.B, traceDone, traceTargetActive, traceArmed,
      traceCounts)

    // （Author 作者：王志瑞）：先在单条快照内选 64-bit word，再做四路选择，避免七路
    // 256-bit RAM 输出集中汇聚到 Controller。
    val selectedWord = MuxLookup(traceSelectCsr.value(10, 8), 0.U(64.W))(
      traceRecords.zipWithIndex.map { case (record, index) =>
        index.U -> record.asTypeOf(Vec(4, UInt(64.W)))(traceSelectCsr.value(1, 0))
      })
    traceDataCsr.sdata := selectedWord
  }

  /** IPOAT：双 4x4 Gemmini 死锁冻结/实时读窗（ABI v7）
    * I（Input 输入）：LoopConv、预约站、Scratchpad/DMA/AccScale 诊断页及 Controller 完成事件。
    * P（Process 处理）：组成 64 个 64-bit 页；control.bit0 原子冻结，bit1 清除。未冻结时 data 返回实时页。
    * O（Output 输出）：status/select/data CSR 可在软件超时后读取同一时刻的完整阻塞链。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-18
    */
  if (outer.config.deadlockDebugControlCsrId.isDefined) {
    val debugCsrBase = outer.config.busyCsrId.toSeq.size +
      outer.config.loopConvStatusCsrId.toSeq.size +
      outer.config.loopConvAcceptedCsrId.toSeq.size +
      outer.config.loopConvRetiredCsrId.toSeq.size +
      outer.config.loopConvTraceControlCsrId.toSeq.size +
      outer.config.loopConvTraceStatusCsrId.toSeq.size +
      outer.config.loopConvTraceSelectCsrId.toSeq.size +
      outer.config.loopConvTraceDataCsrId.toSeq.size
    val debugControlCsr = io.csrs(debugCsrBase)
    val debugStatusCsr = io.csrs(debugCsrBase + 1)
    val debugSelectCsr = io.csrs(debugCsrBase + 2)
    val debugDataCsr = io.csrs(debugCsrBase + 3)

    debugControlCsr.stall := false.B
    debugControlCsr.set := false.B
    debugControlCsr.sdata := 0.U
    debugStatusCsr.stall := false.B
    debugStatusCsr.set := true.B
    debugSelectCsr.stall := false.B
    debugSelectCsr.set := false.B
    debugSelectCsr.sdata := 0.U
    debugDataCsr.stall := false.B
    debugDataCsr.set := true.B

    val live = Wire(Vec(64, UInt(64.W)))
    live.foreach(_ := 0.U)
    live(0) := "h4442475f00070040".U // "DBG_", ABI v7, 64 pages
    for (i <- 0 until 9) {
      live(i + 1) := loop_conv_deadlock_debug(i)
    }
    for (i <- 0 until 20) { live(i + 10) := reservation_station.io.deadlock_debug(i) }
    for (i <- 0 until 12) { live(i + 30) := spad.module.io.deadlock_debug(i) }
    live(42) := Cat(0.U(25.W),
      reservation_station_completed_arb.io.out.bits.pad(8),
      reservation_station_completed_arb.io.out.fire,
      store_controller.io.completed.bits.pad(8), store_controller.io.completed.fire,
      load_controller.io.completed.bits.pad(8), load_controller.io.completed.fire,
      ex_controller.io.completed.bits.pad(8), ex_controller.io.completed.valid)
    live(43) := Cat(loopConvAcceptedCount(15, 0), loopConvRetiredCount(15, 0),
      0.U(19.W), io.loopconv_assembler_partial, loop_conv_running_slots,
      io.loopconv_request_queue_count(1, 0), loopConvOutstandingCount)
    live(44) := Cat(0.U(59.W),
      ex_controller.io.busy, store_controller.io.busy, load_controller.io.busy,
      spad.module.io.busy, reservation_station.io.busy)
    /** IPOAT：LazyRoCC 双边界 blocked-packet 自动快照触发（ABI v7）
      * I（Input 输入）：Router 提供的连续阻塞周期、入口 RUN/serializer packet 阻塞来源及握手。
      * P（Process 处理）：任一边界累计阻塞 2^26 周期后，无需 CPU 写 CSR 即冻结全部 64 页；
      *                  100 MHz 下约 0.671 s，远大于本测试单次卷积的正常满槽等待。
      * O（Output 输出）：page45 保存定宽 Router 状态，page46/47 保存 Gemmini 命令链、credit 和阻塞来源。
      * A（Author 作者）：王志瑞
      * T（Time 时间）：2026-09-19
      */
    val ingressBlockedCycles = io.loopconv_ingress_debug(63, 32)
    val ingressBlockedRun = io.loopconv_ingress_debug(29)
    val serializedPacketBlocked = io.loopconv_ingress_debug(30)
    val automaticFreezeTrigger = ingressBlockedCycles >= (1 << 26).U
    live(45) := io.loopconv_ingress_debug
    live(46) := Cat(0.U(48.W), io.cmd.bits.inst.funct,
      io.cmd.valid, io.cmd.ready, io.cmd.fire,
      raw_cmd.valid, raw_cmd.ready, raw_cmd.fire,
      conv_cmd.valid, conv_cmd.ready, conv_cmd.fire)
    live(47) := Cat(0.U(47.W), loopConvOutstandingCount,
      loop_conv_running_slots, io.loopconv_request_queue_count,
      io.loopconv_assembler_partial, serializedPacketBlocked, ingressBlockedRun)
    live(48) := load_controller.io.deadlock_debug
    live(49) := store_controller.io.deadlock_debug
    live(50) := ex_controller.io.deadlock_debug(0)
    live(51) := ex_controller.io.deadlock_debug(1)
    live(52) := Cat(Cat(debugCompletionCount.reverse),
      Cat(debugCompletionLastTag.reverse))
    for (i <- 0 until 6) { live(i + 53) := reservation_station.io.deadlock_debug(i + 20) }

    val frozen = RegInit(false.B)
    val automaticallyFrozen = RegInit(false.B)
    val snapshot = Reg(Vec(64, UInt(64.W)))
    val manualClear = debugControlCsr.wen && debugControlCsr.wdata(1)
    val manualFreeze = debugControlCsr.wen && debugControlCsr.wdata(0)
    when (manualClear) {
      frozen := false.B
      automaticallyFrozen := false.B
    }.elsewhen (manualFreeze || (!frozen && automaticFreezeTrigger)) {
      snapshot := live
      frozen := true.B
      automaticallyFrozen := automaticFreezeTrigger && !manualFreeze
    }
    val selected = debugSelectCsr.value(5, 0)
    debugStatusCsr.sdata := Cat(0.U(46.W), automaticallyFrozen,
      7.U(8.W), 64.U(8.W), frozen)
    debugDataCsr.sdata := Mux(frozen, snapshot(selected), live(selected))
  }

  io.interrupt := tlb.io.exp.map(_.interrupt).reduce(_ || _)

  // assert(!io.interrupt, "Interrupt handlers have not been written yet")

  // Cycle counters
  val incr_ld_cycles = load_controller.io.busy && !store_controller.io.busy && !ex_controller.io.busy
  val incr_st_cycles = !load_controller.io.busy && store_controller.io.busy && !ex_controller.io.busy
  val incr_ex_cycles = !load_controller.io.busy && !store_controller.io.busy && ex_controller.io.busy

  val incr_ld_st_cycles = load_controller.io.busy && store_controller.io.busy && !ex_controller.io.busy
  val incr_ld_ex_cycles = load_controller.io.busy && !store_controller.io.busy && ex_controller.io.busy
  val incr_st_ex_cycles = !load_controller.io.busy && store_controller.io.busy && ex_controller.io.busy

  val incr_ld_st_ex_cycles = load_controller.io.busy && store_controller.io.busy && ex_controller.io.busy

  counters.io.event_io.connectEventSignal(CounterEvent.MAIN_LD_CYCLES, incr_ld_cycles)
  counters.io.event_io.connectEventSignal(CounterEvent.MAIN_ST_CYCLES, incr_st_cycles)
  counters.io.event_io.connectEventSignal(CounterEvent.MAIN_EX_CYCLES, incr_ex_cycles)
  counters.io.event_io.connectEventSignal(CounterEvent.MAIN_LD_ST_CYCLES, incr_ld_st_cycles)
  counters.io.event_io.connectEventSignal(CounterEvent.MAIN_LD_EX_CYCLES, incr_ld_ex_cycles)
  counters.io.event_io.connectEventSignal(CounterEvent.MAIN_ST_EX_CYCLES, incr_st_ex_cycles)
  counters.io.event_io.connectEventSignal(CounterEvent.MAIN_LD_ST_EX_CYCLES, incr_ld_st_ex_cycles)

  // Issue commands to controllers
  // TODO we combinationally couple cmd.ready and cmd.valid signals here
  // when (compressed_cmd.valid) {
  when (unrolled_cmd.valid) {
    // val config_cmd_type = cmd.bits.rs1(1,0) // TODO magic numbers

    //val funct = unrolled_cmd.bits.inst.funct
    val risc_funct = unrolled_cmd.bits.cmd.inst.funct

    val is_flush = risc_funct === FLUSH_CMD
    val is_counter_op = risc_funct === COUNTER_OP
    val is_clock_gate_en = risc_funct === CLKGATE_EN

    /*
    val is_load = (funct === LOAD_CMD) || (funct === CONFIG_CMD && config_cmd_type === CONFIG_LOAD)
    val is_store = (funct === STORE_CMD) || (funct === CONFIG_CMD && config_cmd_type === CONFIG_STORE)
    val is_ex = (funct === COMPUTE_AND_FLIP_CMD || funct === COMPUTE_AND_STAY_CMD || funct === PRELOAD_CMD) ||
    (funct === CONFIG_CMD && config_cmd_type === CONFIG_EX)
    */

    when (is_flush) {
      val skip = unrolled_cmd.bits.cmd.rs1(0)
      tlb.io.exp.foreach(_.flush_skip := skip)
      tlb.io.exp.foreach(_.flush_retry := !skip)

      unrolled_cmd.ready := true.B // TODO should we wait for an acknowledgement from the TLB?
    }

    .elsewhen (is_counter_op) {
      // If this is a counter access/configuration command, execute immediately
      counters.io.in.valid := unrolled_cmd.valid
      unrolled_cmd.ready := counters.io.in.ready
      counters.io.in.bits := unrolled_cmd.bits.cmd
    }

    .elsewhen (is_clock_gate_en) {
      unrolled_cmd.ready := true.B
    }

    .otherwise {
      reservation_station.io.alloc.valid := true.B

      when(reservation_station.io.alloc.fire) {
        // compressed_cmd.ready := true.B
        unrolled_cmd.ready := true.B
      }
    }
  }

  // Debugging signals
  val pipeline_stall_counter = RegInit(0.U(32.W))
  when (io.cmd.fire) {
    pipeline_stall_counter := 0.U
  }.elsewhen(io.busy) {
    pipeline_stall_counter := pipeline_stall_counter + 1.U
  }
  assert(pipeline_stall_counter < 10000000.U, "pipeline stall")

  /*
  //=========================================================================
  // Wire up global RoCC signals
  //=========================================================================
  io.busy := raw_cmd.valid || unrolled_cmd.valid || rob.io.busy || spad.module.io.busy || tiler.io.busy
  io.interrupt := tlb.io.exp.interrupt

  // hack
  when(is_cisc_mode || !(unrolled_cmd.valid || rob.io.busy || tiler.io.busy)){
    tlb.io.exp.flush_retry := cmd_fsm.io.flush_retry
    tlb.io.exp.flush_skip  := cmd_fsm.io.flush_skip
  }
  */

  //=========================================================================
  // Performance Counters Access
  //=========================================================================

}
