package gemmini
import chisel3._
import chisel3.util._

/** IPOAT：完整驻留矩形的充分条件证明
  * I（Input 输入）：不可变 VI 描述符及段起点/长度。
  * P（Process 处理）：仅对零原点、stride1、无逻辑padding的正步长视图，用宽位宽最大角点证明所有地址驻留；其它情况返回false走原扫描。
  * O（Output 输出）：充分条件成立标志；false不代表非法，不能直接拒绝请求。
  * A（Author 作者）：王志瑞
  * T（Time 时间）：2026-09-09
  */
object VirtualIResidentProof {
  def apply(d: VirtualITileDesc): Bool = {
    val v = d.input
    val pixels = d.batches * d.tileRows * d.tileCols
    val imagePixels = d.tileRows * d.tileCols
    val segmentStart = d.startR * d.tileCols +& d.startC
    val yMax = d.tileRows.pad(128) - 1.U + d.kernelY * d.dilationY
    val xMax = d.tileCols.pad(128) - 1.U + d.kernelX * d.dilationX
    val addressMax = v.base.pad(128) + d.channelBlock.pad(128) * v.channelStride +
      (d.batches.pad(128) - 1.U) * v.batchStride + yMax * v.rowStride + xMax * v.pixelStride
    val outputEnd = d.output.base.pad(128) + pixels.pad(128) * d.output.groups
    d.supported && d.segment && d.segmentRows > 0.U && d.segmentRows <= 64.U &&
      d.batches > 0.U && d.tileRows > 0.U && d.tileCols > 0.U &&
      d.startB < d.batches && d.startR < d.tileRows && d.startC < d.tileCols &&
      segmentStart +& d.segmentRows <= imagePixels &&
      d.batchStart === 0.U && d.outputY === 0.U && d.outputX === 0.U &&
      d.strideY === 1.U && d.strideX === 1.U && d.padY === 0.U && d.padX === 0.U &&
      d.dilationY > 0.U && d.dilationX > 0.U &&
      v.physicalY === 0.S && v.physicalX === 0.S && v.residentY === 0.U && v.residentX === 0.U &&
      v.batchOrigin === 0.U && v.channelOrigin === 0.U && d.batches <= v.batches &&
      d.channelBlock < v.channelBlocks && yMax < d.inputH && xMax < d.inputW &&
      yMax < v.residentH && xMax < v.residentW &&
      v.channelStride > 0.U && v.batchStride > 0.U && v.rowStride > 0.U && v.pixelStride > 0.U &&
      addressMax < v.limit && outputEnd <= d.output.limit && d.outputGroup < d.output.groups &&
      d.kValid > 0.U && d.kValid <= 64.U && d.jValid > 0.U && d.jValid <= 64.U
  }
}
