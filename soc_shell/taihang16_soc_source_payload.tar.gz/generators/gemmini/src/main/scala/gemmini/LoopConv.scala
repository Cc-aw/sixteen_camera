
package gemmini

import chisel3._
import chisel3.util._
import chisel3.experimental._
import freechips.rocketchip.tile.RoCCCommand
import org.chipsalliance.cde.config.Parameters
import GemminiISA._
import LocalAddr._
import Util._

class LoopConvOuterBounds(val large_iterator_bitwidth: Int, val small_iterator_bitwidth: Int, val tiny_iterator_bitwidth: Int) extends Bundle {
  val batch_size = UInt(large_iterator_bitwidth.W)
  val in_row_dim = UInt(small_iterator_bitwidth.W)
  val in_col_dim = UInt(small_iterator_bitwidth.W)
  val in_channels = UInt(large_iterator_bitwidth.W)
  val out_channels = UInt(large_iterator_bitwidth.W)
  val out_col_dim = UInt(large_iterator_bitwidth.W)
  val out_row_dim = UInt(large_iterator_bitwidth.W)
  val out_stride = UInt(large_iterator_bitwidth.W) //stride for output activation
  val in_stride = UInt(large_iterator_bitwidth.W) //stride for input activation
  val weight_stride = UInt(large_iterator_bitwidth.W) //stride for weight
  val pool_out_row_dim = UInt(small_iterator_bitwidth.W)
  val pool_out_col_dim = UInt(small_iterator_bitwidth.W)
  val stride = UInt(tiny_iterator_bitwidth.W)
  val padding = UInt(tiny_iterator_bitwidth.W)
  val kernel_dim = UInt(tiny_iterator_bitwidth.W)
  val kernel_dilation = UInt(tiny_iterator_bitwidth.W)
  val pool_size = UInt(tiny_iterator_bitwidth.W)
  val pool_stride = UInt(tiny_iterator_bitwidth.W)
  val pool_padding = UInt(tiny_iterator_bitwidth.W)
}

class LoopConvInnerBounds(val large_iterator_bitwidth: Int, val small_iterator_bitwidth: Int, val tiny_iterator_bitwidth: Int) extends Bundle {
  val batches = UInt(large_iterator_bitwidth.W)
  val porows = UInt(small_iterator_bitwidth.W)
  val pocols = UInt(small_iterator_bitwidth.W)
  val pochs = UInt(large_iterator_bitwidth.W)
  val krows = UInt(tiny_iterator_bitwidth.W)
  val kcols = UInt(tiny_iterator_bitwidth.W)
  val kchs = UInt(large_iterator_bitwidth.W)
  val lpad = UInt(tiny_iterator_bitwidth.W)
  val rpad = UInt(tiny_iterator_bitwidth.W)
  val upad = UInt(tiny_iterator_bitwidth.W)
  val dpad = UInt(tiny_iterator_bitwidth.W)
  val plpad = UInt(tiny_iterator_bitwidth.W)
  val prad = UInt(tiny_iterator_bitwidth.W)
  val pupad = UInt(tiny_iterator_bitwidth.W)
  val pdpad = UInt(tiny_iterator_bitwidth.W)
  val orows = UInt(small_iterator_bitwidth.W)
  val ocols = UInt(small_iterator_bitwidth.W)
}

class LoopConvDerivedParams(val large_iterator_bitwidth: Int, val small_iterator_bitwidth: Int, val tiny_iterator_bitwidth: Int) extends Bundle {
  val ochs = UInt(large_iterator_bitwidth.W)

  val irows = UInt(small_iterator_bitwidth.W)
  val icols = UInt(small_iterator_bitwidth.W)
  val irows_unpadded = UInt(small_iterator_bitwidth.W)
  val icols_unpadded = UInt(small_iterator_bitwidth.W)
  val ichs = UInt(large_iterator_bitwidth.W)

  val out_channels_per_bank = UInt(small_iterator_bitwidth.W) // TODO this won't work for systolic arrays above 256 in size
  val in_channels_per_bank = UInt(small_iterator_bitwidth.W) // TODO this won't work for systolic arrays above 256 in size

  val bias_spad_stride = UInt(large_iterator_bitwidth.W)
  val input_spad_stride = UInt(large_iterator_bitwidth.W)
  val weight_spad_stride = UInt(large_iterator_bitwidth.W)

  // val ex_overwrite = Bool()
}

class LoopConvLdBiasReq(val coreMaxAddrBits: Int, val large_iterator_bitwidth: Int, val small_iterator_bitwidth: Int, val tiny_iterator_bitwidth: Int, val max_acc_addr: Int, val concurrent_loops: Int)  extends Bundle {
  val outer_bounds = new LoopConvOuterBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val inner_bounds = new LoopConvInnerBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val derived_params = new LoopConvDerivedParams(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val addr_start = UInt(log2Up(max_acc_addr).W)
  val dram_addr = UInt(coreMaxAddrBits.W)
  val no_bias = Bool()
  val loop_id = UInt(log2Up(concurrent_loops).W)
}

class LoopConvLdBias(block_size: Int, coreMaxAddrBits: Int, large_iterator_bitwidth: Int, small_iterator_bitwidth: Int, tiny_iterator_bitwidth: Int, max_acc_addr: Int, acc_w: Int,
                     max_block_len_acc: Int, concurrent_loops: Int, latency: Int,
                     config_mvin_rs1_t: ConfigMvinRs1, mvin_rs2_t: MvinRs2)(implicit p: Parameters) extends Module {
  val MVIN_SCALE_IDENTITY = 0x3f800000.U // TODO get this from configs somehow
  val io = IO(new Bundle {
    val req = Flipped(Decoupled(new LoopConvLdBiasReq(coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth: Int, max_acc_addr, concurrent_loops)))
    val cmd = Decoupled(Output(new RoCCCommand))

    val idle = Output(Bool())
    val rob_overloaded = Input(Bool())
    val wait_for_prev_loop = Input(Bool())

    val loop_id = Output(UInt(log2Up(concurrent_loops).W))
    val deadlock_debug = Output(UInt(64.W))
  })

  object State extends ChiselEnum {
    val idle, config, ld = Value
  }
  import State._
  val state = RegInit(idle)
  val req = Reg(new LoopConvLdBiasReq(coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth: Int, max_acc_addr, concurrent_loops))
  import req.inner_bounds._
  import req.derived_params._

  val acc_addr_start = req.addr_start

  // Derived parameters
  val max_ochs_per_mvin = Mux(ochs < (max_block_len_acc * block_size).U, ochs, (max_block_len_acc * block_size).U)

  val skip = req.dram_addr === 0.U

  // Iterators
  val b = Reg(UInt(large_iterator_bitwidth.W))
  val orow = Reg(UInt(small_iterator_bitwidth.W))
  val ocol = Reg(UInt(small_iterator_bitwidth.W))
  val och = Reg(UInt(large_iterator_bitwidth.W))

  // Addresses
  val dram_offset = och * (acc_w/8).U
  val dram_addr = Mux(req.no_bias, 0.U, req.dram_addr + LoopConv.castDramOffset(dram_offset))
  val spad_addr = acc_addr_start +& (och / block_size.U(och.getWidth.W)) * batches * orows * ocols +& b * orows * ocols +& orow * ocols +& ocol

  // Sizes
  val I = Mux(ocols - ocol > block_size.U, block_size.U, ocols - ocol)
  val J = Mux(ochs - och > max_ochs_per_mvin, max_ochs_per_mvin, ochs - och)

  class RoCCCommandWithAddr extends Bundle {
    val cmd = new RoCCCommand
    val dram_addr = UInt()
    val spad_addr = UInt()
    val I = UInt()
    val J = UInt()
  }
  val command_p = Module(new Pipeline[RoCCCommandWithAddr](new RoCCCommandWithAddr, latency)())

  // Commands
  val config_cmd = Wire(new RoCCCommand)
  config_cmd := DontCare
  config_cmd.inst.funct := CONFIG_CMD

  val config_cmd_rs1 = Wire(config_mvin_rs1_t.cloneType)
  config_cmd_rs1 := DontCare
  config_cmd_rs1.scale := MVIN_SCALE_IDENTITY
  config_cmd_rs1.stride := req.derived_params.bias_spad_stride
  config_cmd_rs1.pixel_repeats := 1.U
  config_cmd_rs1.state_id := 2.U
  config_cmd_rs1.shrink := 0.U
  config_cmd_rs1._unused := 1.U
  config_cmd.rs1 := config_cmd_rs1.asUInt

  config_cmd.rs2 := 0.U

  val mvin_cmd = Wire(new RoCCCommand)
  mvin_cmd := DontCare
  mvin_cmd.inst.funct := LOAD3_CMD
  mvin_cmd.rs1 := 0.U
  mvin_cmd.rs2 := 0.U

  // Inputs and outputs
  io.req.ready := state === idle && !command_p.io.busy
  io.idle := state === idle && !command_p.io.busy
  io.loop_id := req.loop_id

  command_p.io.in.valid := state =/= idle && !io.wait_for_prev_loop && !skip
  command_p.io.in.bits.cmd := Mux(state === config, config_cmd, mvin_cmd)
  command_p.io.in.bits.dram_addr := dram_addr
  command_p.io.in.bits.spad_addr := spad_addr
  command_p.io.in.bits.I := I
  command_p.io.in.bits.J := J

  command_p.io.out.ready := io.cmd.ready && !io.rob_overloaded
  io.cmd.valid := command_p.io.out.valid && !io.rob_overloaded
  io.cmd.bits := command_p.io.out.bits.cmd
  when (command_p.io.out.bits.cmd.inst.funct === LOAD3_CMD) {
    val o = command_p.io.out.bits
    io.cmd.bits.rs1 := o.dram_addr
    val mvin_cmd_rs2 = Wire(mvin_rs2_t.cloneType)
    mvin_cmd_rs2 := DontCare
    mvin_cmd_rs2.num_rows := o.I.asUInt
    mvin_cmd_rs2.num_cols := o.J.asUInt
    mvin_cmd_rs2.local_addr := cast_to_acc_addr(mvin_cmd_rs2.local_addr, o.spad_addr, accumulate = false.B, read_full = false.B)
    io.cmd.bits.rs2 := mvin_cmd_rs2.asUInt
  }

  // Sending outputs
  when (skip) {
    state := idle
  }.elsewhen(command_p.io.in.fire) {
    when (state === config) {
      state := ld
    }.otherwise {
      val next_och = floorAdd(och, max_ochs_per_mvin, ochs)
      val next_ocol = floorAdd(ocol, block_size.U, ocols, next_och === 0.U)
      val next_orow = floorAdd(orow, 1.U, orows, next_ocol === 0.U && next_och === 0.U)
      val next_b = floorAdd(b, 1.U, batches, next_orow === 0.U && next_ocol === 0.U && next_och === 0.U)

      och := next_och
      ocol := next_ocol
      orow := next_orow
      b := next_b

      state := Mux(next_b === 0.U && next_orow === 0.U && next_ocol === 0.U && next_och === 0.U,
        idle, ld)
    }
  }

  // Accepting requests
  when (io.req.fire) {
    req := io.req.bits
    state := config
    b := 0.U
    orow := 0.U
    ocol := 0.U
    och := 0.U
  }

  /** IPOAT：Bias 子生成器阻塞快照
    * I（Input 输入）：状态、loop、等待/过载、pipeline 与当前迭代坐标。
    * P（Process 处理）：只读压缩为 64-bit，不参与任何握手。
    * O（Output 输出）：可区分依赖等待、RS 满和 pipeline 出口反压。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-19
    */
  io.deadlock_debug := Cat(0.U(24.W), b(7, 0), orow(7, 0), ocol(7, 0), och(7, 0),
    state.asUInt.pad(2), io.loop_id, io.wait_for_prev_loop, io.rob_overloaded,
    command_p.io.busy, io.cmd.valid, io.cmd.ready)
}

class LoopConvLdInputReq(val coreMaxAddrBits: Int, val large_iterator_bitwidth: Int, val small_iterator_bitwidth: Int, val tiny_iterator_bitwidth: Int, val max_acc_addr: Int, val concurrent_loops: Int)  extends Bundle {
  val outer_bounds = new LoopConvOuterBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val inner_bounds = new LoopConvInnerBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val derived_params = new LoopConvDerivedParams(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val addr_start = UInt(log2Up(max_acc_addr).W)
  val dram_addr = UInt(coreMaxAddrBits.W)
  val downsample = Bool()
  val max_pixels_per_row = UInt(small_iterator_bitwidth.W)
  val input_dilated = Bool()
  val trans_input_3120 = Bool()
  val loop_id = UInt(log2Up(concurrent_loops).W)
}

class LoopConvLdInput(block_size: Int, coreMaxAddrBits: Int, large_iterator_bitwidth: Int, small_iterator_bitwidth: Int,
                      tiny_iterator_bitwidth: Int, max_addr: Int, input_w: Int, max_block_len: Int,
                      concurrent_loops: Int, latency: Int, config_mvin_rs1_t: ConfigMvinRs1, mvin_rs2_t: MvinRs2)
                     (implicit p: Parameters) extends Module {
  val MVIN_SCALE_IDENTITY = 0x3f800000.U // TODO get this from configs somehow

  val io = IO(new Bundle {
    val req = Flipped(Decoupled(new LoopConvLdInputReq(coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth, max_addr, concurrent_loops)))
    val cmd = Decoupled(Output(new RoCCCommand))

    val idle = Output(Bool())
    val rob_overloaded = Input(Bool())
    val wait_for_prev_loop = Input(Bool())

    val loop_id = Output(UInt(log2Up(concurrent_loops).W))
    val deadlock_debug = Output(UInt(64.W))
  })

  object State extends ChiselEnum {
    val idle, config, ld = Value
  }
  import State._
  val state = RegInit(idle)

  val req = Reg(new LoopConvLdInputReq(coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth, max_addr, concurrent_loops))
  import req.outer_bounds._
  import req.inner_bounds._
  import req.derived_params._

  def undilated(x: UInt): UInt = (x +& req.input_dilated) >> req.input_dilated

  // Derived parameters
  val max_ichs_per_mvin = Mux(ichs < (max_block_len * block_size).U, ichs, (max_block_len * block_size).U).zext
  val max_batches_per_mvin = Mux(batches < (max_block_len * block_size).U, batches, (max_block_len * block_size).U).zext
  val max_chs_per_mvin = Mux(req.trans_input_3120, max_batches_per_mvin, max_ichs_per_mvin)

  // Iterators
  val b = Reg(SInt(large_iterator_bitwidth.W))
  val irow = Reg(SInt(small_iterator_bitwidth.W))
  val icol = Reg(SInt(small_iterator_bitwidth.W))
  val ich = Reg(SInt(large_iterator_bitwidth.W))

  // Calculated params
  val irow_padded = irow +& undilated(upad).zext
  val icol_padded = icol +& undilated(lpad).zext
  val is_zeros = irow < 0.S || irow >= irows_unpadded.zext || icol < 0.S || icol >= icols_unpadded.zext

  val dram_stride = Mux(req.trans_input_3120, batch_size * (input_w/8).U, in_stride * (input_w/8).U)

  // Addresses
  val dram_offset = Mux(req.trans_input_3120, (((ich * in_col_dim * in_row_dim +& irow*in_col_dim +& icol) * batches +& b) * (input_w/8).U).asUInt,
    (((b * in_row_dim * in_col_dim +& irow*in_col_dim +& icol) * in_stride +& ich) * (input_w/8).U).asUInt)
  val dram_addr = Mux(is_zeros, 0.U, req.dram_addr + LoopConv.castDramOffset(dram_offset))
  val spad_addr = Mux(req.trans_input_3120,
    // To prevent Verilator errors, we replace some "/ block_size.U" calls here with ">> log2Up(block_size)"
    req.addr_start.zext +& (b >> log2Up(block_size)) * input_spad_stride +& ich * (irows >> req.downsample) * (icols >> req.downsample) +& (irow_padded >> req.downsample) * (icols >> req.downsample) +& (icol_padded >> req.downsample),
    req.addr_start.zext +& (ich >> log2Up(block_size)) * input_spad_stride +& b * (irows >> req.downsample) * (icols >> req.downsample) +& (irow_padded >> req.downsample) * (icols >> req.downsample) +& (icol_padded >> req.downsample))

  // Sizes
  val block_size_downsampled = (block_size.U << req.downsample).asUInt.zext

  val I = MuxCase(
    Mux(icols_unpadded.zext -& icol > block_size_downsampled, block_size_downsampled, icols_unpadded.zext -& icol),
    Seq(
      (icol < 0.S) -> Mux((0.S-&icol) > block_size.S, block_size.S, 0.S-&icol),
      (icol >= icols_unpadded.zext) -> Mux(icols_unpadded.zext +& undilated(rpad).zext -& icol > block_size.S, block_size.S, icols_unpadded.zext +& undilated(rpad).zext -& icol)
    )
  )
  val K = Mux(req.trans_input_3120,
    Mux(batches.zext -& b > max_chs_per_mvin, max_chs_per_mvin, batches.zext -& b),
    Mux(ichs.zext -& ich > max_chs_per_mvin, max_chs_per_mvin, ichs.zext -& ich))

  class RoCCCommandWithAddr extends Bundle {
    val cmd = new RoCCCommand
    val dram_addr = UInt()
    val spad_addr = SInt()
    val I = SInt()
    val K = SInt()
  }
  val command_p = Module(new Pipeline[RoCCCommandWithAddr](new RoCCCommandWithAddr, latency)())
  // Commands
  val config_cmd = Wire(new RoCCCommand)
  config_cmd := DontCare
  config_cmd.inst.funct := CONFIG_CMD

  val config_cmd_rs1 = Wire(config_mvin_rs1_t.cloneType)
  config_cmd_rs1 := DontCare
  config_cmd_rs1.scale := MVIN_SCALE_IDENTITY
  config_cmd_rs1.stride := input_spad_stride
  config_cmd_rs1.pixel_repeats := req.max_pixels_per_row
  config_cmd_rs1.state_id := 0.U
  config_cmd_rs1.shrink := 0.U
  config_cmd_rs1._unused := 1.U
  config_cmd.rs1 := config_cmd_rs1.asUInt

  config_cmd.rs2 := dram_stride << req.downsample

  val mvin_cmd = Wire(new RoCCCommand)
  mvin_cmd := DontCare
  mvin_cmd.inst.funct := LOAD_CMD
  mvin_cmd.rs1 := 0.U // dram_addr
  mvin_cmd.rs2 := 0.U // mvin_cmd_rs2

  // Inputs and outputs
  io.req.ready := state === idle && !command_p.io.busy
  io.idle := state === idle && !command_p.io.busy
  io.loop_id := req.loop_id

  command_p.io.in.valid := state =/= idle && !io.wait_for_prev_loop && (req.dram_addr =/= 0.U)
  command_p.io.in.bits.cmd := Mux(state === config, config_cmd, mvin_cmd)
  command_p.io.in.bits.dram_addr := dram_addr
  command_p.io.in.bits.spad_addr := spad_addr
  command_p.io.in.bits.I := I
  command_p.io.in.bits.K := K

  command_p.io.out.ready := io.cmd.ready && !io.rob_overloaded
  io.cmd.valid := command_p.io.out.valid && !io.rob_overloaded
  io.cmd.bits := command_p.io.out.bits.cmd
  when (command_p.io.out.bits.cmd.inst.funct === LOAD_CMD) {
    val o = command_p.io.out.bits
    io.cmd.bits.rs1 := o.dram_addr
    val mvin_cmd_rs2 = Wire(mvin_rs2_t.cloneType)
    mvin_cmd_rs2 := DontCare
    mvin_cmd_rs2.num_rows := (o.I >> req.downsample).asUInt
    mvin_cmd_rs2.num_cols := o.K.asUInt
    mvin_cmd_rs2.local_addr := cast_to_sp_addr(mvin_cmd_rs2.local_addr, o.spad_addr)
    io.cmd.bits.rs2 := mvin_cmd_rs2.asUInt
  }

  // Sending outputs
  when(req.dram_addr === 0.U){
    state := idle
  }.elsewhen(command_p.io.in.fire) {
    when (state === config) {
      state := ld
    }.otherwise {
      val b_it = Mux(req.trans_input_3120, max_chs_per_mvin.asUInt, 1.U)
      val ich_it = Mux(req.trans_input_3120, 1.U, max_chs_per_mvin.asUInt)

      val next_ich = sFloorAdd(ich, ich_it, ichs.zext, 0.S)
      val next_icol = sFloorAdd(icol, I.asUInt, (icols_unpadded +& undilated(rpad)).zext, 0.S-&undilated(lpad).zext,
        next_ich === 0.S)
      val next_irow = sFloorAdd(irow, 1.U << req.downsample, (irows_unpadded +& undilated(dpad)).zext, 0.S-&undilated(upad).zext,
        next_icol === 0.S-&undilated(lpad).zext && next_ich === 0.S)
      val next_b = sFloorAdd(b, b_it, batches.zext, 0.S,
        next_irow === 0.S-&undilated(upad).zext && next_icol === 0.S-&undilated(lpad).zext && next_ich === 0.S)

      ich := next_ich
      icol := next_icol
      irow := next_irow
      b := next_b

      state := Mux(next_b === 0.S && next_irow === 0.S-&undilated(upad).zext && next_icol === 0.S-&undilated(lpad).zext && next_ich === 0.S,
        idle, ld)
    }
  }

  // Accepting requests
  when (io.req.fire) {
    req := io.req.bits
    state := config
    b := 0.S
    irow := 0.S -& ((io.req.bits.inner_bounds.upad +& io.req.bits.input_dilated) >> io.req.bits.input_dilated).zext
    icol := 0.S -& ((io.req.bits.inner_bounds.lpad +& io.req.bits.input_dilated) >> io.req.bits.input_dilated).zext
    ich := 0.S
  }

  /** IPOAT：Input 子生成器阻塞快照
    * I（Input 输入）：状态、依赖/RS 背压、pipeline 与 b/irow/icol/ich。
    * P（Process 处理）：保留各坐标低 8 位并组合控制状态，仅作观察。
    * O（Output 输出）：输入加载生成器停滞的精确位置和阻塞类别。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-19
    */
  io.deadlock_debug := Cat(0.U(24.W), b.asUInt.pad(8)(7, 0), irow.asUInt.pad(8)(7, 0),
    icol.asUInt.pad(8)(7, 0), ich.asUInt.pad(8)(7, 0), state.asUInt.pad(2), io.loop_id,
    io.wait_for_prev_loop, io.rob_overloaded, command_p.io.busy, io.cmd.valid, io.cmd.ready)
}

class LoopConvLdWeightReq(val coreMaxAddrBits: Int, val large_iterator_bitwidth: Int, val small_iterator_bitwidth: Int, val tiny_iterator_bitwidth: Int, val max_addr: Int, val concurrent_loops: Int)  extends Bundle {
  val outer_bounds = new LoopConvOuterBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val inner_bounds = new LoopConvInnerBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val derived_params = new LoopConvDerivedParams(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val addr_end = UInt(log2Up(max_addr+1).W)
  val dram_addr = UInt(coreMaxAddrBits.W)
  val trans_weight_1203 = Bool()
  val trans_weight_0132 = Bool()
  val dw = Bool()
  val loop_id = UInt(log2Up(concurrent_loops).W)
}

class LoopConvLdWeight(block_size: Int, coreMaxAddrBits: Int, large_iterator_bitwidth: Int,
                       small_iterator_bitwidth: Int, tiny_iterator_bitwidth: Int, max_addr: Int, input_w: Int,
                       max_block_len: Int, concurrent_loops: Int, latency: Int, config_mvin_rs1_t: ConfigMvinRs1,
                       mvin_rs2_t: MvinRs2)(implicit p: Parameters) extends Module {
  val MVIN_SCALE_IDENTITY = 0x3f800000.U // TODO get this from configs somehow

  val io = IO(new Bundle {
    val req = Flipped(Decoupled(new LoopConvLdWeightReq(coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth, max_addr, concurrent_loops)))
    val cmd = Decoupled(Output(new RoCCCommand))

    val idle = Output(Bool())
    val rob_overloaded = Input(Bool())
    val wait_for_prev_loop = Input(Bool())

    val loop_id = Output(UInt(log2Up(concurrent_loops).W))
    val deadlock_debug = Output(UInt(64.W))
    // （Author 作者：王志瑞）：导出权重 LOAD2 的区间计算量，仅用于片上被动记录。
    val trace = Output(Valid(new LoopConvTraceEvent))
  })

  object State extends ChiselEnum {
    val idle, config, ld = Value
  }
  import State._
  val state = RegInit(idle)

  val req = Reg(new LoopConvLdWeightReq(coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth, max_addr, concurrent_loops))
  import req.outer_bounds._
  import req.inner_bounds._
  import req.derived_params._

  // Derived parameters
  val max_chs_per_mvin = {
    val max_ochs_per_mvin = Mux(ochs < (max_block_len * block_size).U, ochs, (max_block_len * block_size).U)
    val max_kchs_per_mvin = Mux(kchs < (max_block_len * block_size).U, kchs, (max_block_len * block_size).U)
    Mux(req.trans_weight_0132, max_kchs_per_mvin, max_ochs_per_mvin)
  }

  val B_rows = Mux(req.trans_weight_0132, in_channels_per_bank * kcols * krows * ochs,
    out_channels_per_bank * kcols * krows * kchs)
  val addr_start = req.addr_end - B_rows

  // （Author 作者：王志瑞）：同时记录 exclusive end、B_rows 与计算后的起址，
  // 用于区分分区上界少一和权重行数多一，不参与任何控制或数据通路。
  io.trace.valid := io.cmd.fire && io.cmd.bits.inst.funct === LOAD2_CMD
  io.trace.bits.meta := req.loop_id
  io.trace.bits.payload0 := req.addr_end
  io.trace.bits.payload1 := B_rows
  io.trace.bits.payload2 := addr_start

  val dram_stride = MuxCase(weight_stride, Seq(
    req.dw -> 1.U,
    req.trans_weight_1203 -> (kernel_dim * kernel_dim * out_channels),
    req.trans_weight_0132 -> in_channels
  )) * (input_w/8).U

  // Iterators
  val och = Reg(UInt(large_iterator_bitwidth.W))
  val krow = Reg(UInt(tiny_iterator_bitwidth.W))
  val kcol = Reg(UInt(tiny_iterator_bitwidth.W))
  val kch = Reg(UInt(large_iterator_bitwidth.W))

  // Addresses
  val dram_offset = MuxCase(((krow*kernel_dim*in_channels +& kcol*in_channels +& kch) * weight_stride +& och) * (input_w/8).U, Seq(
    req.dw -> (krow * kernel_dim +& kcol) * (input_w/8).U,
    req.trans_weight_1203 -> (((kch*kernel_dim*kernel_dim +& krow*kernel_dim +& kcol) * out_channels +& och) * (input_w/8).U),
    req.trans_weight_0132 -> (((krow*kernel_dim*out_channels +& kcol*out_channels +& och) * in_channels +& kch) * (input_w/8).U)
  ))
  val dram_addr = req.dram_addr + LoopConv.castDramOffset(dram_offset)

  val spad_addr = Mux(req.trans_weight_0132,
    // The width expansions are added here solely to prevent Verilator's "WIDTH" warnings, despite making the code uglier
    addr_start + (kch / block_size.U(kch.getWidth.W)) * krows * kcols * ochs + krow * kcols * ochs + kcol * ochs + och,
    addr_start + (och / block_size.U(och.getWidth.W)) * krows * kcols * kchs + krow * kcols * kchs + kcol * kchs + kch)

  // Sizes
  val J = Mux(req.trans_weight_0132,
    Mux(kchs - kch > max_chs_per_mvin, max_chs_per_mvin, kchs - kch),
    Mux(ochs - och > max_chs_per_mvin, max_chs_per_mvin, ochs - och))
  val K = Mux(req.trans_weight_0132,
    Mux(ochs - och > block_size.U, block_size.U, ochs - och),
    Mux(kchs - kch > block_size.U, block_size.U, kchs - kch))

  class RoCCCommandWithAddr extends Bundle {
    val cmd = new RoCCCommand
    val dram_addr = UInt()
    val spad_addr = UInt()
    val K = UInt()
    val J = UInt()
  }
  val command_p = Module(new Pipeline[RoCCCommandWithAddr](new RoCCCommandWithAddr, latency)())

  // Commands
  val config_cmd = Wire(new RoCCCommand)
  config_cmd := DontCare
  config_cmd.inst.funct := CONFIG_CMD

  val config_cmd_rs1 = Wire(config_mvin_rs1_t.cloneType)
  config_cmd_rs1 := DontCare
  config_cmd_rs1.scale := MVIN_SCALE_IDENTITY
  config_cmd_rs1.stride := req.derived_params.weight_spad_stride
  config_cmd_rs1.pixel_repeats := 1.U
  config_cmd_rs1.state_id := 1.U
  config_cmd_rs1.shrink := 0.U
  config_cmd_rs1._unused := 1.U
  config_cmd.rs1 := config_cmd_rs1.asUInt

  config_cmd.rs2 := dram_stride

  val mvin_cmd = Wire(new RoCCCommand)
  mvin_cmd := DontCare
  mvin_cmd.inst.funct := LOAD2_CMD
  mvin_cmd.rs1 := 0.U // dram_addr
  mvin_cmd.rs2 := 0.U // mvin_cmd_rs2

  // Inputs and outputs
  io.req.ready := state === idle && !command_p.io.busy
  io.idle := state === idle && !command_p.io.busy
  io.loop_id := req.loop_id

  command_p.io.in.valid := state =/= idle && !io.wait_for_prev_loop && (req.dram_addr =/= 0.U)
  command_p.io.in.bits.cmd := Mux(state === config, config_cmd, mvin_cmd)
  command_p.io.in.bits.dram_addr := dram_addr
  command_p.io.in.bits.spad_addr := spad_addr
  command_p.io.in.bits.K := K
  command_p.io.in.bits.J := J

  command_p.io.out.ready := io.cmd.ready && !io.rob_overloaded
  io.cmd.valid := command_p.io.out.valid && !io.rob_overloaded
  io.cmd.bits := command_p.io.out.bits.cmd
  when (command_p.io.out.bits.cmd.inst.funct === LOAD2_CMD) {
    val o = command_p.io.out.bits
    io.cmd.bits.rs1 := o.dram_addr
    val mvin_cmd_rs2 = Wire(mvin_rs2_t.cloneType)
    mvin_cmd_rs2 := DontCare
    mvin_cmd_rs2.num_rows := o.K
    mvin_cmd_rs2.num_cols := o.J
    mvin_cmd_rs2.local_addr := cast_to_sp_addr(mvin_cmd_rs2.local_addr, o.spad_addr)
    io.cmd.bits.rs2 := mvin_cmd_rs2.asUInt
  }

  // Sending outputs
  when(req.dram_addr === 0.U){
    state := idle
  }.elsewhen(command_p.io.in.fire) {
    when (state === config) {
      state := ld
    }.otherwise {
      val och_it = Mux(req.trans_weight_0132, block_size.U, max_chs_per_mvin)
      val kch_it = Mux(req.trans_weight_0132, max_chs_per_mvin, block_size.U)

      val next_kch = floorAdd(kch, kch_it, kchs)
      val next_kcol = floorAdd(kcol, 1.U, kcols, next_kch === 0.U)
      val next_krow = floorAdd(krow, 1.U, krows, next_kcol === 0.U && next_kch === 0.U)
      val next_och = floorAdd(och, och_it, ochs, next_krow === 0.U && next_kcol === 0.U && next_kch === 0.U)

      kch := next_kch
      kcol := next_kcol
      krow := next_krow
      och := next_och

      state := Mux(next_och === 0.U && next_krow === 0.U && next_kcol === 0.U && next_kch === 0.U,
        idle, ld)
    }
  }

  // Accepting requests
  when (io.req.fire) {
    req := io.req.bits
    state := config
    kch := 0.U
    kcol := 0.U
    krow := 0.U
    och := 0.U
  }

  /** IPOAT：Weight 子生成器阻塞快照
    * I（Input 输入）：状态、依赖/RS 背压、pipeline 与 och/krow/kcol/kch。
    * P（Process 处理）：低 8 位迭代坐标和握手状态只读打包。
    * O（Output 输出）：权重加载生成器等待对象及最后迭代位置。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-19
    */
  io.deadlock_debug := Cat(0.U(24.W), och(7, 0), krow.pad(8)(7, 0), kcol.pad(8)(7, 0),
    kch(7, 0), state.asUInt.pad(2), io.loop_id, io.wait_for_prev_loop,
    io.rob_overloaded, command_p.io.busy, io.cmd.valid, io.cmd.ready)
}

/** IPOAT：V02/V03 执行请求快照
 * I（Input 输入）：RUN 对应的边界、驻留地址、资格、跨行开关和 generation。
 * P（Process 处理）：将后续执行所需字段封装进握手请求，隔离之后的 CONFIG。
 * O（Output 输出）：LoopConvExecute 接收的完整请求副本。
 * A（Author 作者）：王志瑞
 * T（Time 时间）：2026-09-09（注释补充日期）
 */
class LoopConvExecuteReq(val large_iterator_bitwidth: Int, val small_iterator_bitwidth: Int, val tiny_iterator_bitwidth: Int, val max_addr: Int, val max_acc_addr: Int, val concurrent_loops: Int)  extends Bundle {
  val outer_bounds = new LoopConvOuterBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val inner_bounds = new LoopConvInnerBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val derived_params = new LoopConvDerivedParams(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val viEligible = Bool()
  val viCrossRow = Bool()
  val viGeneration = UInt(16.W)
  val a_addr_start = UInt(log2Up(max_addr).W)
  val b_addr_end = UInt(log2Up(max_addr+1).W)
  val c_addr_start = UInt(log2Up(max_acc_addr).W)
  val wrot180 = Bool()
  val downsample = Bool()
  val max_pixels_per_row = UInt(small_iterator_bitwidth.W)
  val input_dilated = Bool()
  val trans_weight_0132 = Bool()
  val trans_input_3120 = Bool()
  val loop_id = UInt(log2Up(concurrent_loops).W)
}

class LoopConvExecute(block_size: Int, large_iterator_bitwidth: Int, small_iterator_bitwidth: Int, tiny_iterator_bitwidth: Int, max_addr: Int,
                      max_acc_addr: Int, concurrent_loops: Int, latency: Int,
                      config_ex_rs1_t: ConfigExRs1, preload_rs1_t: PreloadRs, preload_rs2_t: PreloadRs,
                      compute_rs1_t: ComputeRs, compute_rs2_t: ComputeRs)(implicit p: Parameters) extends Module {
  val io = IO(new Bundle {
    val req = Flipped(Decoupled(new LoopConvExecuteReq(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth, max_addr, max_acc_addr, concurrent_loops)))
    val cmd = Decoupled(Output(new RoCCCommand))
    val virtualI = Output(new VirtualICommand)

    val lda_completed = Input(Bool())
    val ldb_completed = Input(Bool())
    val ldd_completed = Input(Bool())

    val idle = Output(Bool())
    val rob_overloaded = Input(Bool())

    val loop_id = Output(UInt(log2Up(concurrent_loops).W))
    val deadlock_debug = Output(UInt(64.W))
  })

  object State extends ChiselEnum {
    val idle, config, pre, comp = Value
  }
  import State._
  val state = RegInit(idle)

  val req = Reg(new LoopConvExecuteReq(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth,
    max_addr, max_acc_addr, concurrent_loops))
  import req.outer_bounds._
  import req.inner_bounds._
  import req.derived_params._

  def undilated(x: UInt): UInt = (x +& req.input_dilated) >> req.input_dilated

  // Derived parameters
  val B_rows = Mux(req.trans_weight_0132, in_channels_per_bank * kcols * krows * ochs,
    out_channels_per_bank * kcols * krows * kchs)

  // Keep the original K/J schedule and loader-owned layout; flatten I only
  // within one image after validating the complete resident allocation.
  /** IPOAT：V03 跨行资格冻结
   * I（Input 输入）：req.fire、VI 资格/跨行开关、完整输入和输出足迹。
   * P（Process 处理）：检查物理容量及非空输出形状，在请求接受时锁存跨行资格。
   * O（Output 输出）：当前执行请求固定使用的 crossRows；不合格时使用旧 I 分组。
   * A（Author 作者）：王志瑞
   * T（Time 时间）：2026-09-09（注释补充日期）
   */
  val crossRows = RegInit(false.B)
  val requested = io.req.bits
  val requestedPixels = requested.inner_bounds.batches * requested.inner_bounds.orows * requested.inner_bounds.ocols
  val requestedInputEnd = requested.a_addr_start +&
    requested.derived_params.input_spad_stride * requested.derived_params.in_channels_per_bank
  val requestedOutputEnd = requested.c_addr_start +& requestedPixels * requested.derived_params.out_channels_per_bank
  when(io.req.fire) {
    crossRows := requested.viEligible && requested.viCrossRow &&
      requestedInputEnd <= max_addr.U && requestedOutputEnd <= max_acc_addr.U &&
      requested.inner_bounds.orows =/= 0.U && requested.inner_bounds.ocols =/= 0.U
  }
  val a_addr_start = req.a_addr_start
  val b_addr_start = req.b_addr_end - B_rows
  val c_addr_start = /*(BigInt(3) << 30).U |*/ req.c_addr_start

  // Iterators
  val och = Reg(UInt(large_iterator_bitwidth.W))
  val krow = Reg(UInt(tiny_iterator_bitwidth.W))
  val kcol = Reg(UInt(tiny_iterator_bitwidth.W))
  val kch = Reg(UInt(large_iterator_bitwidth.W))
  val b = Reg(UInt(large_iterator_bitwidth.W))
  val orow = Reg(UInt(small_iterator_bitwidth.W))
  val ocol = Reg(UInt(small_iterator_bitwidth.W))

  // TODO kernel-dilation and input-dilation can never be activated at the same time, so we can optimize out some multiplications by kernel_dilation
  val skip_iteration = state >= pre && req.input_dilated && (((krow * kernel_dilation +& orow -& upad)(0) & req.input_dilated).asBool ||
    ((kcol * kernel_dilation +& ocol -& lpad)(0) & req.input_dilated).asBool)

  val pixels = Mux(kcols - kcol > req.max_pixels_per_row, req.max_pixels_per_row, kcols - kcol)

  val irow = undilated(orow * stride +& krow * kernel_dilation)
  val icol = undilated(ocol * stride +& kcol * kernel_dilation)

  val legacyI = Mux(req.trans_input_3120,
    Mux(batches - b > block_size.U, block_size.U, batches - b),
    undilated(Mux(ocols - ocol > (block_size.U << req.input_dilated).asUInt, (block_size.U << req.input_dilated).asUInt, ocols - ocol)))
  /** IPOAT：V03 同图 I 分段
   * I（Input 输入）：当前输出行列、单图高宽、crossRows 和旧 I 长度。
   * P（Process 处理）：跨行时取单图剩余像素与 DIM 的较小值，不跨 batch 拼接。
   * O（Output 输出）：本次 I；13×13 对应64、64、41，K/J 次序保持原样。
   * A（Author 作者）：王志瑞
   * T（Time 时间）：2026-09-09（注释补充日期）
   */
  val imagePixelsRemaining = orows * ocols - (orow * ocols +& ocol)
  val I = Mux(crossRows, Mux(imagePixelsRemaining > block_size.U, block_size.U, imagePixelsRemaining), legacyI)
  val J = Mux(ochs - och > block_size.U, block_size.U, ochs - och)
  val K = pixels * Mux(kchs - kch > block_size.U, block_size.U, kchs - kch)

  // Addresses
  val a_addr = Mux(req.trans_input_3120,
    a_addr_start +& (b / block_size.U) * input_spad_stride +& kch * (irows >> req.downsample) * (icols >> req.downsample) +& (irow >> req.downsample) * (icols >> req.downsample) +& (icol >> req.downsample),
    a_addr_start +& (kch / block_size.U(kch.getWidth.W)) * input_spad_stride +& b * (irows >> req.downsample) * (icols >> req.downsample) +& (irow >> req.downsample) * (icols >> req.downsample) +& (icol >> req.downsample))

  // val c_addr = Mux(ex_overwrite && krow === 0.U && kcol === 0.U && kch === 0.U, d_addr_start, c_addr_start) +&
  //   (och / block_size.U) * batches * orows * ocols +& b * orows * ocols +& orow * ocols +& ocol

  // The width expansions are added here solely to prevent Verilator's "WIDTH" warnings, despite making the code uglier
  val c_addr = c_addr_start +&
    (och / block_size.U(och.getWidth.W)) * batches * orows * ocols +& b * orows * ocols +& orow * ocols +& ocol

  // val new_weights = b === 0.U && orow === 0.U && ocol === 0.U
  val new_weights = Reg(Bool())
  val krow_rot = Mux(req.wrot180, krows - krow - 1.U, krow)
  val kcol_rot = Mux(req.wrot180, kcols - kcol - 1.U, kcol)

  val b_addr = Mux(req.trans_weight_0132,
    b_addr_start +& (kch / block_size.U(och.getWidth.W)) * krows * kcols * ochs +& krow_rot * kcols * ochs +& kcol_rot * ochs +& och,
    b_addr_start +& (och / block_size.U(och.getWidth.W)) * krows * kcols * kchs +& krow_rot * kcols * kchs +& kcol_rot * kchs +& kch)

  class RoCCCommandWithAddr extends Bundle {
    val cmd = new RoCCCommand
    val virtualI = new VirtualICommand
    val a_addr = UInt()
    val b_addr = UInt()
    val c_addr = UInt()
    val I = UInt()
    val J = UInt()
    val K = UInt()
    val new_weights = Bool()
  }
  val command_p = Module(new Pipeline[RoCCCommandWithAddr](new RoCCCommandWithAddr, latency)())

  // Elaboration-time opt-in trace for validating batch weight reuse. This is
  // simulation output only; it is intentionally disabled for normal FPGA RTL.
  private val loopConvTrace = sys.env.get("GEMMINI_LOOP_CONV_TRACE").contains("1")

  // Commands
  val config_cmd = Wire(new RoCCCommand)
  config_cmd := DontCare
  config_cmd.inst.funct := CONFIG_CMD

  val config_cmd_rs1 = Wire(config_ex_rs1_t.cloneType)
  config_cmd_rs1 := DontCare
  config_cmd_rs1.a_stride := (irows * icols).asUInt
  config_cmd_rs1.set_only_strides := 1.U
  config_cmd_rs1.cmd_type := 0.U

  val config_cmd_rs2 = Wire(new ConfigExRs2)
  config_cmd_rs2 := DontCare
  config_cmd_rs2.c_stride := (orows * ocols).asUInt

  config_cmd.rs1 := config_cmd_rs1.asUInt
  config_cmd.rs2 := config_cmd_rs2.asUInt

  val pre_cmd = Wire(new RoCCCommand) // preload
  pre_cmd := DontCare
  pre_cmd.inst.funct := PRELOAD_CMD
  pre_cmd.rs1 := 0.U//(K << 48) | (J << 32) | pre_addr
  pre_cmd.rs2 := 0.U//(I << 48) | (J << 32) | c_addr

  val comp_cmd = Wire(new RoCCCommand()) // compute.preloaded
  comp_cmd := DontCare
  comp_cmd.inst.funct := Mux(new_weights, COMPUTE_AND_FLIP_CMD, COMPUTE_AND_STAY_CMD)
  comp_cmd.rs1 := 0.U//(I << 48) | (K << 32) | a_addr
  comp_cmd.rs2 := 0.U//(I << 48) | (J << 32) | GARBAGE_ADDR

  val ld_ahead = io.lda_completed && io.ldb_completed && io.ldd_completed

  // Inputs and outputs
  io.req.ready := state === idle && !command_p.io.busy
  io.idle := state === idle && !command_p.io.busy
  io.loop_id := req.loop_id

  command_p.io.in.valid := state =/= idle && !skip_iteration && ld_ahead
  command_p.io.in.bits.cmd := MuxCase(config_cmd, Seq((state === pre) -> pre_cmd, (state === comp) -> comp_cmd))
  command_p.io.in.bits.a_addr := a_addr
  command_p.io.in.bits.b_addr := b_addr
  command_p.io.in.bits.c_addr := c_addr
  command_p.io.in.bits.I := I
  command_p.io.in.bits.J := J
  command_p.io.in.bits.K := K
  command_p.io.in.bits.new_weights := new_weights
  val vi = WireInit(0.U.asTypeOf(new VirtualICommand))
  val vd = vi.desc
  // V02 retains the original I grouping and reads loader-materialized padding.
  // Coordinates here refer to the padded resident tile, not the full DRAM tensor.
  vi.valid := req.viEligible && state === comp
  vd.supported := true.B
  vd.owner := req.loop_id
  vd.generation := req.viGeneration
  vd.batches := 1.U; vd.tileRows := 1.U; vd.tileCols := I
  vd.batchStart := b
  vd.inputH := irows; vd.inputW := icols
  vd.outputY := irow; vd.outputX := icol
  vd.strideY := 1.U; vd.strideX := 1.U
  vd.dilationY := 1.U; vd.dilationX := 1.U
  vd.channelBlock := kch >> log2Up(block_size)
  vd.kValid := K; vd.jValid := J
  vd.input.base := req.a_addr_start
  vd.input.limit := req.a_addr_start +& input_spad_stride * in_channels_per_bank
  vd.input.channelStride := input_spad_stride
  vd.input.batchStride := irows * icols
  vd.input.rowStride := icols; vd.input.pixelStride := 1.U
  vd.input.residentH := irows; vd.input.residentW := icols
  vd.input.batches := batches
  vd.input.channelBlocks := in_channels_per_bank
  vd.output.base := c_addr
  vd.output.limit := max_acc_addr.U
  vd.output.groups := 1.U
  vi.valid := req.viEligible && state === comp &&
    (req.a_addr_start +& input_spad_stride * in_channels_per_bank) <= max_addr.U &&
    (c_addr +& I) <= max_acc_addr.U && irow < irows && (icol +& I) <= icols &&
    K > 0.U && K <= block_size.U && J > 0.U && J <= block_size.U
  /** IPOAT：V03 分段地址描述
   * I（Input 输入）：当前 b/orow/ocol、I、K/J、完整输出形状和驻留视图。
   * P（Process 处理）：用段起点描述本次 I，同时保留完整 P 作为 ACC 输出组间距。
   * O（Output 输出）：与 COMP 同步的 VI 描述符，尾段不扩展 ACC 分配。
   * A（Author 作者）：王志瑞
   * T（Time 时间）：2026-09-09（注释补充日期）
   */
  when(crossRows) {
    vi.valid := state === comp
    vd.segment := true.B
    vd.startB := b; vd.startR := orow; vd.startC := ocol; vd.segmentRows := I
    vd.batches := batches; vd.tileRows := orows; vd.tileCols := ocols
    vd.batchStart := 0.U
    vd.outputY := 0.U; vd.outputX := 0.U
    vd.kernelY := krow; vd.kernelX := kcol
    vd.dilationY := kernel_dilation; vd.dilationX := kernel_dilation
    vd.output.base := req.c_addr_start
    vd.output.groups := out_channels_per_bank
    vd.outputGroup := och >> log2Up(block_size)
  }
  command_p.io.in.bits.virtualI := vi
  io.virtualI := command_p.io.out.bits.virtualI

  command_p.io.out.ready := io.cmd.ready && !io.rob_overloaded
  io.cmd.valid := command_p.io.out.valid && !io.rob_overloaded
  io.cmd.bits := command_p.io.out.bits.cmd
  when (command_p.io.out.bits.cmd.inst.funct === PRELOAD_CMD) {
    val o = command_p.io.out.bits

    val pre_cmd_rs1 = Wire(preload_rs1_t.cloneType)
    pre_cmd_rs1 := DontCare
    pre_cmd_rs1.num_rows := o.K.asUInt
    pre_cmd_rs1.num_cols := o.J.asUInt
    pre_cmd_rs1.local_addr := Mux(o.new_weights, cast_to_sp_addr(pre_cmd_rs1.local_addr, o.b_addr),
      garbage_addr(pre_cmd_rs1.local_addr))

    val pre_cmd_rs2 = Wire(preload_rs2_t.cloneType)
    pre_cmd_rs2 := DontCare
    pre_cmd_rs2.num_rows := o.I.asUInt
    pre_cmd_rs2.num_cols := o.J.asUInt
    pre_cmd_rs2.local_addr := cast_to_acc_addr(pre_cmd_rs2.local_addr, o.c_addr, accumulate = true.B, read_full = false.B)

    io.cmd.bits.rs1 := pre_cmd_rs1.asUInt
    io.cmd.bits.rs2 := pre_cmd_rs2.asUInt
  }.elsewhen(command_p.io.out.bits.cmd.inst.funct =/= CONFIG_CMD) {
    val o = command_p.io.out.bits
    val comp_cmd_rs1 = Wire(compute_rs1_t.cloneType)
    comp_cmd_rs1 := DontCare
    comp_cmd_rs1.num_rows := o.I.asUInt
    comp_cmd_rs1.num_cols := o.K.asUInt
    comp_cmd_rs1.local_addr := cast_to_sp_addr(comp_cmd_rs1.local_addr, o.a_addr)

    val comp_cmd_rs2 = Wire(compute_rs2_t.cloneType)
    comp_cmd_rs2 := DontCare
    comp_cmd_rs2.num_rows := o.I.asUInt
    comp_cmd_rs2.num_cols := o.J.asUInt
    comp_cmd_rs2.local_addr := garbage_addr(comp_cmd_rs2.local_addr)

    io.cmd.bits.rs1 := comp_cmd_rs1.asUInt
    io.cmd.bits.rs2 := comp_cmd_rs2.asUInt
  }

  // Updating "new_weights"
  when (state === comp && command_p.io.in.fire) {
    new_weights := false.B
    if (loopConvTrace) {
      printf(p"LOOP_CONV_TRACE b=${b} och=${och} krow=${krow} kcol=${kcol} kch=${kch} new_weights=${new_weights} funct=${comp_cmd.inst.funct}\n")
    }
  }

  // Sending outputs
  when (command_p.io.in.fire || skip_iteration) {
    when (state === config) {
      state := pre
    }.elsewhen (state === pre) {
      state := comp
    }.otherwise {
      val b_it = Mux(req.trans_input_3120, block_size.U, 1.U)
      val ocol_it = Mux(skip_iteration || req.trans_input_3120, 1.U, block_size.U << req.input_dilated).asUInt

      /** IPOAT：V03 命令接受后的跨行更新
       * I（Input 输入）：COMP 接受事件、当前列、I 和单图剩余像素。
       * P（Process 处理）：有界跨行进位；图尾归零行列并推进 b，沿用原 K/J 迭代与权重更新条件。
       * O（Output 输出）：下一组 b/orow/ocol/K/J 及执行状态。
       * A（Author 作者）：王志瑞
       * T（Time 时间）：2026-09-09（注释补充日期）
       */
      val (crossCol, carryRows) = VirtualIRowAdvance(ocol, ocols, I)
      val imageEnd = I === imagePixelsRemaining
      val next_ocol = Mux(crossRows, Mux(imageEnd, 0.U, crossCol), floorAdd(ocol, ocol_it, ocols))
      val next_orow = Mux(crossRows, Mux(imageEnd, 0.U, orow +& carryRows), floorAdd(orow, 1.U, orows, next_ocol === 0.U))
      val next_b = floorAdd(b, b_it, batches, next_orow === 0.U && next_ocol === 0.U)
      val next_kch = floorAdd(kch, block_size.U, kchs,
        next_b === 0.U && next_orow === 0.U && next_ocol === 0.U)
      val next_kcol = floorAdd(kcol, req.max_pixels_per_row, kcols,
        next_kch === 0.U && next_b === 0.U && next_orow === 0.U && next_ocol === 0.U)
      val next_krow = floorAdd(krow, 1.U, krows,
        next_kcol === 0.U && next_kch === 0.U && next_b === 0.U && next_orow === 0.U && next_ocol === 0.U)
      val next_och = floorAdd(och, block_size.U, ochs, next_krow === 0.U &&
        next_kcol === 0.U && next_kch === 0.U && next_b === 0.U && next_orow === 0.U && next_ocol === 0.U)

      ocol := next_ocol
      orow := next_orow
      b := next_b
      kch := next_kch
      kcol := next_kcol
      krow := next_krow
      och := next_och

      when (next_b === 0.U && next_orow === 0.U && next_ocol === 0.U) {
        new_weights := true.B
      }

      state := Mux(next_och === 0.U && next_krow === 0.U && next_kcol === 0.U && next_kch === 0.U && next_b === 0.U &&
        next_orow === 0.U && next_ocol === 0.U,
        idle, pre)
    }
  }

  // Accepting requests
  when (io.req.fire) {
    req := io.req.bits
    state := Mux(io.req.bits.trans_input_3120, config, pre)

    b := 0.U
    orow := 0.U
    ocol := 0.U
    och := 0.U
    krow := 0.U
    kcol := 0.U
    kch := 0.U

    new_weights := true.B
  }

  /** IPOAT：Execute 子生成器阻塞快照
    * I（Input 输入）：状态、load-ahead、RS/pipeline 背压和七级卷积迭代坐标。
    * P（Process 处理）：控制位与各坐标低 8 位组合，不改变 PRELOAD/COMPUTE 调度。
    * O（Output 输出）：执行生成器究竟等待 load、RS ready 还是内部 pipeline。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-19
    */
  io.deadlock_debug := Cat(b(7, 0), orow(7, 0), ocol(7, 0), och(7, 0),
    krow.pad(8)(7, 0), kcol.pad(8)(7, 0), kch(7, 0), state.asUInt.pad(2),
    io.loop_id, ld_ahead, io.rob_overloaded, command_p.io.busy, io.cmd.valid, io.cmd.ready)
}

class LoopConvStReq(val coreMaxAddrBits: Int, val large_iterator_bitwidth: Int, val small_iterator_bitwidth: Int, val tiny_iterator_bitwidth: Int, val max_acc_addr: Int, val concurrent_loops: Int)  extends Bundle {
  val outer_bounds = new LoopConvOuterBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val inner_bounds = new LoopConvInnerBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val derived_params = new LoopConvDerivedParams(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val addr_start = UInt(log2Up(max_acc_addr).W)
  val dram_addr = UInt(coreMaxAddrBits.W)
  val no_pool = Bool()
  val activation = UInt(Activation.bitwidth.W)
  val trans_output_1203 = Bool()
  val loop_id = UInt(log2Up(concurrent_loops).W)
}

class LoopConvSt(block_size: Int, coreMaxAddrBits: Int, large_iterator_bitwidth: Int, small_iterator_bitwidth: Int, tiny_iterator_bitwidth: Int, max_acc_addr: Int, input_w: Int, concurrent_loops: Int, latency: Int, config_mvout_rs2_t: ConfigMvoutRs2, mvout_rs2_t: MvoutRs2)(implicit p: Parameters) extends Module {
  val ACC_SCALE_NO_CHANGE = ~(0.U(32.W)) // TODO get this from ISA description somehow

  val io = IO(new Bundle {
    val req = Flipped(Decoupled(new LoopConvStReq(coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth: Int, max_acc_addr, concurrent_loops)))
    val cmd = Decoupled(Output(new RoCCCommand))

    val ex_completed = Input(Bool())

    val idle = Output(Bool())
    val rob_overloaded = Input(Bool())

    val loop_id = Output(UInt(log2Up(concurrent_loops).W))
    val deadlock_debug = Output(UInt(64.W))
  })

  object State extends ChiselEnum {
    val idle, st, pre_pool_config, pool, post_pool_config = Value
  }
  import State._
  val state = RegInit(idle)
  private val loopConvTrace = sys.env.get("GEMMINI_LOOP_CONV_TRACE").contains("1")

  val req = Reg(new LoopConvStReq(coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth: Int, max_acc_addr, concurrent_loops))
  import req.outer_bounds._
  import req.inner_bounds._
  import req.derived_params._

  val acc_addr_start = req.addr_start

  // Derived parameters
  val skip = req.dram_addr === 0.U

  // Iterators
  val b = Reg(UInt(large_iterator_bitwidth.W))
  val orow = Reg(UInt(small_iterator_bitwidth.W))
  val ocol = Reg(UInt(small_iterator_bitwidth.W))
  val och = Reg(UInt(large_iterator_bitwidth.W))

  // Addresses
  val dram_offset = Mux(req.trans_output_1203,
    ((orow*out_col_dim*batch_size +& ocol*batch_size +& b) * out_channels +& och) * (input_w/8).U,
    ((b*out_row_dim*out_col_dim +& orow*out_col_dim +& ocol) * out_stride +& och) * (input_w/8).U)
  val dram_addr = req.dram_addr + LoopConv.castDramOffset(dram_offset)
  val spad_addr = acc_addr_start +& (och / block_size.U(och.getWidth.W)) * batches * orows * ocols +& b * orows * ocols +& orow * ocols +& ocol

  val pool_dram_addr = req.dram_addr + ((b * pool_out_col_dim * pool_out_row_dim) * out_stride + och) * (input_w/8).U
  val pool_spad_addr = acc_addr_start +& (och / block_size.U(och.getWidth.W)) * batches * orows * ocols +& b * orows * ocols

  // Sizes
  val I = Mux(ocols - ocol > block_size.U, block_size.U, ocols - ocol)
  val J = Mux(ochs - och > block_size.U, block_size.U, ochs - och)

  val channels = J

  class RoCCCommandWithAddr extends Bundle {
    val cmd = new RoCCCommand
    val dram_addr = UInt()
    val spad_addr = UInt()
    val pool_dram_addr = UInt()
    val pool_spad_addr = UInt()
    val channels = UInt()
    val is_pool = Bool()
    val I = UInt()
    val J = UInt()
  }
  val command_p = Module(new Pipeline[RoCCCommandWithAddr](new RoCCCommandWithAddr, latency)())
  // Commands
  val mvout_cmd = Wire(new RoCCCommand)
  mvout_cmd := DontCare
  mvout_cmd.inst.funct := STORE_CMD
  mvout_cmd.rs1 := 0.U // dram_addr
  mvout_cmd.rs2 := 0.U // mvout_cmd_rs2

  val pre_pool_config_cmd = Wire(new RoCCCommand)
  pre_pool_config_cmd := DontCare
  pre_pool_config_cmd.inst.funct := CONFIG_CMD
  val pre_pool_config_cmd_rs1 = Wire(new ConfigMvoutRs1)
  pre_pool_config_cmd_rs1 := DontCare
  pre_pool_config_cmd_rs1.ocols := ocols
  pre_pool_config_cmd_rs1.orows := orows
  pre_pool_config_cmd_rs1.pocols := pocols
  pre_pool_config_cmd_rs1.porows := porows
  pre_pool_config_cmd_rs1.pool_out_dim := pool_out_col_dim
  pre_pool_config_cmd_rs1.lpad := plpad
  pre_pool_config_cmd_rs1.upad := pupad
  pre_pool_config_cmd_rs1.pool_size := pool_size
  pre_pool_config_cmd_rs1.pool_stride := pool_stride
  pre_pool_config_cmd_rs1.activation := req.activation
  pre_pool_config_cmd_rs1.cmd_type := CONFIG_STORE
  pre_pool_config_cmd.rs1 := pre_pool_config_cmd_rs1.asUInt

  val pre_pool_config_cmd_rs2 = Wire(config_mvout_rs2_t.cloneType)
  pre_pool_config_cmd_rs2 := DontCare
  pre_pool_config_cmd_rs2.acc_scale := ACC_SCALE_NO_CHANGE
  pre_pool_config_cmd_rs2.stride := out_stride * (input_w / 8).U
  pre_pool_config_cmd.rs2 := pre_pool_config_cmd_rs2.asUInt

  val post_pool_config_cmd = Wire(new RoCCCommand)
  post_pool_config_cmd := DontCare
  post_pool_config_cmd.inst.funct := CONFIG_CMD

  val post_pool_config_cmd_rs1 = Wire(new ConfigMvoutRs1)
  post_pool_config_cmd_rs1 := DontCare
  post_pool_config_cmd_rs1.activation := req.activation
  post_pool_config_cmd_rs1.cmd_type := CONFIG_STORE
  post_pool_config_cmd.rs1 := post_pool_config_cmd_rs1.asUInt

  val post_pool_config_cmd_rs2 = Wire(config_mvout_rs2_t.cloneType)
  post_pool_config_cmd_rs2 := DontCare
  post_pool_config_cmd_rs2.acc_scale := ACC_SCALE_NO_CHANGE
  post_pool_config_cmd_rs2.stride := out_stride * (input_w / 8).U
  post_pool_config_cmd.rs2 := post_pool_config_cmd_rs2.asUInt

  val pool_cmd = Wire(new RoCCCommand)
  pool_cmd := DontCare
  pool_cmd.inst.funct := STORE_CMD
  pool_cmd.rs1 := 0.U//pool_dram_addr
  pool_cmd.rs2 := 0.U//(channels << 32.U) | pool_spad_addr

  // Inputs and outputs
  io.req.ready := state === idle && !command_p.io.busy
  io.idle := state === idle && !command_p.io.busy
  io.loop_id := req.loop_id

  command_p.io.in.valid := state =/= idle && !skip && io.ex_completed
  command_p.io.in.bits.cmd := MuxLookup(state.asUInt, mvout_cmd)(Seq(
    pre_pool_config.asUInt -> pre_pool_config_cmd,
    pool.asUInt -> pool_cmd,
    post_pool_config.asUInt -> post_pool_config_cmd)
  )
  command_p.io.in.bits.is_pool := state === pool
  command_p.io.in.bits.dram_addr := dram_addr
  command_p.io.in.bits.spad_addr := spad_addr
  command_p.io.in.bits.pool_spad_addr := pool_spad_addr
  command_p.io.in.bits.pool_dram_addr := pool_dram_addr
  command_p.io.in.bits.channels := channels
  command_p.io.in.bits.I := I
  command_p.io.in.bits.J := J

  command_p.io.out.ready := io.cmd.ready && !io.rob_overloaded
  io.cmd.valid := command_p.io.out.valid && !io.rob_overloaded
  io.cmd.bits := command_p.io.out.bits.cmd
  when (command_p.io.out.bits.cmd.inst.funct === STORE_CMD) {
    val o = command_p.io.out.bits
    when (o.is_pool) {
      val pool_mvout_cmd_rs2 = Wire(mvout_rs2_t.cloneType)
      pool_mvout_cmd_rs2 := DontCare
      pool_mvout_cmd_rs2.num_cols := o.channels
      pool_mvout_cmd_rs2.local_addr := cast_to_acc_addr(pool_mvout_cmd_rs2.local_addr, o.pool_spad_addr, accumulate = false.B, read_full = false.B)

      io.cmd.bits.rs1 := o.pool_dram_addr
      io.cmd.bits.rs2 := pool_mvout_cmd_rs2.asUInt
    } .otherwise {
      val mvout_cmd_rs2 = Wire(mvout_rs2_t.cloneType)
      mvout_cmd_rs2 := DontCare
      mvout_cmd_rs2.num_rows := o.I.asUInt
      mvout_cmd_rs2.num_cols := o.J.asUInt
      mvout_cmd_rs2.local_addr := cast_to_acc_addr(mvout_cmd_rs2.local_addr, o.spad_addr, accumulate = false.B, read_full = false.B)

      io.cmd.bits.rs1 := o.dram_addr
      io.cmd.bits.rs2 := mvout_cmd_rs2.asUInt
    }
  }

  if (loopConvTrace) {
    when (io.req.fire) {
      printf(p"LC_ST_REQ loop=${io.req.bits.loop_id} dram=0x${io.req.bits.dram_addr} acc=0x${io.req.bits.addr_start} batches=${io.req.bits.inner_bounds.batches} orows=${io.req.bits.inner_bounds.orows} ocols=${io.req.bits.inner_bounds.ocols} pochs=${io.req.bits.inner_bounds.pochs}\n")
    }
    when (io.cmd.fire) {
      printf(p"LC_ST_CMD loop=${io.loop_id} b=${b} orow=${orow} ocol=${ocol} och=${och} dram=0x${dram_addr} spad=0x${spad_addr}\n")
    }
    when (io.idle && state =/= idle) {
      printf(p"LC_ST_IDLE loop=${io.loop_id} b=${b} orow=${orow} ocol=${ocol} och=${och}\n")
    }
  }

  // Sending outputs
  when (skip) {
    state := idle
  }.elsewhen(command_p.io.in.fire) {
    when (req.no_pool) {
      val next_och = floorAdd(och, block_size.U, ochs)
      val next_ocol = floorAdd(ocol, block_size.U, ocols, next_och === 0.U)
      val next_orow = floorAdd(orow, 1.U, orows, next_ocol === 0.U && next_och === 0.U)
      val next_b = floorAdd(b, 1.U, batches, next_orow === 0.U && next_ocol === 0.U && next_och === 0.U)

      och := next_och
      ocol := next_ocol
      orow := next_orow
      b := next_b

      state := Mux(next_b === 0.U && next_orow === 0.U && next_ocol === 0.U && next_och === 0.U,
        idle, st)
    }.elsewhen(state === pre_pool_config) {
      state := pool
    }.elsewhen(state === post_pool_config) {
      state := idle
    }.otherwise {
      val next_och = floorAdd(och, block_size.U, ochs)
      val next_b = floorAdd(b, 1.U, batches, next_och === 0.U)

      och := next_och
      b := next_b

      state := Mux(next_b === 0.U && next_och === 0.U,
        post_pool_config, pool)
    }
  }

  // Accepting requests
  when (io.req.fire) {
    req := io.req.bits
    state := Mux(io.req.bits.no_pool, st, pre_pool_config)

    b := 0.U
    orow := 0.U
    ocol := 0.U
    och := 0.U
  }

  /** IPOAT：Store 子生成器阻塞快照
    * I（Input 输入）：状态、execute-ahead、RS/pipeline 背压和 b/orow/ocol/och。
    * P（Process 处理）：只读组合为固定 64-bit 页。
    * O（Output 输出）：Store 生成器是否在等 EX、RS 或 pipeline 出口。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-19
    */
  io.deadlock_debug := Cat(0.U(24.W), b(7, 0), orow(7, 0), ocol(7, 0), och(7, 0),
    state.asUInt.pad(3), io.loop_id, io.ex_completed, io.rob_overloaded,
    command_p.io.busy, io.cmd.valid)
}

class LoopConvState(val block_size: Int, val large_iterator_bitwidth: Int, val small_iterator_bitwidth: Int, val tiny_iterator_bitwidth: Int, val coreMaxAddrBits: Int, val max_addr: Int, val max_acc_addr: Int) extends Bundle {
  /** IPOAT：LoopConv 请求身份
    * I（Input 输入）：每次 LOOP_CONV_WS 被接受时的全局请求序号。
    * P（Process 处理）：序号随 slot 状态保存，slot 释放时清零。
    * O（Output 输出）：诊断快照可把两个 slot 映射回具体请求。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-17
    */
  val request_seq = UInt(32.W)
  val viEligible = Bool()
  val viCrossRow = Bool()
  val viGeneration = UInt(16.W)
  val outer_bounds = new LoopConvOuterBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)
  val inner_bounds = new LoopConvInnerBounds(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth)

  val bias_dram_addr = UInt(coreMaxAddrBits.W)
  val weights_dram_addr = UInt(coreMaxAddrBits.W)
  val input_dram_addr = UInt(coreMaxAddrBits.W)
  val output_dram_addr = UInt(coreMaxAddrBits.W)

  val no_bias = Bool()
  val wrot180 = Bool()
  val no_pool = Bool()
  val downsample = Bool()
  val input_dilated = Bool()
  val activation = UInt(Activation.bitwidth.W)
  val trans_output_1203 = Bool()
  val trans_weight_1203 = Bool()
  val trans_weight_0132 = Bool()
  val trans_input_3120 = Bool()
  val dw = Bool()

  val max_pixels_per_row = UInt(small_iterator_bitwidth.W)
  val a_ex_spad_id = UInt(2.W)
  val b_ex_spad_id = UInt(2.W)

  val configured = Bool()

  val running = Bool()

  val ld_bias_started = Bool()
  val ld_input_started = Bool()
  val ld_weights_started = Bool()
  val ex_started = Bool()
  val st_started = Bool()

  val ld_bias_completed = Bool()
  val ld_input_completed = Bool()
  val ld_weights_completed = Bool()
  val ex_completed = Bool()
  val st_completed = Bool()

  def all_completed(dummy: Int=0): Bool = ld_bias_completed && ld_input_completed && ld_weights_completed && ex_completed && st_completed

  val a_addr_start = UInt(log2Up(max_addr).W)
  val b_addr_end = UInt(log2Up(max_addr+1).W)

  def derived_params(dummy: Int=0): LoopConvDerivedParams = {
    import outer_bounds.{stride, kernel_dilation}
    import inner_bounds.{batches, pochs, orows, ocols, krows, kcols, upad, dpad, lpad, rpad, kchs}

    val result = Wire(new LoopConvDerivedParams(large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth))

    result.ochs := pochs

    val dilated_krows = krows + (kernel_dilation - 1.U)*(krows - 1.U)
    val dilated_kcols = kcols + (kernel_dilation - 1.U)*(kcols - 1.U)

    val irows_without_dilation = orows * stride +& dilated_krows -& 1.U
    val icols_without_dilation = ocols * stride +& dilated_kcols -& 1.U
    val irows_unpadded_without_dilation = irows_without_dilation -& upad -& dpad
    val icols_unpadded_without_dilation = icols_without_dilation -& lpad -& rpad

    def undilated(x: UInt): UInt = (x +& input_dilated) >> input_dilated

    val irows_unpadded = undilated(irows_unpadded_without_dilation)
    val icols_unpadded = undilated(icols_unpadded_without_dilation)

    result.irows := Mux(input_dilated, irows_unpadded +& undilated(upad) +& undilated(dpad), irows_without_dilation)
    result.icols := Mux(input_dilated, icols_unpadded +& undilated(lpad) +& undilated(rpad), icols_without_dilation)

    result.irows_unpadded := irows_unpadded
    result.icols_unpadded := icols_unpadded

    result.ichs := kchs

    result.out_channels_per_bank := result.ochs / block_size.U(result.ochs.getWidth.W) +& (result.ochs % block_size.U =/= 0.U)
    result.in_channels_per_bank := result.ichs / block_size.U(result.ochs.getWidth.W) +& (result.ichs % block_size.U =/= 0.U)

    result.bias_spad_stride := batches * orows * ocols
    result.input_spad_stride := Mux(trans_input_3120,
      result.ichs * (result.irows >> downsample) * (result.icols >> downsample),
      batches * (result.irows >> downsample) * (result.icols >> downsample))
    result.weight_spad_stride := Mux(trans_weight_0132, krows * kcols * pochs, krows * kcols * kchs)

    // result.ex_overwrite := bias_dram_addr =/= 0.U && no_bias

    result
  }

  def reset(): Unit = {
    request_seq := 0.U
    configured := false.B

    running := false.B

    ld_bias_started := false.B
    ld_input_started := false.B
    ld_weights_started := false.B
    ex_started := false.B
    st_started := false.B

    ld_bias_completed := false.B
    ld_input_completed := false.B
    ld_weights_completed := false.B
    ex_completed := false.B
    st_completed := false.B
  }
}

class LoopConv (block_size: Int, coreMaxAddrBits: Int, reservation_station_size: Int, max_lds: Int, max_exs: Int, max_sts: Int,
                max_addr: Int, max_acc_addr: Int, input_w: Int, acc_w: Int, dma_max_bytes: Int,
                config_mvin_rs1_t: ConfigMvinRs1, mvin_rs2_t: MvinRs2, config_mvout_rs2_t: ConfigMvoutRs2, mvout_rs2_t: MvoutRs2,
                config_ex_rs1_t: ConfigExRs1, preload_rs1_t: PreloadRs, preload_rs2_t: PreloadRs,
                compute_rs1_t: ComputeRs, compute_rs2_t: ComputeRs,
                has_training_convs: Boolean, has_max_pool: Boolean, has_first_layer_optimizations: Boolean,
                has_dw_convs: Boolean, virtual_i_enable: Boolean = false, virtual_i_cross_row: Boolean = false)
  (implicit p: Parameters) extends Module {
  val large_iterator_bitwidth = 16
  val small_iterator_bitwidth = 16 // 8
  val tiny_iterator_bitwidth = 16 // 4

  val max_block_len = (dma_max_bytes / (block_size * (input_w / 8))) max 1
  val max_block_len_acc = (dma_max_bytes / (block_size * (acc_w / 8))) max 1

  val io = IO(new Bundle {
    val in = Flipped(Decoupled(new GemminiCmd(reservation_station_size)))
    val out = Decoupled(new GemminiCmd(reservation_station_size))
    val ld_completed = Input(UInt(log2Up(reservation_station_size+1).W))
    val st_completed = Input(UInt(log2Up(reservation_station_size+1).W))
    val ex_completed = Input(UInt(log2Up(reservation_station_size+1).W))
    val busy = Output(Bool())
    // （Output 输出；Author 作者：王志瑞）：request_retire 必须与 slot 真正 reset/free 同拍，不能用任一
    // 子单元的 completed 或 all_completed 代替。running_slot_count 仅供状态观测。
    val request_retire = Output(Bool())
    val running_slot_count = Output(UInt(2.W))
    // （Author 作者：王志瑞）：LoopConvLdWeight 内部地址计算的被动观测值。
    val ldWeightTrace = Output(Valid(new LoopConvTraceEvent))
    /** IPOAT：LoopConv 死锁观测端口
      * I：slot、子引擎、utilization 与握手状态；P：只读打包；
      * O：四个 64-bit 页；A：王志瑞；T：2026-09-17。
      */
    val deadlock_debug = Output(Vec(9, UInt(64.W)))
  })

  // Create states
  val concurrent_loops = 2
  private val loopConvTrace = sys.env.get("GEMMINI_LOOP_CONV_TRACE").contains("1")
  val loops = Reg(Vec(concurrent_loops, new LoopConvState(block_size, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth, coreMaxAddrBits, max_addr, max_acc_addr)))
  val head_loop_id = RegInit(0.U(log2Up(concurrent_loops).W))
  val tail_loop_id = (~head_loop_id).asUInt // This is the loop that we always try to configure if available
  val head_loop = loops(head_loop_id)
  val tail_loop = loops(tail_loop_id)

  val viEpoch = RegInit(0.U(16.W))
  /** IPOAT：请求序号分配器
    * I（Input 输入）：LOOP_CONV_WS 的 cmd.fire。
    * P（Process 处理）：单调递增并在接受同拍写入目标 slot。
    * O（Output 输出）：两个 running slot 的稳定 request_seq。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-17
    */
  val requestSeq = RegInit(0.U(32.W))
  val viRunStatus = Reg(Vec(concurrent_loops, chiselTypeOf(io.in.bits.cmd.status)))
  val loop_configured = loops.map(_.configured).reduce(_ || _)
  io.running_slot_count := PopCount(loops.map(_.running))

  val loop_being_configured_id = Mux(head_loop.configured, tail_loop_id, head_loop_id)
  val loop_being_configured = loops(loop_being_configured_id)

  // Create inner modules
  val latency = 2
  val ld_bias = Module(new LoopConvLdBias(block_size, coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth, max_acc_addr, acc_w, max_block_len_acc, concurrent_loops, latency, config_mvin_rs1_t, mvin_rs2_t))
  val ld_input = Module(new LoopConvLdInput(block_size, coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth, max_addr, input_w, max_block_len, concurrent_loops, latency, config_mvin_rs1_t, mvin_rs2_t))
  val ld_weights = Module(new LoopConvLdWeight(block_size, coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth, max_addr, input_w, max_block_len, concurrent_loops, latency, config_mvin_rs1_t, mvin_rs2_t))
  io.ldWeightTrace := ld_weights.io.trace
  val ex = Module(new LoopConvExecute(block_size, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth, max_addr, max_acc_addr, concurrent_loops, latency, config_ex_rs1_t, preload_rs1_t, preload_rs2_t, compute_rs1_t, compute_rs2_t))
  val st = Module(new LoopConvSt(block_size, coreMaxAddrBits, large_iterator_bitwidth, small_iterator_bitwidth, tiny_iterator_bitwidth, max_acc_addr, input_w, concurrent_loops, latency, config_mvout_rs2_t, mvout_rs2_t))

  // Create command queue
  val cmd = Queue(io.in)

  io.busy := cmd.valid || loop_configured

  // Create arbiter
  val arb = Module(new Arbiter(new RoCCCommand, 5))
  arb.io.in(0) <> st.io.cmd
  arb.io.in(1) <> ex.io.cmd
  arb.io.in(2) <> ld_bias.io.cmd
  arb.io.in(3) <> ld_weights.io.cmd
  arb.io.in(4) <> ld_input.io.cmd
  val unrolled_cmd = arb.io.out

  // Create reservation station utilization counters
  val ld_utilization = RegInit(0.U(log2Up(max_lds+1).W))
  val st_utilization = RegInit(0.U(log2Up(max_sts+1).W))
  val ex_utilization = RegInit(0.U(log2Up(max_exs+1).W))

  ld_utilization := ld_utilization +& (ld_bias.io.cmd.fire || ld_weights.io.cmd.fire || ld_input.io.cmd.fire) -& io.ld_completed
  st_utilization := st_utilization +& st.io.cmd.fire -& io.st_completed
  ex_utilization := ex_utilization +& ex.io.cmd.fire -& io.ex_completed

  assert(ld_utilization >= io.ld_completed, "ld utilization underflow")
  assert(st_utilization >= io.st_completed, "st utilization underflow")
  assert(ex_utilization >= io.ex_completed, "ex utilization underflow")

  // Wire up unrolled command output
  val is_loop_run_cmd = cmd.bits.cmd.inst.funct === LOOP_CONV_WS
  val is_loop_config_cmd = cmd.bits.cmd.inst.funct >= LOOP_CONV_WS_CONFIG_1 && cmd.bits.cmd.inst.funct <= LOOP_CONV_WS_CONFIG_6
  val is_loop_cmd = is_loop_run_cmd || is_loop_config_cmd

  io.out.bits.cmd := Mux(loop_configured, unrolled_cmd.bits, cmd.bits.cmd)
  io.out.bits.cmd.status := cmd.bits.cmd.status // TODO This is not guaranteed to be the correct fix! We must fix this
  if (virtual_i_enable) {
    val statusSlot = MuxCase(ld_input.io.loop_id, Seq(
      (arb.io.chosen === 0.U) -> st.io.loop_id,
      (arb.io.chosen === 1.U) -> ex.io.loop_id,
      (arb.io.chosen === 2.U) -> ld_bias.io.loop_id,
      (arb.io.chosen === 3.U) -> ld_weights.io.loop_id))
    when(loop_configured) { io.out.bits.cmd.status := viRunStatus(statusSlot) }
  }
  io.out.bits.rob_id := DontCare
  io.out.bits.virtualI := Mux(loop_configured,
    Mux(arb.io.chosen === 1.U, ex.io.virtualI, 0.U.asTypeOf(new VirtualICommand)), cmd.bits.virtualI)
  io.out.bits.from_matmul_fsm := Mux(loop_configured, false.B, cmd.bits.from_matmul_fsm)
  io.out.bits.from_conv_fsm := Mux(loop_configured, true.B, cmd.bits.from_conv_fsm)
  io.out.valid := Mux(loop_configured, unrolled_cmd.valid, cmd.valid && !is_loop_config_cmd && !is_loop_run_cmd)

  cmd.ready := Mux(is_loop_cmd, !loop_being_configured.configured, !loop_configured && io.out.ready)
  arb.io.out.ready := io.out.ready

  // Wire up waiting-for-loads signals
  val ex_is_waiting_for_loads = loops(ex.io.loop_id).ex_started && !loops(ex.io.loop_id).ex_completed &&
    !(loops(ex.io.loop_id).ld_input_completed && loops(ex.io.loop_id).ld_weights_completed &&
      loops(ex.io.loop_id).ld_bias_completed)

  ld_bias.io.wait_for_prev_loop := ex_is_waiting_for_loads && ld_bias.io.loop_id =/= ex.io.loop_id
  ld_weights.io.wait_for_prev_loop := ex_is_waiting_for_loads && ld_weights.io.loop_id =/= ex.io.loop_id
  ld_input.io.wait_for_prev_loop := ex_is_waiting_for_loads && ld_input.io.loop_id =/= ex.io.loop_id

  // Wire up overloaded signals
  ld_bias.io.rob_overloaded := ld_utilization >= max_lds.U
  ld_input.io.rob_overloaded := ld_utilization >= max_lds.U
  ld_weights.io.rob_overloaded := ld_utilization >= max_lds.U
  ex.io.rob_overloaded := ex_utilization >= max_exs.U
  st.io.rob_overloaded := st_utilization >= max_sts.U

  // Wire up iterator inputs
  ex.io.lda_completed := (ld_input.io.loop_id =/= ex.io.loop_id) || ld_input.io.idle
  ex.io.ldb_completed := (ld_weights.io.loop_id =/= ex.io.loop_id) || ld_weights.io.idle
  ex.io.ldd_completed := (ld_bias.io.loop_id =/= ex.io.loop_id) || ld_bias.io.idle
  st.io.ex_completed := (ex.io.loop_id =/= st.io.loop_id) || ex.io.idle

  // Create config registers
  when(cmd.valid && is_loop_cmd && !loop_being_configured.configured) {

    switch (cmd.bits.cmd.inst.funct) {
      is (LOOP_CONV_WS_CONFIG_1) {
        loop_being_configured.outer_bounds.out_channels := cmd.bits.cmd.rs1(63, 48)
        loop_being_configured.outer_bounds.in_channels := cmd.bits.cmd.rs1(47, 32)
        loop_being_configured.outer_bounds.in_row_dim := cmd.bits.cmd.rs1(31, 16)
        loop_being_configured.outer_bounds.batch_size := cmd.bits.cmd.rs1(15, 0)

        loop_being_configured.outer_bounds.padding := cmd.bits.cmd.rs2(63, 56)
        loop_being_configured.outer_bounds.stride := cmd.bits.cmd.rs2(55, 48)
        loop_being_configured.outer_bounds.out_col_dim := cmd.bits.cmd.rs2(47, 32)
        loop_being_configured.outer_bounds.pool_out_row_dim := cmd.bits.cmd.rs2(31, 16)
        loop_being_configured.outer_bounds.out_row_dim := cmd.bits.cmd.rs2(15, 0)
      }

      is (LOOP_CONV_WS_CONFIG_2) {
        loop_being_configured.outer_bounds.kernel_dim := cmd.bits.cmd.rs1(63, 48)
        loop_being_configured.outer_bounds.pool_out_col_dim := cmd.bits.cmd.rs1(47, 32)
        loop_being_configured.outer_bounds.pool_size := (if (!has_max_pool) 1.U else cmd.bits.cmd.rs1(31, 16))
        loop_being_configured.outer_bounds.pool_stride := (if (!has_max_pool) 1.U else cmd.bits.cmd.rs1(15, 8))
        loop_being_configured.outer_bounds.pool_padding := (if (!has_max_pool) 0.U else cmd.bits.cmd.rs1(7, 0))

        loop_being_configured.inner_bounds.batches := cmd.bits.cmd.rs2(63, 48)
        loop_being_configured.inner_bounds.porows := cmd.bits.cmd.rs2(47, 32)
        loop_being_configured.inner_bounds.pocols := cmd.bits.cmd.rs2(31, 16)
        loop_being_configured.inner_bounds.pochs := cmd.bits.cmd.rs2(15, 0)
      }

      is (LOOP_CONV_WS_CONFIG_3) {
        loop_being_configured.inner_bounds.krows := cmd.bits.cmd.rs1(63, 48)
        loop_being_configured.inner_bounds.kcols := cmd.bits.cmd.rs1(47, 32)
        loop_being_configured.inner_bounds.kchs := cmd.bits.cmd.rs1(31, 16)
        loop_being_configured.inner_bounds.lpad := cmd.bits.cmd.rs1(15, 0)

        loop_being_configured.inner_bounds.rpad := cmd.bits.cmd.rs2(63, 48)
        loop_being_configured.inner_bounds.upad := cmd.bits.cmd.rs2(47, 32)
        loop_being_configured.inner_bounds.dpad := cmd.bits.cmd.rs2(31, 24)
        loop_being_configured.inner_bounds.plpad := cmd.bits.cmd.rs2(23, 16)
        loop_being_configured.outer_bounds.in_col_dim := cmd.bits.cmd.rs2(15, 0)
      }

      is (LOOP_CONV_WS_CONFIG_4) {
        loop_being_configured.inner_bounds.orows := cmd.bits.cmd.rs1(63, 48)
        loop_being_configured.inner_bounds.prad := cmd.bits.cmd.rs1(47, 32)
        loop_being_configured.inner_bounds.pupad := cmd.bits.cmd.rs1(31, 21)
        loop_being_configured.inner_bounds.pdpad := cmd.bits.cmd.rs1(20, 10)
        loop_being_configured.outer_bounds.kernel_dilation := cmd.bits.cmd.rs1(9, 0)

        loop_being_configured.inner_bounds.ocols := cmd.bits.cmd.rs2(15, 0)
        loop_being_configured.outer_bounds.in_stride := cmd.bits.cmd.rs2(63, 48)
        loop_being_configured.outer_bounds.weight_stride := cmd.bits.cmd.rs2(47, 32)
        loop_being_configured.outer_bounds.out_stride := cmd.bits.cmd.rs2(31, 16)
      }

      is (LOOP_CONV_WS_CONFIG_5) {
        loop_being_configured.weights_dram_addr := cmd.bits.cmd.rs1

        loop_being_configured.output_dram_addr := cmd.bits.cmd.rs2
      }

      is (LOOP_CONV_WS_CONFIG_6) {
        loop_being_configured.bias_dram_addr := cmd.bits.cmd.rs1

        loop_being_configured.input_dram_addr := cmd.bits.cmd.rs2
      }

      is (LOOP_CONV_WS) {
        // RUN commits immutable eligibility; later CONFIG targets another slot.
        /** IPOAT：V02/V03 RUN 提交
         * I（Input 输入）：当前配置槽、RUN 命令、静态 VI 开关及请求状态。
         * P（Process 处理）：在 RUN 提交中保存跨行开关、资格与 generation，后续 CONFIG 不覆盖执行快照。
         * O（Output 输出）：被提交请求槽内的 VI 元数据。
         * A（Author 作者）：王志瑞
         * T（Time 时间）：2026-09-09（注释补充日期）
         */
        loop_being_configured.viCrossRow := virtual_i_cross_row.B
        loop_being_configured.viGeneration := viEpoch
        when(cmd.fire) {
          viEpoch := viEpoch + 1.U
          requestSeq := requestSeq + 1.U
          loop_being_configured.request_seq := requestSeq
          viRunStatus(loop_being_configured_id) := cmd.bits.cmd.status
        }
        loop_being_configured.viEligible := virtual_i_enable.B && (block_size == 64).B &&
          loop_being_configured.outer_bounds.stride === 1.U &&
          (!has_max_pool.B || cmd.bits.cmd.rs2(0)) && !cmd.bits.cmd.rs2(2,1).orR &&
          !cmd.bits.cmd.rs1(6,1).orR && cmd.bits.cmd.rs1(15,8) <= 1.U

        loop_being_configured.no_bias := cmd.bits.cmd.rs1(0)

        // TODO we added a default value for max_pixels_per_row just to maintain backwards compatibility. we should deprecate and remove it later
        val config_max_pixels_per_row = cmd.bits.cmd.rs1(15, 8)
        loop_being_configured.max_pixels_per_row := Mux(
          !has_first_layer_optimizations.B || config_max_pixels_per_row === 0.U,
          1.U, config_max_pixels_per_row)

        loop_being_configured.a_ex_spad_id := cmd.bits.cmd.rs1(19, 18)
        loop_being_configured.b_ex_spad_id := cmd.bits.cmd.rs1(17, 16) 
        
        loop_being_configured.wrot180 := has_training_convs.B && cmd.bits.cmd.rs1(1)
        loop_being_configured.input_dilated := has_training_convs.B && cmd.bits.cmd.rs2(2)
        loop_being_configured.trans_output_1203 := has_training_convs.B && cmd.bits.cmd.rs1(2)
        loop_being_configured.trans_weight_1203 := has_training_convs.B && cmd.bits.cmd.rs1(3)
        loop_being_configured.trans_weight_0132 := has_training_convs.B && cmd.bits.cmd.rs1(4)
        loop_being_configured.trans_input_3120 := has_training_convs.B && cmd.bits.cmd.rs1(5)
        loop_being_configured.dw := has_dw_convs.B && cmd.bits.cmd.rs1(6)

        loop_being_configured.no_pool := !has_max_pool.B || cmd.bits.cmd.rs2(0)
        loop_being_configured.activation := cmd.bits.cmd.rs2(5,3)

        loop_being_configured.downsample := cmd.bits.cmd.rs2(1)

        loop_being_configured.configured := true.B

        // assert(!loop_being_configured.input_dilated || loop_being_configured.outer_bounds.stride === 1.U)
        // assert(!loop_being_configured.downsample || (loop_being_configured.outer_bounds.kernel_dim === 1.U && loop_being_configured.outer_bounds.stride === 2.U)) // TODO add the rest of the conditions that must be true for "downsample" to be enabled
      }
    }
  }

  // Wire up request signals
  val ld_bias_addr_start = RegInit(0.U(log2Up(max_acc_addr).W))
  val ex_c_addr_start = RegInit(0.U(log2Up(max_acc_addr).W))
  val st_addr_start = RegInit(0.U(log2Up(max_acc_addr).W))

  val loop_requesting_ld_bias_id = Mux(head_loop.ld_bias_started, tail_loop_id, head_loop_id)
  val loop_requesting_ld_bias = loops(loop_requesting_ld_bias_id)
  ld_bias.io.req.bits.outer_bounds := loop_requesting_ld_bias.outer_bounds
  ld_bias.io.req.bits.inner_bounds := loop_requesting_ld_bias.inner_bounds
  ld_bias.io.req.bits.derived_params := loop_requesting_ld_bias.derived_params()
  ld_bias.io.req.bits.addr_start := ld_bias_addr_start
  ld_bias.io.req.bits.dram_addr := loop_requesting_ld_bias.bias_dram_addr
  ld_bias.io.req.bits.no_bias := loop_requesting_ld_bias.no_bias
  ld_bias.io.req.bits.loop_id := loop_requesting_ld_bias_id

  ld_bias.io.req.valid := !loop_requesting_ld_bias.ld_bias_started && loop_requesting_ld_bias.configured

  when (ld_bias.io.req.fire) {
    loop_requesting_ld_bias.running := true.B
    loop_requesting_ld_bias.ld_bias_started := true.B

    // when (loop_requesting_ld_bias.bias_dram_addr =/= 0.U) {
    when (loop_requesting_ld_bias.output_dram_addr =/= 0.U) {
      ld_bias_addr_start := floorAdd(ld_bias_addr_start, (max_acc_addr / concurrent_loops).U, max_acc_addr.U)
    }
  }

  val loop_requesting_ld_input_id = Mux(head_loop.ld_input_started, tail_loop_id, head_loop_id)
  val loop_requesting_ld_input = loops(loop_requesting_ld_input_id)
  ld_input.io.req.bits.outer_bounds := loop_requesting_ld_input.outer_bounds
  ld_input.io.req.bits.inner_bounds := loop_requesting_ld_input.inner_bounds
  ld_input.io.req.bits.derived_params := loop_requesting_ld_input.derived_params()
  ld_input.io.req.bits.addr_start := Mux(loop_requesting_ld_input.a_ex_spad_id === 0.U, loop_requesting_ld_input.a_addr_start, (loop_requesting_ld_input.a_ex_spad_id - 1.U) * (max_addr / concurrent_loops).U)
  ld_input.io.req.bits.dram_addr := loop_requesting_ld_input.input_dram_addr
  ld_input.io.req.bits.downsample := loop_requesting_ld_input.downsample
  ld_input.io.req.bits.max_pixels_per_row := loop_requesting_ld_input.max_pixels_per_row
  ld_input.io.req.bits.input_dilated := loop_requesting_ld_input.input_dilated
  ld_input.io.req.bits.trans_input_3120 := loop_requesting_ld_input.trans_input_3120
  ld_input.io.req.bits.loop_id := loop_requesting_ld_input_id

  ld_input.io.req.valid := !loop_requesting_ld_input.ld_input_started && loop_requesting_ld_input.configured

  when (ld_input.io.req.fire) {
    loop_requesting_ld_input.running := true.B
    loop_requesting_ld_input.ld_input_started := true.B
  }

  val loop_requesting_ld_weights_id = Mux(head_loop.ld_weights_started, tail_loop_id, head_loop_id)
  val loop_requesting_ld_weights = loops(loop_requesting_ld_weights_id)
  ld_weights.io.req.bits.outer_bounds := loop_requesting_ld_weights.outer_bounds
  ld_weights.io.req.bits.inner_bounds := loop_requesting_ld_weights.inner_bounds
  ld_weights.io.req.bits.derived_params := loop_requesting_ld_weights.derived_params()
  ld_weights.io.req.bits.addr_end :=  Mux(loop_requesting_ld_weights.b_ex_spad_id === 0.U, loop_requesting_ld_weights.b_addr_end, (loop_requesting_ld_weights.b_ex_spad_id) * (max_addr / concurrent_loops).U)
  ld_weights.io.req.bits.dram_addr := loop_requesting_ld_weights.weights_dram_addr
  ld_weights.io.req.bits.trans_weight_1203 := loop_requesting_ld_weights.trans_weight_1203
  ld_weights.io.req.bits.trans_weight_0132 := loop_requesting_ld_weights.trans_weight_0132
  ld_weights.io.req.bits.dw := loop_requesting_ld_weights.dw
  ld_weights.io.req.bits.loop_id := loop_requesting_ld_weights_id

  ld_weights.io.req.valid := !loop_requesting_ld_weights.ld_weights_started && loop_requesting_ld_weights.configured

  when (ld_weights.io.req.fire) {
    loop_requesting_ld_weights.running := true.B
    loop_requesting_ld_weights.ld_weights_started := true.B
  }

  val loop_requesting_ex_id = Mux(head_loop.ex_started, tail_loop_id, head_loop_id)
  val loop_requesting_ex = loops(loop_requesting_ex_id)
  ex.io.req.bits.outer_bounds := loop_requesting_ex.outer_bounds
  ex.io.req.bits.inner_bounds := loop_requesting_ex.inner_bounds
  ex.io.req.bits.derived_params := loop_requesting_ex.derived_params()
  ex.io.req.bits.viEligible := loop_requesting_ex.viEligible
  ex.io.req.bits.viCrossRow := loop_requesting_ex.viCrossRow
  ex.io.req.bits.viGeneration := loop_requesting_ex.viGeneration
  ex.io.req.bits.a_addr_start := Mux(loop_requesting_ex.a_ex_spad_id === 0.U, loop_requesting_ex.a_addr_start, (loop_requesting_ex.a_ex_spad_id - 1.U) * (max_addr / concurrent_loops).U)
  ex.io.req.bits.b_addr_end := Mux(loop_requesting_ex.b_ex_spad_id === 0.U, loop_requesting_ex.b_addr_end, (loop_requesting_ex.b_ex_spad_id) * (max_addr / concurrent_loops).U)
  ex.io.req.bits.c_addr_start := ex_c_addr_start
  ex.io.req.bits.wrot180 := loop_requesting_ex.wrot180
  ex.io.req.bits.downsample := loop_requesting_ex.downsample
  ex.io.req.bits.max_pixels_per_row := loop_requesting_ex.max_pixels_per_row
  ex.io.req.bits.input_dilated := loop_requesting_ex.input_dilated
  ex.io.req.bits.trans_weight_0132 := loop_requesting_ex.trans_weight_0132
  ex.io.req.bits.trans_input_3120 := loop_requesting_ex.trans_input_3120
  ex.io.req.bits.loop_id := loop_requesting_ex_id

  ex.io.req.valid := !loop_requesting_ex.ex_started && loop_requesting_ex.ld_bias_started &&
    loop_requesting_ex.ld_input_started && loop_requesting_ex.ld_weights_started && loop_requesting_ex.configured

  when (ex.io.req.fire) {
    loop_requesting_ex.running := true.B
    loop_requesting_ex.ex_started := true.B

    when (loop_requesting_ex.output_dram_addr =/= 0.U) {
      ex_c_addr_start := floorAdd(ex_c_addr_start, (max_acc_addr / concurrent_loops).U, max_acc_addr.U)
    }
  }

  val loop_requesting_st_id = Mux(head_loop.st_started, tail_loop_id, head_loop_id)
  val loop_requesting_st = loops(loop_requesting_st_id)
  st.io.req.bits.outer_bounds := loop_requesting_st.outer_bounds
  st.io.req.bits.inner_bounds := loop_requesting_st.inner_bounds
  st.io.req.bits.derived_params := loop_requesting_st.derived_params()
  st.io.req.bits.addr_start := st_addr_start
  st.io.req.bits.dram_addr := loop_requesting_st.output_dram_addr
  st.io.req.bits.no_pool := loop_requesting_st.no_pool
  st.io.req.bits.activation := loop_requesting_st.activation
  st.io.req.bits.trans_output_1203 := loop_requesting_st.trans_output_1203
  st.io.req.bits.loop_id := loop_requesting_st_id

  st.io.req.valid := !loop_requesting_st.st_started && loop_requesting_st.ex_started && loop_requesting_st.configured

  when (st.io.req.fire) {
    loop_requesting_st.running := true.B
    loop_requesting_st.st_started := true.B

    when (loop_requesting_st.output_dram_addr =/= 0.U) {
      st_addr_start := floorAdd(st_addr_start, (max_acc_addr / concurrent_loops).U, max_acc_addr.U)
    }
  }

  // Handle completed signals
  when (ld_bias.io.idle && loops(ld_bias.io.loop_id).running && loops(ld_bias.io.loop_id).ld_bias_started) {
    loops(ld_bias.io.loop_id).ld_bias_completed := true.B
  }

  when (ld_input.io.idle && loops(ld_input.io.loop_id).running && loops(ld_input.io.loop_id).ld_input_started) {
    loops(ld_input.io.loop_id).ld_input_completed := true.B
  }

  when (ld_weights.io.idle && loops(ld_weights.io.loop_id).running && loops(ld_weights.io.loop_id).ld_weights_started) {
    loops(ld_weights.io.loop_id).ld_weights_completed := true.B
  }

  when (ex.io.idle && loops(ex.io.loop_id).running && loops(ex.io.loop_id).ex_started) {
    loops(ex.io.loop_id).ex_completed := true.B
  }

  when (st.io.idle && loops(st.io.loop_id).running && loops(st.io.loop_id).st_started) {
    loops(st.io.loop_id).st_completed := true.B
  }

  if (loopConvTrace) {
    when (st.io.idle && loops(st.io.loop_id).running && loops(st.io.loop_id).st_started) {
      printf(p"LC_ST_IDLE_TOP loop=${st.io.loop_id} st_util=${st_utilization} ld_util=${ld_utilization} ex_util=${ex_utilization} head=${head_loop_id} tail=${tail_loop_id}\n")
    }
    when (io.st_completed =/= 0.U) {
      printf(p"LC_ST_COMPLETED count=${io.st_completed} st_util=${st_utilization} head=${head_loop_id} tail=${tail_loop_id}\n")
    }
  }

  // （Output 输出；Author 作者：王志瑞）：这是 LoopConv request 唯一可归还 credit 的事件。虽然
  // all_completed 已成立，但在 reset 前 slot 仍是占用状态，不能提前告知软件可提交。
  val requestRetire = head_loop.running && head_loop.all_completed()
  io.request_retire := requestRetire
  when (requestRetire) {
    if (loopConvTrace) {
      printf(p"LC_SLOT_RESET loop=${head_loop_id} ld_util=${ld_utilization} ex_util=${ex_utilization} st_util=${st_utilization}\n")
    }
    head_loop.reset()
    head_loop_id := ~head_loop_id
  }

  /** IPOAT：LoopConv 四页死锁快照
    * I（Input 输入）：两个 slot 的序号/started/completed、五个子引擎握手、RS utilization 和完成计数。
    * P（Process 处理）：计算阻塞原因位与距上次进展周期数；逻辑仅扇出观察，绝不回接 ready/valid。
    * O（Output 输出）：页0全局状态、页1/2 slot0/1、页3子引擎及完成事件。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-17
    */
  val debugProgress = cmd.fire || io.out.fire || requestRetire ||
    io.ld_completed.orR || io.ex_completed.orR || io.st_completed.orR ||
    ld_bias.io.req.fire || ld_input.io.req.fire || ld_weights.io.req.fire ||
    ex.io.req.fire || st.io.req.fire
  val debugCyclesSinceProgress = RegInit(0.U(32.W))
  when (debugProgress) {
    debugCyclesSinceProgress := 0.U
  }.elsewhen (io.busy && debugCyclesSinceProgress =/= "hffffffff".U) {
    debugCyclesSinceProgress := debugCyclesSinceProgress + 1.U
  }

  def startedMask(l: LoopConvState): UInt = Cat(l.st_started, l.ex_started,
    l.ld_weights_started, l.ld_input_started, l.ld_bias_started)
  def completedMask(l: LoopConvState): UInt = Cat(l.st_completed, l.ex_completed,
    l.ld_weights_completed, l.ld_input_completed, l.ld_bias_completed)
  def slotBlockMask(id: Int): UInt = Cat(
    loops(id).st_started && !loops(id).st_completed && !st.io.idle,
    loops(id).ex_started && !loops(id).ex_completed && !ex.io.idle,
    st.io.rob_overloaded,
    ex.io.rob_overloaded,
    ld_weights.io.wait_for_prev_loop || ld_input.io.wait_for_prev_loop || ld_bias.io.wait_for_prev_loop,
    ld_weights.io.rob_overloaded || ld_input.io.rob_overloaded || ld_bias.io.rob_overloaded,
    loops(id).configured && !loops(id).running,
    !loops(id).configured)

  io.deadlock_debug(0) := Cat(debugCyclesSinceProgress, requestSeq(7, 0),
    io.out.fire,
    arb.io.chosen, io.running_slot_count, tail_loop_id, head_loop_id,
    st_utilization.pad(5), ex_utilization.pad(6), ld_utilization.pad(5))
  for (i <- 0 until concurrent_loops) {
    io.deadlock_debug(i + 1) := Cat(0.U(12.W), slotBlockMask(i),
      completedMask(loops(i)), startedMask(loops(i)), loops(i).running,
      loops(i).configured, loops(i).request_seq)
  }
  io.deadlock_debug(3) := Cat(0.U(27.W),
    st.io.loop_id, ex.io.loop_id, ld_weights.io.loop_id, ld_input.io.loop_id, ld_bias.io.loop_id,
    st.io.idle, ex.io.idle, ld_weights.io.idle, ld_input.io.idle, ld_bias.io.idle,
    st.io.req.valid, st.io.req.ready, ex.io.req.valid, ex.io.req.ready,
    ld_weights.io.req.valid, ld_weights.io.req.ready,
    ld_input.io.req.valid, ld_input.io.req.ready,
    ld_bias.io.req.valid, ld_bias.io.req.ready,
    io.st_completed.pad(4), io.ex_completed.pad(4), io.ld_completed.pad(4))
  /** IPOAT：五个子生成器详细页
    * I（Input 输入）：Bias/Input/Weight/Execute/Store 各自的状态、迭代器和阻塞握手。
    * P（Process 处理）：按固定顺序透传子模块的 64-bit 被动观测页。
    * O（Output 输出）：deadlock_debug[4..8]，用于从未退休 slot 追到具体生成器等待条件。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-19
    */
  io.deadlock_debug(4) := ld_bias.io.deadlock_debug
  io.deadlock_debug(5) := ld_input.io.deadlock_debug
  io.deadlock_debug(6) := ld_weights.io.deadlock_debug
  io.deadlock_debug(7) := ex.io.deadlock_debug
  io.deadlock_debug(8) := st.io.deadlock_debug

  // Resets
  when (reset.asBool) {
    loops.zipWithIndex.foreach { case (l, i) =>
      l.reset()
      l.a_addr_start := (i * (max_addr / concurrent_loops)).U
      l.b_addr_end := ((i+1) * (max_addr / concurrent_loops)).U
    }
  }
}

object LoopConv {
  /** IPOAT：LoopConv 诊断返回值
    * I（Input 输入）：LoopConv module 的四页只读端口。
    * P（Process 处理）：随原有 out/busy/retire/running/trace 一并返回 Controller。
    * O（Output 输出）：不改变命令路径的第六个 tuple 元素。
    * A（Author 作者）：王志瑞
    * T（Time 时间）：2026-09-17
    */
  def apply(in: DecoupledIO[GemminiCmd], ld_completed: UInt, st_completed: UInt, ex_completed: UInt,
            block_size: Int, coreMaxAddrBits: Int, rob_size: Int, max_lds: Int, max_exs: Int, max_sts: Int,
            max_addr: Int, max_acc_addr: Int, input_w: Int, acc_w: Int, dma_max_bytes: Int,
            config_mvin_rs1_t: ConfigMvinRs1, mvin_rs2_t: MvinRs2, config_mvout_rs2_t: ConfigMvoutRs2,
            mvout_rs2_t: MvoutRs2, config_ex_rs1_t: ConfigExRs1, preload_rs1_t: PreloadRs, preload_rs2_t: PreloadRs,
            compute_rs1_t: ComputeRs, compute_rs2_t: ComputeRs, has_training_convs: Boolean, has_max_pool: Boolean,
            has_first_layer_optimizations: Boolean, has_dw_convs: Boolean, virtual_i_enable: Boolean = false, virtual_i_cross_row: Boolean = false)
           (implicit p: Parameters): (DecoupledIO[GemminiCmd], Bool, Bool, UInt, ValidIO[LoopConvTraceEvent], Vec[UInt]) = {

    val mod = Module(new LoopConv(block_size, coreMaxAddrBits, rob_size, max_lds, max_exs, max_sts,
      max_addr, max_acc_addr, input_w, acc_w, dma_max_bytes,
      config_mvin_rs1_t, mvin_rs2_t, config_mvout_rs2_t, mvout_rs2_t, config_ex_rs1_t, preload_rs1_t, preload_rs2_t,
      compute_rs1_t, compute_rs2_t, has_training_convs, has_max_pool, has_first_layer_optimizations, has_dw_convs, virtual_i_enable, virtual_i_cross_row))

    mod.io.in <> in
    mod.io.ld_completed := ld_completed
    mod.io.st_completed := st_completed
    mod.io.ex_completed := ex_completed
    (mod.io.out, mod.io.busy, mod.io.request_retire, mod.io.running_slot_count, mod.io.ldWeightTrace, mod.io.deadlock_debug)
  }

  def castDramOffset(dram_offset: UInt): UInt = {
    // Cast dram offsets to 32 bits max
    dram_offset & "hFFFFFFFF".U
  }
}
