package gemmini

import chisel3._
import chisel3.util._

/** Row units throughout; no LocalAddr flag bits and no DRAM byte addresses.
  * The caller supplies a frozen, owned, completely loaded rectangular view.
  * Physical origin may include explicit halo rows outside the valid rectangle.
  */
/** IPOAT：V01 输入张量视图
 * I（Input 输入）：已加载输入 tile 的物理基址、驻留矩形、步长及通道/batch 范围。
 * P（Process 处理）：以 SPAD 行为单位描述驻留布局，区分物理原点与有效范围。
 * O（Output 输出）：供 AGU 使用的 InputTileView 字段。
 * A（Author 作者）：王志瑞
 * T（Time 时间）：2026-09-09（注释补充日期）
 */
class InputTileView extends Bundle {
  val base = UInt(32.W)
  val limit = UInt(32.W) // exclusive physical row limit
  val channelStride = UInt(32.W)
  val batchStride = UInt(32.W)
  val rowStride = UInt(32.W)
  val pixelStride = UInt(32.W)
  val physicalY = SInt(32.W)
  val physicalX = SInt(32.W)
  val residentY = UInt(16.W)
  val residentX = UInt(16.W)
  val residentH = UInt(16.W)
  val residentW = UInt(16.W)
  val batchOrigin = UInt(16.W)
  val batches = UInt(16.W)
  val channelOrigin = UInt(16.W) // channel BLOCK, not scalar channel
  val channelBlocks = UInt(16.W)
}

/** Normal LoopConv output layout: base + jg * (Nb*Ht*Wt) + p. */
/** IPOAT：V01 输出张量视图
 * I（Input 输入）：调用者拥有的 ACC 分配基址、上界及输出组数。
 * P（Process 处理）：描述完整输出分配，供组间距计算和越界检查使用。
 * O（Output 输出）：OutputTileView；地址单位为 ACC 行。
 * A（Author 作者）：王志瑞
 * T（Time 时间）：2026-09-09（注释补充日期）
 */
class OutputTileView extends Bundle {
  val base = UInt(32.W)
  val limit = UInt(32.W) // exclusive end of the caller-owned ACC allocation
  val groups = UInt(16.W)
}

/** IPOAT：V01–V03 不可变段描述符
 * I（Input 输入）：输入/输出视图、卷积坐标、owner/generation、可选段起点及长度。
 * P（Process 处理）：保留完整输出 tile 的形状；用 segment 表示其中不超过64行的微操作。
 * O（Output 输出）：随请求按值保存的描述符；segment=false 保持原行为。
 * A（Author 作者）：王志瑞
 * T（Time 时间）：2026-09-09（注释补充日期）
 */
class VirtualITileDesc extends Bundle {
  val input = new InputTileView
  val output = new OutputTileView
  val owner = UInt(16.W)
  val generation = UInt(16.W)
  // Optional <=64-row micro-op within the full output allocation.
  val segment = Bool()
  val startB = UInt(16.W)
  val startR = UInt(16.W)
  val startC = UInt(16.W)
  val segmentRows = UInt(7.W)
  val supported = Bool() // caller rejects transpose/pooling/packed-first-layer etc.
  val batches = UInt(16.W)
  val tileRows = UInt(16.W)
  val tileCols = UInt(16.W)
  val batchStart = UInt(16.W)
  val outputY = UInt(16.W)
  val outputX = UInt(16.W)
  val inputH = UInt(16.W)
  val inputW = UInt(16.W)
  val strideY = UInt(16.W)
  val strideX = UInt(16.W)
  val padY = UInt(16.W)
  val padX = UInt(16.W)
  val kernelY = UInt(16.W) // one original K segment, never merges kernel positions
  val kernelX = UInt(16.W)
  val dilationY = UInt(16.W)
  val dilationX = UInt(16.W)
  val channelBlock = UInt(16.W)
  val outputGroup = UInt(16.W)
  val kValid = UInt(7.W)
  val jValid = UInt(7.W)
}

/** IPOAT：V01 地址 token
 * I（Input 输入）：AGU 计算的逻辑坐标、驻留状态、物理地址和有效列数。
 * P（Process 处理）：封装行地址、掩码、归属及段尾标志；无效地址由状态约束其使用。
 * O（Output 输出）：RESIDENT/PADDING/NOT_RESIDENT token 及 fault/last/chunkLast。
 * A（Author 作者）：王志瑞
 * T（Time 时间）：2026-09-09（注释补充日期）
 */
class VirtualIAddress extends Bundle {
  val owner = UInt(16.W)
  val generation = UInt(16.W)
  val pixel = UInt(48.W)
  val batch = UInt(17.W)
  val row = UInt(16.W)
  val col = UInt(16.W)
  val status = UInt(2.W) // 0 RESIDENT, 1 PADDING (symmetric INT8 zero), 2 NOT_RESIDENT
  val fault = Bool() // malformed/unsupported descriptor or output allocation
  val spadRow = UInt(32.W) // meaningful ONLY for RESIDENT
  val accRow = UInt(32.W) // meaningful ONLY when !fault
  val inputMask = UInt(64.W)
  val outputMask = UInt(64.W)
  val chunkLast = Bool() // <=64 pixels per micro-op; does not allocate padded ACC rows
  val last = Bool()
}

/** Counter-based address generator used standalone and by Execute preflight.
  * One immutable descriptor per original K/J segment, one ordered token per fire.
  * The caller preflights NOT_RESIDENT before compute side effects and owns read credit.
  */
/** IPOAT：V01/V03 计数器式地址生成
 * I（Input 输入）：req 中的冻结描述符、out.ready 和共享 reset。
 * P（Process 处理）：请求握手后锁存；计数器只在 out.fire 推进，校验驻留/容量并在段尾结束。
 * O（Output 输出）：稳定的地址 token；padding 读零，未驻留与非法请求明确报告。
 * A（Author 作者）：王志瑞
 * T（Time 时间）：2026-09-09（注释补充日期）
 */
class VirtualIAddressGenerator extends Module {
  val io = IO(new Bundle {
    val req = Flipped(Decoupled(new VirtualITileDesc))
    val out = Decoupled(new VirtualIAddress)
  })
  val active = RegInit(false.B)
  val d = Reg(new VirtualITileDesc)
  val b = RegInit(0.U(16.W))
  val r = RegInit(0.U(16.W))
  val c = RegInit(0.U(16.W))
  val p = RegInit(0.U(48.W))
  val chunk = RegInit(0.U(6.W))
  val emitted = RegInit(0.U(7.W))
  io.req.ready := !active && !reset.asBool
  when(io.req.fire) {
    d := io.req.bits
    active := true.B
    val in = io.req.bits
    b := Mux(in.segment, in.startB, 0.U)
    r := Mux(in.segment, in.startR, 0.U)
    c := Mux(in.segment, in.startC, 0.U)
    p := Mux(in.segment, in.startB * in.tileRows * in.tileCols +& in.startR * in.tileCols +& in.startC, 0.U)
    emitted := 0.U; chunk := 0.U
  }
  // Widen before signed arithmetic; unsigned subtraction must never wrap into a row.
  val batch = d.batchStart +& b
  val iy = ((d.outputY +& r) * d.strideY).zext.pad(64) - d.padY.zext.pad(64) + (d.kernelY * d.dilationY).zext.pad(64)
  val ix = ((d.outputX +& c) * d.strideX).zext.pad(64) - d.padX.zext.pad(64) + (d.kernelX * d.dilationX).zext.pad(64)
  val padding = iy < 0.S || ix < 0.S || iy >= d.inputH.zext || ix >= d.inputW.zext
  val v = d.input
  val inView = batch >= v.batchOrigin && batch < (v.batchOrigin +& v.batches) &&
    iy >= v.residentY.zext && iy < (v.residentY +& v.residentH).zext &&
    ix >= v.residentX.zext && ix < (v.residentX +& v.residentW).zext &&
    d.channelBlock >= v.channelOrigin && d.channelBlock < (v.channelOrigin +& v.channelBlocks)
  val dy = iy - v.physicalY
  val dx = ix - v.physicalX
  // 128-bit intermediate prevents truncation even for malformed maximum-width descriptors.
  val address = v.base.pad(128) +
    (d.channelBlock.zext - v.channelOrigin.zext).asUInt.pad(128) * v.channelStride +
    (batch.zext - v.batchOrigin.zext).asUInt.pad(128) * v.batchStride +
    dy.asUInt.pad(128) * v.rowStride + dx.asUInt.pad(128) * v.pixelStride
  val pixels = d.batches * d.tileRows * d.tileCols
  val allocationEnd = d.output.base.pad(128) + pixels.pad(128) * d.output.groups
  val acc = d.output.base.pad(128) + d.outputGroup * pixels.pad(128) + p
  val startPixel = d.startB * d.tileRows * d.tileCols +& d.startR * d.tileCols +& d.startC
  val badSegment = d.segment && (d.startB >= d.batches || d.startR >= d.tileRows ||
    d.startC >= d.tileCols || d.segmentRows === 0.U || d.segmentRows > 64.U ||
    startPixel +& d.segmentRows > pixels)
  val bad = badSegment || !d.supported || d.batches === 0.U || d.tileRows === 0.U || d.tileCols === 0.U ||
    d.inputH === 0.U || d.inputW === 0.U || d.strideY === 0.U || d.strideX === 0.U ||
    d.dilationY === 0.U || d.dilationX === 0.U ||
    d.kValid === 0.U || d.kValid > 64.U || d.jValid === 0.U || d.jValid > 64.U ||
    d.outputGroup >= d.output.groups || allocationEnd > d.output.limit ||
    v.pixelStride === 0.U || v.rowStride === 0.U || v.batchStride === 0.U || v.channelStride === 0.U
  val resident = inView && dy >= 0.S && dx >= 0.S && address < v.limit
  val last = bad || (d.segment && emitted === d.segmentRows - 1.U) || (b === d.batches - 1.U && r === d.tileRows - 1.U && c === d.tileCols - 1.U)
  io.out.valid := active && !reset.asBool
  io.out.bits.owner := d.owner
  io.out.bits.generation := d.generation
  io.out.bits.pixel := p
  io.out.bits.batch := batch
  io.out.bits.row := r
  io.out.bits.col := c
  io.out.bits.status := Mux(bad, 2.U, Mux(padding, 1.U, Mux(resident, 0.U, 2.U)))
  io.out.bits.fault := bad
  io.out.bits.spadRow := Mux(!bad && !padding && resident, address, 0.U)
  io.out.bits.accRow := Mux(bad, 0.U, acc)
  io.out.bits.inputMask := Mux(bad, 0.U, ((1.U(65.W) << d.kValid) - 1.U)(63, 0))
  io.out.bits.outputMask := Mux(bad, 0.U, ((1.U(65.W) << d.jValid) - 1.U)(63, 0))
  io.out.bits.last := last
  io.out.bits.chunkLast := chunk === 63.U || last
  when(io.out.fire) {
    when(last) { active := false.B }
      .otherwise {
        p := p + 1.U
        emitted := emitted + 1.U
        chunk := chunk + 1.U
        when(c === d.tileCols - 1.U) {
          c := 0.U
          when(r === d.tileRows - 1.U) { r := 0.U; b := b + 1.U }
            .otherwise { r := r + 1.U }
        }.otherwise { c := c + 1.U }
      }
  }
}
