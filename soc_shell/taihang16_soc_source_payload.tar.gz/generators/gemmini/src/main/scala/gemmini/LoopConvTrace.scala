package gemmini

import chisel3._

/** IPOAE-A（Author 作者：王志瑞）：LoopConv LOAD2 片上被动观测事件。
  *
  * word 0 of the stored record is {cycle[31:0], meta[31:0]}. The remaining
  * three words are interpreted per observation point and documented by the
  * board diagnostic software.
  */
class LoopConvTraceEvent extends Bundle {
  val meta = UInt(32.W)
  val payload0 = UInt(64.W)
  val payload1 = UInt(64.W)
  val payload2 = UInt(64.W)
}
