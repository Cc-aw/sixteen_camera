package gemmini
import chisel3._
import chisel3.util._

/** Immutable by-value descriptor. No handle table is reused while a command lives
  * in RS/Execute: each queue entry owns its copy. Raw/legacy commands set valid=0.
  */
/** IPOAT：V02 命令随行快照
 * I（Input 输入）：VI 有效标志和完整 tile/segment 描述符。
 * P（Process 处理）：描述符按值随流水、仲裁及队列传递，避免引用后续 CONFIG。
 * O（Output 输出）：每条命令独占的 VirtualICommand；legacy 设置 valid=false。
 * A（Author 作者）：王志瑞
 * T（Time 时间）：2026-09-09（注释补充日期）
 */
class VirtualICommand extends Bundle {
  val valid = Bool()
  val desc = new VirtualITileDesc
}

/** Validate a whole <=64-row micro-op before allowing any compute side effect.
  * Tokens are retained until their SRAM request (or padding event) commits.
  * The existing Execute control FIFO reserves return metadata at that same fire.
  */
/** IPOAT：V02/V03 微操作预检查
 * I（Input 输入）：冻结请求、输出消费 ready、完成 release 和共享 reset。
 * P（Process 处理）：先证明完整驻留矩形或扫描整个微操作；整体检查后才输出地址，消费完后释放。
 * O（Output 输出）：prepared/reject、按序地址 token 和下一请求 ready；拒绝时不发部分读取。
 * A（Author 作者）：王志瑞
 * T（Time 时间）：2026-09-09（注释补充日期）
 */
class VirtualIPreflight(maxRows: Int = 64, fastResident: Boolean = true) extends Module {
  require(maxRows >= 1 && maxRows <= 64)
  val io = IO(new Bundle {
    val req = Flipped(Decoupled(new VirtualITileDesc))
    val out = Decoupled(new VirtualIAddress)
    val reject = Output(Bool())
    val release = Input(Bool()) // command drained/rejected, not merely last address issued
    val prepared = Output(Bool())
  })
  val idle :: checking :: ready :: rejected :: drained :: streaming :: Nil = Enum(6)
  val state = RegInit(idle)
  val agu = Module(new VirtualIAddressGenerator)
  val tokens = Reg(Vec(maxRows, new VirtualIAddress))
  val w = RegInit(0.U(7.W))
  val rd = RegInit(0.U(7.W))
  val bad = RegInit(false.B)
  val rows = Mux(io.req.bits.segment, io.req.bits.segmentRows, io.req.bits.batches * io.req.bits.tileRows * io.req.bits.tileCols)
  val shapeOK = rows > 0.U && rows <= maxRows.U
  /** IPOAT：已证明驻留段直接流出
   * I（Input 输入）：请求描述符、矩形充分条件和原输出信用握手。
   * P（Process 处理）：证明通过时跳过逐token预扫描，锁存后的AGU按消费推进；未证明的请求仍先完整扫描。
   * O（Output 输出）：无副作用的整体检查结果及有背压的地址流；保留同拍末token/release和reset语义。
   * A（Author 作者）：王志瑞
   * T（Time 时间）：2026-09-09
   */
  val proven = if (fastResident) VirtualIResidentProof(io.req.bits) else false.B
  io.req.ready := state === idle && agu.io.req.ready && !reset.asBool
  agu.io.req.valid := io.req.valid && state === idle && shapeOK && !reset.asBool
  agu.io.req.bits := io.req.bits
  when(io.req.fire) {
    w := 0.U; rd := 0.U; bad := false.B
    state := Mux(shapeOK, Mux(proven, streaming, checking), rejected)
  }
  agu.io.out.ready := state === checking || (state === streaming && io.out.ready)
  when(agu.io.out.fire && state === checking) {
    tokens(w) := agu.io.out.bits
    val invalid = agu.io.out.bits.fault || agu.io.out.bits.status === 2.U
    bad := bad || invalid
    when(agu.io.out.bits.last) { state := Mux(bad || invalid, rejected, ready) }
      .otherwise { w := w + 1.U }
  }
  io.out.valid := (state === ready || (state === streaming && agu.io.out.valid)) && !reset.asBool
  io.out.bits := Mux(state === streaming, agu.io.out.bits, tokens(rd))
  io.prepared := (state === ready || state === streaming || state === drained) && !reset.asBool
  io.reject := state === rejected && !reset.asBool
  when(state === streaming && agu.io.out.valid) {
    assert(!agu.io.out.bits.fault && agu.io.out.bits.status === 0.U, "VI resident proof disagrees with AGU")
  }
  when(io.out.fire) {
    when(io.out.bits.last) { state := drained }
      .otherwise { rd := rd + 1.U }
  }
  when(io.release) {
    assert(state === drained || state === rejected || ((state === ready || state === streaming) && io.out.fire && io.out.bits.last), "VI release before all address tokens retired")
    state := idle
  }
}
